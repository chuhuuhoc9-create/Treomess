# Facebook MQTT All-in-One Tool
# Tích hợp tất cả các tính năng: Typing, Share Link, Share Contact, Send Message, Poll, Theme, Block, Add User, Rename Group

import json
import time
import random
import string
import re
import os
import sys
import ssl
import threading
from io import BytesIO, BufferedReader
from os.path import basename
from mimetypes import guess_type
from urllib.parse import urlparse
from typing import Callable, Optional, Union, List
from concurrent.futures import ThreadPoolExecutor
import concurrent.futures

import requests
import paho.mqtt.client as mqtt

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def parse_cookie_string(cookie_string):
    """Parse cookie string into dictionary"""
    cookie_dict = {}
    cookies = cookie_string.split(";")
    for cookie in cookies:
        if "=" in cookie:
            key, value = cookie.split("=", 1)
            try:
                cookie_dict[key.strip()] = value.strip()
            except:
                pass
    return cookie_dict

def digitToChar(digit):
    """Convert digit to character for base conversion"""
    if digit < 10:
        return str(digit)
    return chr(ord('a') + digit - 10)

def str_base(number, base):
    """Convert number to specified base"""
    if number < 0:
        return "-" + str_base(-number, base)
    (d, m) = divmod(number, base)
    if d > 0:
        return str_base(d, base) + digitToChar(m)
    return digitToChar(m)

def base36encode(number: int, alphabet="0123456789abcdefghijklmnopqrstuvwxyz"):
    """Encode number to base36"""
    if not isinstance(number, int):
        raise TypeError("number must be an integer")
    base36 = ""
    sign = ""
    if number < 0:
        sign = "-"
        number = -number
    if 0 <= number < len(alphabet):
        return sign + alphabet[number]
    while number != 0:
        number, i = divmod(number, len(alphabet))
        base36 = alphabet[i] + base36
    return sign + base36

def generate_offline_threading_id() -> str:
    """Generate offline threading ID"""
    ret = int(time.time() * 1000)
    value = random.randint(0, 4294967295)
    binary_str = format(value, "022b")[-22:]
    msgs = bin(ret)[2:] + binary_str
    return str(int(msgs, 2))

def generate_session_id():
    """Generate a random session ID between 1 and 9007199254740991"""
    return random.randint(1, 2 ** 53)

def generate_client_id():
    """Generate client ID"""
    def gen(length):
        return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))
    return gen(8) + '-' + gen(4) + '-' + gen(4) + '-' + gen(4) + '-' + gen(12)

def json_minimal(data):
    """Get JSON data in minimal form"""
    return json.dumps(data, separators=(",", ":"))

def gen_threading_id():
    """Generate threading ID"""
    return str(
        int(format(int(time.time() * 1000), "b") +
            ("0000000000000000000000" +
             format(int(random.random() * 4294967295), "b"))
            [-22:], 2)
    )

def get_guid():
    """Generate GUID"""
    return generate_client_id()

def clearHTML(text):
    """Remove HTML tags from text"""
    regex = re.compile(r'<[^>]+>')
    return regex.sub('', text)

def normalize_text(text):
    """Normalize text for comparison"""
    if not text:
        return ""
    return str(text).lower().strip()

def get_group_members_simple(dataFB, thread_id, fb_tools_instance=None):
    """Get group members with gender classification - with DEBUG logging"""
    try:
        if not fb_tools_instance:
            print(f"⚠️ Thread {thread_id}: Không có fb_tools instance")
            return None, [], []
        
        if not fb_tools_instance.getAllThreadList():
            print(f"❌ Thread {thread_id}: getAllThreadList() failed")
            return None, [], []
        
        fb_tools_instance.threadID = str(thread_id)
        member_data = fb_tools_instance.typeCommand("exportMemberListToJson")
        
        # DEBUG: Log what we got
        if not member_data:
            print(f"❌ Thread {thread_id}: member_data is empty/None")
            return None, [], []
        
        if not isinstance(member_data, list):
            print(f"⚠️ Thread {thread_id}: member_data type = {type(member_data)}, expected list")
            return None, [], []
        
        print(f"📊 Thread {thread_id}: Got {len(member_data)} member JSON items")
        
        males = []
        females = []
        no_gender_count = 0
        
        for i, member_json in enumerate(member_data):
            try:
                member = json.loads(member_json)
                for uid, info in member.items():
                    gender = info.get("gender", "").upper()
                    name = info.get("nameFB", "Không rõ")
                    
                    if not gender or gender not in ("MALE", "FEMALE"):
                        no_gender_count += 1
                        print(f"   ⚠️ UID {uid} ({name}): gender='{gender}' (skipped)")
                        continue
                    
                    member_info = {"uid": uid, "name": name, "gender": gender}
                    if gender == "MALE":
                        males.append(member_info)
                    else:
                        females.append(member_info)
            except Exception as parse_err:
                print(f"   ❌ Parse error item {i}: {parse_err}")
                continue
        
        print(f"✅ Thread {thread_id}: {len(males)} nam, {len(females)} nữ, {no_gender_count} no gender")
        return None, males, females
        
    except Exception as e:
        print(f"❌ Lỗi get_group_members_simple thread {thread_id}: {e}")
        import traceback
        traceback.print_exc()
        return None, [], []

# ============================================================================
# HEADERS AND REQUEST FUNCTIONS
# ============================================================================

def Headers(setCookies, dataForm=None, Host=None):
    """Generate headers for Facebook requests"""
    if Host is None:
        Host = "www.facebook.com"
    headers = {}
    headers["Host"] = Host
    headers["Connection"] = "keep-alive"
    if dataForm is not None:
        headers["Content-Length"] = str(len(dataForm))
    headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
    headers["Accept"] = "*/*"
    headers["Origin"] = "https://" + Host
    headers["Sec-Fetch-Site"] = "same-origin"
    headers["Sec-Fetch-Mode"] = "cors"
    headers["Sec-Fetch-Dest"] = "empty"
    headers["Referer"] = "https://" + Host
    headers["Accept-Language"] = "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7"
    return headers

class Counter:
    """Simple counter class"""
    def __init__(self, initial_value=0):
        self.value = initial_value
    
    def increment(self):
        self.value += 1
        return self.value
    
    @property
    def counter(self):
        return self.value

# Global counter for requests
_req_counter = Counter(0)

def formAll(dataFB, FBApiReqFriendlyName=None, docID=None, requireGraphql=None):
    """Build form data for Facebook API requests"""
    global _req_counter
    __reg = _req_counter.increment()
    
    dataForm = {}
    if requireGraphql is None:
        dataForm["fb_dtsg"] = dataFB["fb_dtsg"]
        dataForm["jazoest"] = dataFB["jazoest"]
        dataForm["__a"] = 1
        dataForm["__user"] = str(dataFB["FacebookID"])
        dataForm["__req"] = str_base(__reg, 36)
        dataForm["__rev"] = dataFB["clientRevision"]
        dataForm["av"] = dataFB["FacebookID"]
        dataForm["fb_api_caller_class"] = "RelayModern"
        dataForm["fb_api_req_friendly_name"] = FBApiReqFriendlyName
        dataForm["server_timestamps"] = "true"
        dataForm["doc_id"] = str(docID)
    else:
        dataForm["fb_dtsg"] = dataFB["fb_dtsg"]
        dataForm["jazoest"] = dataFB["jazoest"]
        dataForm["__a"] = 1
        dataForm["__user"] = str(dataFB["FacebookID"])
        dataForm["__req"] = str_base(__reg, 36)
        dataForm["__rev"] = dataFB["clientRevision"]
        dataForm["av"] = dataFB["FacebookID"]
    
    return dataForm

def mainRequests(url, data, cookies):
    """Build request parameters for Facebook API"""
    return {
        "headers": Headers(cookies, data),
        "timeout": 5,
        "url": url,
        "data": data,
        "cookies": parse_cookie_string(cookies),
        "verify": True
    }

# ============================================================================
# DATA EXTRACTION FUNCTIONS
# ============================================================================

def get_uid_fbdtsg(ck):
    try:
        headers = {
            'Accept': 'text/html',
            'Cookie': ck,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
        }
        response = requests.get('https://www.facebook.com/', headers=headers)
        html_content = response.text
        
        if "home_icon" not in html_content and '"USER_ID":"' not in html_content:
            return None, None, None, None, None, None
            
        user_id = re.search(r'"USER_ID":"(\d+)"', html_content)
        user_id = user_id.group(1) if user_id else None
        
        fb_dtsg_match = re.search(r'"f":"([^"]+)"', html_content)
        fb_dtsg = fb_dtsg_match.group(1) if fb_dtsg_match else None
        
        jazoest_match = re.search(r'jazoest=(\d+)', html_content)
        jazoest = jazoest_match.group(1) if jazoest_match else None
        
        revision_match = re.search(r'"server_revision":(\d+),"client_revision":(\d+)', html_content)
        rev = revision_match.group(1) if revision_match else ""
        
        a_match = re.search(r'__a=(\d+)', html_content)
        a = a_match.group(1) if a_match else "1"
        
        req = "1b"
        
        if not user_id or not fb_dtsg:
            return None, None, None, None, None, None
            
        return user_id, fb_dtsg, rev, req, a, jazoest
    except Exception as e:
        print(f"Lỗi Khi Check Cookie: {e}")
        return None, None, None, None, None, None

def dataGetHome(setCookies):
    """Extract Facebook data from home page"""
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36"
    ]
    
    dictValueSaved = {}
    
    try:
        c_user = re.search(r"c_user=(\d+)", setCookies)
        if c_user:
            dictValueSaved["FacebookID"] = c_user.group(1)
        else:
            dictValueSaved["FacebookID"] = "Unable to retrieve data for FacebookID. Cookie không hợp lệ."
    except:
        dictValueSaved["FacebookID"] = "Unable to retrieve data for FacebookID. It's possible that they have been deleted or modified."
    
    headers = {
        'Cookie': setCookies,
        'User-Agent': random.choice(user_agents),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1'
    }
    
    sites_to_try = ['https://www.facebook.com', 'https://mbasic.facebook.com', 'https://m.facebook.com']
    fb_dtsg_found = False
    jazoest_found = False
    
    params_to_extract = {
        "fb_dtsg": None,
        "fb_dtsg_ag": None,
        "jazoest": None,
        "hash": None,
        "sessionID": None,
        "clientRevision": None
    }
    
    for site in sites_to_try:
        if fb_dtsg_found and jazoest_found:
            break
        try:
            response = requests.get(site, headers=headers)
            
            if not fb_dtsg_found:
                fb_dtsg_match = re.search(r'"token":"(.*?)"', response.text)
                if not fb_dtsg_match:
                    fb_dtsg_match = re.search(r'name="fb_dtsg" value="(.*?)"', response.text)
                if fb_dtsg_match:
                    params_to_extract["fb_dtsg"] = fb_dtsg_match.group(1)
                    fb_dtsg_found = True
            
            if not jazoest_found:
                jazoest_match = re.search(r'jazoest=(\d+)', response.text)
                if jazoest_match:
                    params_to_extract["jazoest"] = jazoest_match.group(1)
                    jazoest_found = True
            
            fb_dtsg_ag_match = re.search(r'async_get_token":"(.*?)"', response.text)
            if fb_dtsg_ag_match:
                params_to_extract["fb_dtsg_ag"] = fb_dtsg_ag_match.group(1)
                
            hash_match = re.search(r'hash":"(.*?)"', response.text)
            if hash_match:
                params_to_extract["hash"] = hash_match.group(1)
                
            session_match = re.search(r'sessionId":"(.*?)"', response.text)
            if session_match:
                params_to_extract["sessionID"] = session_match.group(1)
                
            revision_match = re.search(r'client_revision":(\d+)', response.text)
            if revision_match:
                params_to_extract["clientRevision"] = revision_match.group(1)
                
        except Exception as e:
            continue
    
    for param, value in params_to_extract.items():
        if value:
            dictValueSaved[param] = value
        else:
            dictValueSaved[param] = f"Unable to retrieve data for {param}. It's possible that they have been deleted or modified."
    
    dictValueSaved["__rev"] = "1015919737"
    dictValueSaved["__req"] = "1b"
    dictValueSaved["__a"] = "1"
    dictValueSaved["cookieFacebook"] = setCookies
    
    return dictValueSaved

def upload_image_get_fbid(image_path_or_url: str, ck: str) -> str:
    user_id, fb_dtsg, rev, req, a, jazoest = get_uid_fbdtsg(ck)
    if not all([user_id, fb_dtsg, jazoest]):
        return "Không thể lấy thông tin từ cookie. Vui lòng kiểm tra lại."
    
    # Tải ảnh nếu là URL
    is_url = image_path_or_url.startswith("http://") or image_path_or_url.startswith("https://")
    try:
        if is_url:
            resp = requests.get(image_path_or_url)
            if resp.status_code != 200:
                return "Không thể tải ảnh từ URL."
            img_data = BytesIO(resp.content)
            img_data.name = "image.jpg"
        else:
            if not os.path.isfile(image_path_or_url):
                return "File không tồn tại. Hãy nhập đúng đường dẫn tới ảnh."
            img_data = open(image_path_or_url, 'rb')
    except Exception as e:
        return f"Lỗi khi đọc ảnh: {e}"
    
    headers = {
        'cookie': ck,
        'origin': 'https://www.facebook.com',
        'referer': 'https://www.facebook.com/',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64)',
        'x-fb-lsd': fb_dtsg,
    }
    
    params = {
        'av': user_id,
        'profile_id': user_id,
        'source': '19',
        'target_id': user_id,
        '__user': user_id,
        '__a': a,
        '__req': req,
        '__rev': rev,
        'fb_dtsg': fb_dtsg,
        'jazoest': jazoest,
    }
    
    try:
        files = {
            'file': (img_data.name, img_data, 'image/jpeg')
        }
        
        response = requests.post(
            'https://www.facebook.com/ajax/ufi/upload/',
            headers=headers,
            params=params,
            files=files
        )
        
        if is_url:
            img_data.close()
        
        text = response.text.strip()
        if text.startswith("for(;;);"):
            text = text[8:]
        
        try:
            data = json.loads(text)
            fbid = data.get("payload", {}).get("fbid")
            if fbid:
                return fbid
            return "Không tìm thấy fbid trong JSON."
        except json.JSONDecodeError:
            match = re.search(r'"fbid"\s*:\s*"(\d+)"', text)
            if match:
                return match.group(1)
            return "Không tìm thấy fbid trong text."
    except Exception as e:
        return f"Lỗi khi upload: {e}"

# ============================================================================
# FACEBOOK TOOLS CLASS
# ============================================================================

class fbTools:
    """Facebook tools for thread management and data extraction"""
    def __init__(self, dataFB, threadID="0"):
        self.threadID = threadID
        self.dataGet = None
        self.dataFB = dataFB
        self.ProcessingTime = None
        self.last_seq_id = None

    def getAllThreadList(self):
        """Get all thread list from Facebook"""
        randomNumber = str(int(format(int(time.time() * 1000), "b") + ("0000000000000000000000" + format(int(random.random() * 4294967295), "b"))[-22:], 2))
        
        dataForm = formAll(self.dataFB, requireGraphql=0)
        dataForm["queries"] = json.dumps({
            "o0": {
                "doc_id": "3336396659757871",
                "query_params": {
                    "limit": 20,
                    "before": None,
                    "tags": ["INBOX"],
                    "includeDeliveryReceipts": False,
                    "includeSeqID": True,
                }
            }
        })
        
        sendRequests = requests.post(**mainRequests("https://www.facebook.com/api/graphqlbatch/", dataForm, self.dataFB["cookieFacebook"]))
        response_text = sendRequests.text
        self.ProcessingTime = sendRequests.elapsed.total_seconds()
        
        if response_text.startswith("for(;;);"):
            response_text = response_text[9:]
        
        if not response_text.strip():
            print("Error: Empty response from Facebook API")
            return False
        
        try:
            response_parts = response_text.split("\n")
            first_part = response_parts[0]
            if first_part.strip():
                response_data = json.loads(first_part)
                self.dataGet = first_part
                if "o0" in response_data and "data" in response_data["o0"] and "viewer" in response_data["o0"]["data"] and "message_threads" in response_data["o0"]["data"]["viewer"]:
                    self.last_seq_id = response_data["o0"]["data"]["viewer"]["message_threads"]["sync_sequence_id"]
                    return True
                else:
                    print("Error: Expected fields not found in response")
                    return False
            else:
                print("Error: Empty first part of response")
                return False
        except json.JSONDecodeError as e:
            print(f"JSON Decode Error: {e}")
            print(f"Response first part: {response_parts[0][:100]}")
            return False
        except KeyError as e:
            print(f"Key Error: {e}")
            print("The expected data structure wasn't found in the response")
            return False
    
    def get_group_members(self, thread_id):
        """Lấy danh sách thành viên nhóm"""
        try:
            # Sử dụng formAll để tạo form data đúng cách từ dataFB
            form_data = formAll(self.dataFB, requireGraphql=0)
            form_data["queries"] = json.dumps({
                "o0": {
                    "doc_id": "3449967031715030",
                    "query_params": {
                        "id": thread_id,
                        "message_limit": 0,
                        "load_messages": False,
                        "load_read_receipts": False,
                        "before": None,
                    }
                }
            })
            
            # Sử dụng mainRequests để tạo request params với headers và cookies đúng
            response = requests.post(
                **mainRequests("https://www.facebook.com/api/graphqlbatch/", 
                              form_data, 
                              self.dataFB["cookieFacebook"])
            )
            response_text = response.text
            
            # Parse JSON response
            if response_text.startswith('for (;;);'):
                response_text = response_text[9:]
            elif response_text.startswith('for(;;);'):
                response_text = response_text[8:]
            
            if not response_text.strip():
                print("❌ Empty response from Facebook API")
                return None, []
            
            # Parse response - có thể có nhiều dòng JSON
            response_parts = response_text.split("\n")
            first_part = response_parts[0]
            
            if not first_part.strip():
                print("❌ Empty first part of response")
                return None, []
            
            data = json.loads(first_part)
            
            # Extract thread data
            thread_data = data.get("o0", {}).get("data", {}).get("message_thread", {})
            
            if not thread_data:
                print(f"❌ No thread data found in response for thread_id: {thread_id}")
                return None, []
            
            thread_name = thread_data.get("name", "Không tên")
            participants = thread_data.get("all_participants", {}).get("edges", [])
            
            members = []
            for p in participants:
                user = p.get("node", {}).get("messaging_actor", {})
                if user:
                    members.append({
                        "uid": user.get("id", ""),
                        "name": user.get("name", "Không rõ")
                    })
            
            print(f"✅ Got {len(members)} members from thread: {thread_name}")
            return thread_name, members
            
        except json.JSONDecodeError as e:
            print(f"❌ JSON decode error in get_group_members: {e}")
            if 'response_text' in locals():
                print(f"Response text preview: {response_text[:200]}")
            return None, []
        except Exception as e:
            print(f"❌ Lỗi get_group_members: {e}")
            import traceback
            traceback.print_exc()
            return None, []

    def typeCommand(self, commandUsed):
        """Execute various commands on thread data"""
        listData = []
        try:
            if self.dataGet is None:
                return "No data available. Make sure to call getAllThreadList first."
            
            data_to_parse = self.dataGet
            if data_to_parse.startswith("for(;;);"):
                data_to_parse = data_to_parse[9:]
            
            getData = json.loads(data_to_parse)["o0"]["data"]["viewer"]["message_threads"]["nodes"]
        except json.JSONDecodeError as e:
            return f"Failed to decode JSON response: {e}"
        except KeyError as e:
            try:
                error_data = json.loads(data_to_parse)["o0"]
                if "errors" in error_data:
                    return error_data["errors"][0]["summary"]
                else:
                    return f"Unexpected response structure. Missing key: {e}"
            except:
                return f"Unexpected response structure. Missing key: {e}"
        
        dataThread = None
        for getNeedIDThread in getData:
            thread_key = getNeedIDThread.get("thread_key", {})
            thread_fbid = thread_key.get("thread_fbid")
            if thread_fbid and str(thread_fbid) == str(self.threadID):
                dataThread = getNeedIDThread
                break
        
        if dataThread is not None:
            if commandUsed == "getAdmin":
                for dataID in dataThread.get("thread_admins", []):
                    listData.append(str(dataID["id"]))
                exportData = {
                    "adminThreadList": listData
                }
            elif commandUsed == "threadInfomation":
                threadInfoList = dataThread.get("customization_info", {})
                exportData = {
                    "nameThread": dataThread.get("name"),
                    "IDThread": self.threadID,
                    "emojiThread": threadInfoList.get("emoji"),
                    "messageCount": dataThread.get("messages_count"),
                    "adminThreadCount": len(dataThread.get("thread_admins", [])),
                    "memberCount": len(dataThread.get("all_participants", {}).get("edges", [])),
                    "approvalMode": "Bật" if (dataThread.get("approval_mode", 0) != 0) else "Tắt",
                    "joinableMode": "Bật" if (dataThread.get("joinable_mode", {}).get("mode") != "0") else "Tắt",
                    "urlJoinableThread": dataThread.get("joinable_mode", {}).get("link", "")
                }
            elif commandUsed == "exportMemberListToJson":
                getMemberList = dataThread.get("all_participants", {}).get("edges", [])
                for exportMemberList in getMemberList:
                    node = exportMemberList.get("node", {})
                    dataUserThread = node.get("messaging_actor", {})
                    if dataUserThread:
                        exportData = json.dumps({
                            dataUserThread.get("id", ""): {
                                "nameFB": str(dataUserThread.get("name", "")),
                                "idFacebook": str(dataUserThread.get("id", "")),
                                "profileUrl": str(dataUserThread.get("url", "")),
                                "avatarUrl": str(dataUserThread.get("big_image_src", {}).get("uri", "")),
                                "gender": str(dataUserThread.get("gender", "")),
                                "usernameFB": str(dataUserThread.get("username", ""))
                            }
                        }, skipkeys=True, allow_nan=True, ensure_ascii=False, indent=5)
                        listData.append(exportData)
                exportData = listData
            else:
                exportData = {
                    "err": "no data"
                }
            return exportData
        else:
            return "Không lấy được dữ liệu ThreadList, đã xảy ra lỗi T___T"

    def getListThreadID(self):
        """Get list of thread IDs and names"""
        try:
            if self.dataGet is None:
                return {
                    "ERR": "No data available. Make sure to call getAllThreadList first."
                }
            
            data_to_parse = self.dataGet
            if data_to_parse.startswith("for(;;);"):
                data_to_parse = data_to_parse[9:]
            
            threadIDList = []
            threadNameList = []
            
            try:
                getData = json.loads(data_to_parse)["o0"]["data"]["viewer"]["message_threads"]["nodes"]
                for getThreadID in getData:
                    thread_key = getThreadID.get("thread_key", {})
                    thread_fbid = thread_key.get("thread_fbid")
                    if thread_fbid is not None:
                        threadIDList.append(thread_fbid)
                        threadNameList.append(getThreadID.get("name", "No Name"))
                
                return {
                    "threadIDList": threadIDList,
                    "threadNameList": threadNameList,
                    "countThread": len(threadIDList)
                }
            except (KeyError, json.JSONDecodeError) as e:
                return {
                    "ERR": f"Error processing thread data: {str(e)}"
                }
        except Exception as errLog:
            return {
                "ERR": f"Unexpected error: {str(errLog)}"
            }


# ============================================================================
# THEMES DATA
# ============================================================================

THEMES = [
    {"id": "3650637715209675", "name": "Besties"},
    {"id": "769656934577391", "name": "Women's History Month"},
    {"id": "702099018755409", "name": "Dune: Part Two"},
    {"id": "1480404512543552", "name": "Avatar: The Last Airbender"},
    {"id": "952656233130616", "name": "J.Lo"},
    {"id": "741311439775765", "name": "Love"},
    {"id": "215565958307259", "name": "Bob Marley: One Love"},
    {"id": "194982117007866", "name": "Football"},
    {"id": "1743641112805218", "name": "Soccer"},
    {"id": "730357905262632", "name": "Mean Girls"},
    {"id": "1270466356981452", "name": "Wonka"},
    {"id": "704702021720552", "name": "Pizza"},
    {"id": "1013083536414851", "name": "Wish"},
    {"id": "359537246600743", "name": "Trolls"},
    {"id": "173976782455615", "name": "The Marvels"},
    {"id": "2317258455139234", "name": "One Piece"},
    {"id": "6685081604943977", "name": "1989"},
    {"id": "1508524016651271", "name": "Avocado"},
    {"id": "265997946276694", "name": "Loki Season 2"},
    {"id": "6584393768293861", "name": "olivia rodrigo"},
    {"id": "845097890371902", "name": "Baseball"},
    {"id": "292955489929680", "name": "Lollipop"},
    {"id": "976389323536938", "name": "Loops"},
    {"id": "810978360551741", "name": "Parenthood"},
    {"id": "195296273246380", "name": "Bubble Tea"},
    {"id": "6026716157422736", "name": "Basketball"},
    {"id": "693996545771691", "name": "Elephants & Flowers"},
    {"id": "390127158985345", "name": "Chill"},
    {"id": "365557122117011", "name": "Support"},
    {"id": "339021464972092", "name": "Music"},
    {"id": "1060619084701625", "name": "Lo-Fi"},
    {"id": "3190514984517598", "name": "Sky"},
    {"id": "627144732056021", "name": "Celebration"},
    {"id": "275041734441112", "name": "Care"},
    {"id": "3082966625307060", "name": "Astrology"},
    {"id": "539927563794799", "name": "Cottagecore"},
    {"id": "527564631955494", "name": "Ocean"},
    {"id": "230032715012014", "name": "Tie-Dye"},
    {"id": "788274591712841", "name": "Monochrome"},
    {"id": "3259963564026002", "name": "Default"},
    {"id": "724096885023603", "name": "Berry"},
    {"id": "624266884847972", "name": "Candy"},
    {"id": "273728810607574", "name": "Unicorn"},
    {"id": "262191918210707", "name": "Tropical"},
    {"id": "2533652183614000", "name": "Maple"},
    {"id": "909695489504566", "name": "Sushi"},
    {"id": "582065306070020", "name": "Rocket"},
    {"id": "557344741607350", "name": "Citrus"},
    {"id": "280333826736184", "name": "Lollipop"},
    {"id": "271607034185782", "name": "Shadow"},
    {"id": "1257453361255152", "name": "Rose"},
    {"id": "571193503540759", "name": "Lavender"},
    {"id": "2873642949430623", "name": "Tulip"},
    {"id": "3273938616164733", "name": "Classic"},
    {"id": "403422283881973", "name": "Apple"},
    {"id": "3022526817824329", "name": "Peach"},
    {"id": "672058580051520", "name": "Honey"},
    {"id": "3151463484918004", "name": "Kiwi"},
    {"id": "736591620215564", "name": "Ocean"},
    {"id": "193497045377796", "name": "Grape"}
]

# ============================================================================
# MAIN FACEBOOK MQTT ALL-IN-ONE CLIENT
# ============================================================================

class FacebookMQTTAllInOne:
    """Facebook MQTT All-in-One Client với tất cả tính năng"""
    
    def __init__(self, cookies: str, options: dict = None):
        """
        Initialize Facebook MQTT All-in-One client
        
        Args:
            cookies (str): Facebook cookies string
            options (dict): Configuration options
        """
        self.cookies = cookies
        self.dataFB = dataGetHome(cookies)
        self.user_id = self._extract_user_id()
        self.mqtt_client = None
        self.connected = False
        self.req_callbacks = {}
        self.ws_task_number = 0
        self.ws_req_number = 0
        self.last_seq_id = None
        self.sync_token = None
        
        # Default options
        default_options = {
            "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
            "online": True,
            "debug": False,
            "self_listen": False,
            "listen_events": True,
            "update_presence": False,
        }
        
        if options:
            default_options.update(options)
        self.options = default_options
        
        # Initialize fbTools
        self.fb_tools = fbTools(self.dataFB)
        
        print(f"🚀 Facebook MQTT All-in-One initialized for user: {self.user_id}")

    def _extract_user_id(self):
        """Extract user ID from cookies"""
        cookie_dict = parse_cookie_string(self.cookies)
        user_id = cookie_dict.get("c_user")
        if not user_id:
            raise ValueError("Không thể lấy user ID từ cookies!")
        return user_id

    def _get_seq_id(self):
        """Get sequence ID from Facebook"""
        try:
            if self.fb_tools.getAllThreadList():
                self.last_seq_id = self.fb_tools.last_seq_id
                if self.options["debug"]:
                    print(f"Got sequence ID: {self.last_seq_id}")
                return True
            else:
                raise Exception("Failed to get thread list")
        except Exception as e:
            raise Exception(f"Failed to get sequence ID: {str(e)}")

    def connect(self):
        """Connect to Facebook MQTT server"""
        if self.connected:
            print("✅ Already connected to MQTT")
            return True
            
        print("🔌 Connecting to Facebook MQTT...")
        
        # Get sequence ID first
        self._get_seq_id()
        
        session_id = generate_session_id()
        client_id = generate_client_id()
        
        user = {
            "a": self.options["user_agent"],
            "u": self.user_id,
            "s": session_id,
            "chat_on": self.options["online"],
            "fg": False,
            "d": client_id,
            "ct": "websocket",
            "aid": "219994525426954", # Facebook app ID
            "mqtt_sid": "",
            "cp": 3,
            "ecp": 10,
            "st": [],
            "pm": [],
            "dc": "",
            "no_auto_fg": True,
            "gas": None,
            "pack": [],
        }
        
        host = f"wss://edge-chat.facebook.com/chat?sid={session_id}&cid={client_id}"
        
        # Parse cookies for headers
        cookie_dict = parse_cookie_string(self.cookies)
        cookie_str = "; ".join([f"{k}={v}" for k, v in cookie_dict.items()])
        
        # MQTT client options
        mqtt_options = {
            "client_id": "mqttwsclient",
            "username": json_minimal(user),
            "clean": True,
            "ws_options": {
                "headers": {
                    "Cookie": cookie_str,
                    "Origin": "https://www.facebook.com",
                    "User-Agent": self.options["user_agent"],
                    "Referer": "https://www.facebook.com/",
                    "Host": "edge-chat.facebook.com",
                },
            },
            "keepalive": 10,
        }
        
        # Create MQTT client
        self.mqtt_client = mqtt.Client(
            client_id=mqtt_options["client_id"],
            clean_session=mqtt_options["clean"],
            protocol=mqtt.MQTTv31,
            transport="websockets",
        )
        
        # SSL configuration
        self.mqtt_client.tls_set(
            certfile=None,
            keyfile=None,
            cert_reqs=ssl.CERT_NONE,
            tls_version=ssl.PROTOCOL_TLSv1_2
        )
        self.mqtt_client.tls_insecure_set(True)
        
        # Set callbacks
        self.mqtt_client.on_connect = self._on_connect
        self.mqtt_client.on_message = self._on_message
        self.mqtt_client.on_disconnect = self._on_disconnect
        
        # Set username
        self.mqtt_client.username_pw_set(username=mqtt_options["username"])
        
        # Parse host for WebSocket options
        parsed_host = urlparse(host)
        self.mqtt_client.ws_set_options(
            path=f"{parsed_host.path}?{parsed_host.query}",
            headers=mqtt_options["ws_options"]["headers"],
        )
        
        # Connect
        try:
            self.mqtt_client.connect(
                host=mqtt_options["ws_options"]["headers"]["Host"],
                port=443,
                keepalive=mqtt_options["keepalive"],
            )
            
            # Start loop in background
            self.mqtt_client.loop_start()
            
            # Wait for connection
            timeout = 15
            start_time = time.time()
            while not self.connected and (time.time() - start_time) < timeout:
                time.sleep(0.1)
                
            if not self.connected:
                raise Exception("Failed to connect to MQTT within timeout")
                
            print("✅ Successfully connected to Facebook MQTT!")
            return True
            
        except Exception as e:
            print(f"❌ Failed to connect to MQTT: {e}")
            return False

    def _on_connect(self, client: mqtt.Client, userdata, flags, rc):
        """MQTT connection callback"""
        if rc == 0:
            print(f"📡 MQTT Connected with result code {rc}")
            self.connected = True
            
            # Subscribe to necessary topics
            topics = [
                "/ls_resp",
                "/thread_typing", 
                "/orca_typing_notifications",
                "/t_ms",
                "/mercury",
                "/messaging_events",
                "/inbox",
                "/pp",  # presence
                "/webrtc",
                "/legacy_web",
                "/br_sr",  # browser events
                "/sr_res",
            ]
            
            for topic in topics:
                client.subscribe(topic, qos=1)
                
            # Send app settings
            client.publish(
                topic="/ls_app_settings",
                payload=json_minimal({
                    "ls_fdid": "",
                    "ls_sv": "6928813347213944"
                }),
                qos=1,
                retain=False,
            )
            
            # Create initial sync queue
            self._create_sync_queue(self.last_seq_id)
            print(f"✅ Sync queue requested with seq_id: {self.last_seq_id}")
            
        else:
            print(f"❌ MQTT connection failed with code {rc}")
            self.connected = False

    def _on_message(self, client, userdata, msg: mqtt.MQTTMessage):
        """MQTT message callback"""
        try:
            payload_str = msg.payload.decode("utf-8")
            if payload_str.startswith("{"):
                parsed = json.loads(payload_str)
            else:
                parsed = {"t": payload_str}
            
            # Handle different message topics
            if msg.topic == "/ls_resp":
                self._handle_ls_resp(parsed)
            elif msg.topic in ["/thread_typing", "/orca_typing_notifications"]:
                if self.options["debug"]:
                    print(f"👀 Typing notification: {parsed}")
            elif msg.topic == "/t_ms":
                self._handle_t_ms(parsed)
            elif msg.topic in ["/mercury", "/messaging_events"]:
                if self.options["debug"]:
                    print(f"📨 Message event: {parsed}")
                    
        except Exception as e:
            if self.options["debug"]:
                print(f"Error processing message from {msg.topic}: {e}")

    def _handle_ls_resp(self, parsed):
        """Handle /ls_resp messages"""
        # Check for sync sequence ID in response
        if "payload" in parsed:
            try:
                payload_data = json.loads(parsed["payload"]) if isinstance(parsed["payload"], str) else parsed["payload"]
                
                # Look for sequence ID in various places
                if "sync_sequence_id" in payload_data:
                    new_seq_id = payload_data["sync_sequence_id"]
                    print(f"📌 Got seq_id from LS response: {new_seq_id}")
                    if new_seq_id != self.last_seq_id:
                        self.last_seq_id = new_seq_id
                        self._create_sync_queue(new_seq_id)
                        
                if "lastSeqId" in payload_data:
                    new_seq_id = payload_data["lastSeqId"]
                    print(f"📌 Got lastSeqId from LS response: {new_seq_id}")
            except:
                pass
        
        if "request_id" in parsed and parsed["request_id"] in self.req_callbacks:
            callback = self.req_callbacks[parsed["request_id"]]
            
            # Parse response payload
            if "payload" in parsed:
                try:
                    response_payload = json.loads(parsed["payload"])
                    
                    # Check for errors
                    if "error" in response_payload:
                        error_msg = response_payload["error"].get("description", "Unknown error")
                        callback(None, error_msg)
                    else:
                        # Success - extract result info
                        result = {"success": True}
                        
                        if "actions" in response_payload:
                            for action in response_payload["actions"]:
                                if "message_id" in action:
                                    result["message_id"] = action["message_id"]
                                if "thread_fbid" in action:
                                    result["thread_id"] = action["thread_fbid"]
                                    
                        callback(result, None)
                        
                except json.JSONDecodeError:
                    callback({"success": True}, None)
            else:
                callback({"success": True}, None)
                
            # Remove callback
            del self.req_callbacks[parsed["request_id"]]

    def _handle_t_ms(self, parsed):
        """Handle /t_ms messages for sync and new messages"""
        if self.options.get("debug"):
            print(f"📥 /t_ms received: {str(parsed)[:300]}...")
        
        # Handle queue errors
        error_code = parsed.get("errorCode")
        if error_code in ["ERROR_QUEUE_OVERFLOW", "ERROR_QUEUE_UNDERFLOW"]:
            # Rate limit refresh attempts
            current_time = time.time()
            if not hasattr(self, '_last_refresh_time'):
                self._last_refresh_time = 0
                self._refresh_count = 0
            
            if current_time - self._last_refresh_time < 30:
                self._refresh_count += 1
                if self._refresh_count > 3:
                    print(f"⚠️ Too many retry attempts, will try again later...")
                    return
            else:
                self._refresh_count = 0
            
            self._last_refresh_time = current_time
            
            # Extract new sequence ID from error payload
            new_seq_id = None
            for key in ["lastSeqId", "newLastSeqId", "firstDeltaSeqId", "lastIssuedSeqId"]:
                if key in parsed:
                    new_seq_id = parsed[key]
                    print(f"📌 Found {key}: {new_seq_id}")
                    break
            
            if new_seq_id:
                if error_code == "ERROR_QUEUE_OVERFLOW":
                    print(f"⚠️ Queue overflow - retrying with seq_id: {new_seq_id}")
                    self._create_sync_queue(new_seq_id)
                elif error_code == "ERROR_QUEUE_UNDERFLOW":
                    print("⚠️ Queue underflow - seq_id too high, using original...")
                    self._create_sync_queue(self.last_seq_id)
            else:
                # No sequence ID in payload - try fetching fresh one via API
                print(f"⚠️ Queue {error_code} - fetching fresh seq_id...")
                fresh_seq_id = self._fetch_inbox_seq_id()
                if fresh_seq_id:
                    print(f"📌 Got fresh seq_id from inbox: {fresh_seq_id}")
                    self._create_sync_queue(fresh_seq_id)
                else:
                    print(f"⚠️ Could not get fresh seq_id, waiting...")
            return
            
        if "firstDeltaSeqId" in parsed and "syncToken" in parsed:
            self.last_seq_id = parsed["firstDeltaSeqId"]
            self.sync_token = parsed["syncToken"]
            if self.options.get("debug"):
                print(f"✅ Got sync token, seq_id: {self.last_seq_id}")
            
        if "lastIssuedSeqId" in parsed:
            self.last_seq_id = parsed["lastIssuedSeqId"]
        
        # Process deltas for new messages
        if "deltas" in parsed:
            if self.options.get("debug"):
                print(f"📦 Found {len(parsed['deltas'])} deltas")
            for delta in parsed.get("deltas", []):
                self._process_delta(delta)
    
    def _create_sync_queue(self, seq_id):
        """Create a new sync queue with given sequence ID"""
        try:
            queue = {
                "sync_api_version": 10,
                "max_deltas_able_to_process": 100,
                "delta_batch_size": 50,
                "encoding": "JSON",
                "entity_fbid": self.user_id,
                "initial_titan_sequence_id": str(seq_id),
                "device_params": None
            }
            
            self.mqtt_client.publish(
                topic="/messenger_sync_create_queue",
                payload=json_minimal(queue),
                qos=1,
                retain=False,
            )
            print(f"📡 Sync queue create request sent with seq_id: {seq_id}")
        except Exception as e:
            print(f"❌ Error creating sync queue: {e}")
    
    def _fetch_inbox_seq_id(self):
        """Fetch fresh sequence ID and sync token using MessengerInboxSyncQuery"""
        try:
            # Use MessengerInboxSyncQuery to get fresh sync data
            form_data = {
                "fb_dtsg": self.dataFB.get("fb_dtsg"),
                "jazoest": self.dataFB.get("jazoest"),
                "__a": 1,
                "__user": str(self.user_id),
                "doc_id": "6545310025662669",  # MessengerInboxSyncQuery
                "variables": json.dumps({
                    "input": {
                        "client_mutation_id": "1",
                        "actor_id": str(self.user_id),
                    }
                })
            }
            
            response = requests.post(
                "https://www.facebook.com/api/graphql/",
                data=form_data,
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Cookie": self.cookies,
                    "User-Agent": self.options.get("user_agent", "Mozilla/5.0")
                },
                timeout=15
            )
            
            if response.status_code != 200:
                print(f"InboxSync API returned {response.status_code}")
                return None
            
            text = response.text
            if text.startswith("for (;;);"):
                text = text[9:]
            elif text.startswith("for(;;);"):
                text = text[8:]
            
            if text.strip():
                data = json.loads(text)
                
                # Try to find sequence ID in various places
                def find_seq_id(obj):
                    if isinstance(obj, dict):
                        for key in ["sync_sequence_id", "sequence_id", "lastSeqId", "seqId"]:
                            if key in obj:
                                return obj[key]
                        for v in obj.values():
                            result = find_seq_id(v)
                            if result:
                                return result
                    elif isinstance(obj, list):
                        for item in obj:
                            result = find_seq_id(item)
                            if result:
                                return result
                    return None
                
                seq_id = find_seq_id(data)
                if seq_id:
                    print(f"📌 Found seq_id from InboxSync: {seq_id}")
                    return seq_id
                
                # Debug: print structure
                print(f"📋 InboxSync response structure: {str(data)[:500]}...")
            
            return None
        except Exception as e:
            print(f"Error fetching inbox seq_id: {e}")
            return None
    
    def _get_fresh_seq_id(self):
        """Get fresh sequence ID directly from Facebook API"""
        try:
            form_data = {
                "fb_dtsg": self.dataFB.get("fb_dtsg"),
                "jazoest": self.dataFB.get("jazoest"),
                "__a": 1,
                "__user": str(self.user_id),
                "__req": "fresh",
                "__rev": self.dataFB.get("clientRevision", ""),
                "queries": json.dumps({
                    "o0": {
                        "doc_id": "3336396659757871",
                        "query_params": {
                            "limit": 1,
                            "before": None,
                            "tags": ["INBOX"],
                            "includeDeliveryReceipts": False,
                            "includeSeqID": True,
                        }
                    }
                })
            }
            
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "Cookie": self.cookies,
                "User-Agent": self.options.get("user_agent", "Mozilla/5.0")
            }
            
            response = requests.post(
                "https://www.facebook.com/api/graphqlbatch/",
                data=form_data,
                headers=headers,
                timeout=15
            )
            
            if response.status_code != 200:
                return None
            
            response_text = response.text
            if response_text.startswith("for(;;);"):
                response_text = response_text[9:]
            
            response_parts = response_text.split("\n")
            first_part = response_parts[0]
            
            if first_part.strip():
                response_data = json.loads(first_part)
                if ("o0" in response_data and "data" in response_data["o0"] and 
                    "viewer" in response_data["o0"]["data"] and 
                    "message_threads" in response_data["o0"]["data"]["viewer"]):
                    return response_data["o0"]["data"]["viewer"]["message_threads"]["sync_sequence_id"]
            
            return None
        except Exception as e:
            print(f"Error getting fresh seq_id: {e}")
            return None
    
    def _process_delta(self, delta):
        """Process a single delta message"""
        try:
            delta_class = delta.get("class")
            
            if delta_class == "NewMessage":
                self._handle_new_message(delta)
            elif delta_class == "ClientPayload":
                # Handle client payload (contains message data)
                if "payload" in delta:
                    try:
                        payload = json.loads(delta["payload"]) if isinstance(delta["payload"], str) else delta["payload"]
                        if "deltas" in payload:
                            for sub_delta in payload["deltas"]:
                                self._process_delta(sub_delta)
                    except:
                        pass
        except Exception as e:
            if self.options.get("debug"):
                print(f"Error processing delta: {e}")
    
    def _handle_new_message(self, delta):
        """Handle new message delta"""
        try:
            meta = delta.get("messageMetadata", {})
            thread_key = meta.get("threadKey", {})
            thread_id = thread_key.get("threadFbId") or thread_key.get("otherUserFbId")
            sender_id = meta.get("actorFbId")
            message_id = meta.get("messageId")
            body = delta.get("body", "")

            # ── Trích xuất thông tin tin nhắn được reply ──────────────────────
            reply_to_sender_id = None
            reply_to_message_id = None

            # Thử các trường khác nhau mà FB MQTT có thể dùng
            for key in ("replyToMessageId", "reply_to_message_id",
                        "replied_to_message_id", "replyMessageId"):
                if delta.get(key):
                    reply_to_message_id = delta[key]
                    break

            replied_meta = (
                delta.get("repliedToMessage", {}) or
                delta.get("reply_to", {}) or
                delta.get("replyToMessage", {}) or {}
            )
            if replied_meta:
                replied_inner_meta = replied_meta.get("messageMetadata", {})
                reply_to_sender_id = (
                    replied_meta.get("actorFbId") or
                    replied_inner_meta.get("actorFbId") or
                    replied_meta.get("sender_id") or
                    replied_meta.get("senderId")
                )
                if not reply_to_message_id:
                    reply_to_message_id = (
                        replied_inner_meta.get("messageId") or
                        replied_meta.get("messageId") or
                        replied_meta.get("message_id")
                    )

            # Fallback: kiểm tra trong tags của delta
            tags = delta.get("tags", [])
            if isinstance(tags, list):
                for tag in tags:
                    if isinstance(tag, str) and tag.startswith("reply:"):
                        parts = tag.split(":")
                        if len(parts) >= 2:
                            reply_to_message_id = parts[1]
            # ────────────────────────────────────────────────────────────────

            # ── Trích xuất mentions (UID được @tag) ──────────────────────────
            mentions = []
            mention_data = delta.get("mentionData") or delta.get("mention_data") or {}
            if mention_data:
                ids_str = mention_data.get("mention_ids", "")
                if ids_str:
                    mentions = [uid.strip() for uid in str(ids_str).split(",") if uid.strip()]
            if not mentions:
                for key in ("mentionIDs", "mention_ids", "taggedUserFbIds"):
                    raw = meta.get(key) or delta.get(key)
                    if raw:
                        if isinstance(raw, list):
                            mentions = [str(x) for x in raw if x]
                        elif isinstance(raw, str):
                            mentions = [x.strip() for x in raw.split(",") if x.strip()]
                        break
            # ────────────────────────────────────────────────────────────────

            # Create message event
            message_event = {
                "type": "message",
                "thread_id": str(thread_id) if thread_id else None,
                "sender_id": str(sender_id) if sender_id else None,
                "message_id": message_id,
                "body": body,
                "timestamp": meta.get("timestamp"),
                "is_group": thread_key.get("threadFbId") is not None,
                # Thông tin reply (nếu có)
                "reply_to_sender_id": str(reply_to_sender_id) if reply_to_sender_id else None,
                "reply_to_message_id": reply_to_message_id,
                # Danh sách UID được @tag trong tin nhắn này
                "mentions": mentions,
            }
            
            # Call message callback if set
            if hasattr(self, 'on_message_callback') and self.on_message_callback:
                self.on_message_callback(message_event)
                
        except Exception as e:
            if self.options.get("debug"):
                print(f"Error handling new message: {e}")
    
    def set_message_callback(self, callback):
        """Set callback function for incoming messages"""
        self.on_message_callback = callback

    def _on_disconnect(self, client, userdata, rc):
        """MQTT disconnect callback"""
        print(f"📡 MQTT Disconnected with result code {rc}")
        self.connected = False
        
        if rc != 0:
            print("🔄 Unexpected disconnection, attempting to reconnect...")

    def disconnect(self):
        """Disconnect from MQTT server"""
        if self.mqtt_client and self.connected:
            self.mqtt_client.loop_stop()
            self.mqtt_client.disconnect()
            self.connected = False
            print("👋 Disconnected from Facebook MQTT")

    # ========================================================================
    # MESSAGE SENDING FUNCTIONS
    # ========================================================================
    
    def send_message(self, text: str = None, thread_id: str = None, 
                    mention: Union[dict, List[dict]] = None,
                    attachment: Union[BufferedReader, tuple, List] = None,
                    message_id: str = None, callback: Callable = None):
        """
        Send message via MQTT
        
        Args:
            text (str): Text message to send
            thread_id (str): Thread ID to send message to  
            mention (dict|list): Mention data for tagging users
            attachment: File attachments (not implemented in MQTT version)
            message_id (str): Reply to message ID
            callback (callable): Callback function for response
        """
        if not self.connected:
            raise ValueError("❌ Not connected to MQTT. Call connect() first.")
            
        if thread_id is None:
            raise ValueError("❌ thread_id is required")
            
        if text is None and attachment is None:
            raise ValueError("❌ text or attachment required")
            
        self.ws_req_number += 1
        self.ws_task_number += 1
        
        # Create message task
        task_payload = {
            "initiating_source": 0,
            "multitab_env": 0,
            "otid": generate_offline_threading_id(),
            "send_type": 1,
            "skip_url_preview_gen": 0,
            "source": 0,
            "sync_group": 1,
            "text": str(text) if text else "",
            "text_has_links": 0,
            "thread_id": int(thread_id),
        }
        
        # Handle reply
        if message_id:
            task_payload["reply_metadata"] = {
                "reply_source_id": message_id,
                "reply_source_type": 1,
                "reply_type": 0,
            }
        
        # Handle mentions
        if mention and text:
            valid_mentions = self._get_valid_mentions(text, mention)
            if valid_mentions:
                task_payload["mention_data"] = {
                    "mention_ids": ",".join([str(x["i"]) for x in valid_mentions]),
                    "mention_lengths": ",".join([str(x["l"]) for x in valid_mentions]),
                    "mention_offsets": ",".join([str(x["o"]) for x in valid_mentions]),
                    "mention_types": ",".join(["p" for _ in valid_mentions]),
                }
        
        task = {
            "failure_count": None,
            "label": "46",
            "payload": json_minimal(task_payload),
            "queue_name": str(thread_id),
            "task_id": self.ws_task_number,
        }
        
        # Create mark read task
        self.ws_task_number += 1
        task_mark_payload = {
            "last_read_watermark_ts": int(time.time() * 1000),
            "sync_group": 1,
            "thread_id": int(thread_id),
        }
        
        task_mark = {
            "failure_count": None,
            "label": "21",
            "payload": json_minimal(task_mark_payload),
            "queue_name": str(thread_id),
            "task_id": self.ws_task_number,
        }
        
        # Create final content
        content = {
            "app_id": "2220391788200892",
            "payload": {
                "data_trace_id": None,
                "epoch_id": int(generate_offline_threading_id()),
                "tasks": [task, task_mark],
                "version_id": "7545284305482586",
            },
            "request_id": self.ws_req_number,
            "type": 3,
        }
        
        content["payload"] = json_minimal(content["payload"])
        
        # Register callback
        if callback:
            self.req_callbacks[self.ws_req_number] = callback
            
        # Send via MQTT
        try:
            self.mqtt_client.publish(
                topic="/ls_req",
                payload=json_minimal(content),
                qos=1,
                retain=False,
            )
            
            if self.options["debug"]:
                print(f"📤 Message sent with request_id: {self.ws_req_number}")
                
            return self.ws_req_number
            
        except Exception as e:
            if self.ws_req_number in self.req_callbacks:
                del self.req_callbacks[self.ws_req_number]
            raise Exception(f"❌ Failed to send message: {str(e)}")

    def _get_valid_mentions(self, text: str, mention: Union[dict, List[dict]]) -> list:
        """Get valid mentions from text and mention data"""
        if not isinstance(mention, dict) and not isinstance(mention, list):
            return []
            
        mentions = mention if isinstance(mention, list) else [mention]
        valid_mentions = []
        
        for m in mentions:
            if "id" not in m:
                continue
                
            # Support both "tag" format and "offset"/"length" format
            if "tag" in m:
                provided_offset = m.get("offset")
                tag_len = 0
                
                if isinstance(provided_offset, int):
                    if provided_offset >= len(text):
                        break
                    is_length_exceed = provided_offset + len(m["tag"]) > len(text)
                    tag_len = (
                        len(m["tag"])
                        if not is_length_exceed
                        else len(text) - provided_offset
                    )
                    current_offset = provided_offset
                else:
                    find = text.find(m["tag"])
                    if find != -1:
                        is_length_exceed = find + len(m["tag"]) > len(text)
                        tag_len = (
                            len(m["tag"])
                            if not is_length_exceed
                            else len(text) - find
                        )
                        current_offset = find
                
                if tag_len > 0:
                    valid_mentions.append({
                        "i": m["id"],
                        "o": current_offset,
                        "l": tag_len,
                    })
            
            # Also support direct offset/length format (used by ghepdoi module)
            elif "offset" in m and "length" in m:
                offset = m.get("offset", 0)
                length = m.get("length", 0)
                if 0 <= offset < len(text) and length > 0:
                    valid_mentions.append({
                        "i": m["id"],
                        "o": offset,
                        "l": length,
                    })
                    
        return valid_mentions

    # ========================================================================
    # TYPING INDICATOR FUNCTIONS
    # ========================================================================
    
    def send_typing_indicator(self, thread_id: str, is_typing: bool, callback=None):
        """
        Send typing indicator to specified thread
        
        Args:
            thread_id (str): Thread ID to send typing indicator to
            is_typing (bool): True if typing, False if stopped typing
            callback (callable, optional): Callback function for response
        """
        if not self.connected:
            raise Exception('❌ Not connected to MQTT')
            
        self.ws_req_number += 1
        
        try:
            # Get thread info to determine if it's a group
            thread_data = self._get_thread_info(thread_id)
            
            # Prepare task payload
            label = '3'
            is_group_thread = 1 if thread_data.get("isGroup", False) else 0
            attribution = 0
            
            task_payload = {
                "thread_key": thread_id,
                "is_group_thread": is_group_thread,
                "is_typing": 1 if is_typing else 0,
                "attribution": attribution,
            }
            
            payload = json.dumps(task_payload)
            version = '25393437286970779'
            
            content = {
                "app_id": '2220391788200892',
                "payload": json.dumps({
                    "label": label,
                    "payload": payload,
                    "version": version,
                }),
                "request_id": self.ws_req_number,
                "type": 4,
            }
            
            # Store callback if provided
            if callback and callable(callback):
                self.req_callbacks[self.ws_req_number] = callback
                
            # Publish to MQTT
            self.mqtt_client.publish(
                topic='/ls_req',
                payload=json.dumps(content),
                qos=1,
                retain=False
            )
            
            return True
            
        except Exception as e:
            print(f"❌ Error sending typing indicator: {e}")
            raise Exception(f'Failed to send typing indicator: {str(e)}')

    def _get_thread_info(self, thread_id: str) -> dict:
        """
        Get thread information using fbTools
        
        Args:
            thread_id (str): Thread ID to get info for
            
        Returns:
            dict: Thread information including isGroup status
        """
        try:
            fb_tools = fbTools(self.dataFB, thread_id)
            if fb_tools.getAllThreadList():
                thread_info = fb_tools.typeCommand("threadInfomation")
                if thread_info and not isinstance(thread_info, str):
                    member_count = thread_info.get("memberCount", 0)
                    is_group = member_count > 2
                    return {
                        "isGroup": is_group,
                        "threadInfo": thread_info
                    }
            
            # Fallback: assume single chat if thread_id equals user_id
            return {
                "isGroup": thread_id != self.user_id,
                "threadInfo": None
            }
        except Exception:
            return {
                "isGroup": thread_id != self.user_id,
                "threadInfo": None
            }

    def send_typing_forever(self, thread_id: str, interval: float = 3.0):
        """
        Send typing indicator forever with interval
        
        Args:
            thread_id (str): Thread ID to send typing indicator to
            interval (float): Interval between typing signals in seconds
        """
        if not self.connected:
            raise Exception('❌ Not connected to MQTT')
            
        print(f"🔥 Starting infinite typing spam for thread {thread_id} every {interval}s...")
        print("Press Ctrl+C to stop")
        
        try:
            while True:
                self.send_typing_indicator(thread_id, True)
                print(f"⌨️ Sent typing signal at {time.strftime('%H:%M:%S')}")
                time.sleep(interval)
                
        except KeyboardInterrupt:
            print("\n🛑 Stopping infinite typing...")
            self.send_typing_indicator(thread_id, False)
            print("✅ Stopped typing indicator")
        except Exception as e:
            print(f"❌ Error in infinite typing: {e}")
            try:
                self.send_typing_indicator(thread_id, False)
            except:
                pass

    def send_typing_burst(self, thread_id: str, count: int = 10, interval: float = 1.0):
        """
        Send typing indicator burst (multiple times)
        
        Args:
            thread_id (str): Thread ID to send typing indicator to
            count (int): Number of typing signals to send
            interval (float): Interval between signals in seconds
        """
        if not self.connected:
            raise Exception('❌ Not connected to MQTT')
            
        print(f"💥 Starting typing burst: {count} signals every {interval}s for thread {thread_id}")
        
        try:
            for i in range(count):
                self.send_typing_indicator(thread_id, True)
                print(f"⌨️ Burst {i+1}/{count} sent at {time.strftime('%H:%M:%S')}")
                if i < count - 1:
                    time.sleep(interval)
                    
            time.sleep(0.5)
            self.send_typing_indicator(thread_id, False)
            print("✅ Typing burst completed")
            
        except Exception as e:
            print(f"❌ Error in typing burst: {e}")
            try:
                self.send_typing_indicator(thread_id, False)
            except:
                pass

    # ========================================================================
    # SHARE FUNCTIONS
    # ========================================================================
    
    def share_link(self, url: str, thread_id: str, text: str = "", callback: Optional[Callable] = None):
        """
        Share link via MQTT
        
        Args:
            url: URL to share
            thread_id: ID of the thread to share link to
            text: Optional text message with the link
            callback: Optional callback function for response
        """
        if not self.connected:
            raise Exception("❌ MQTT client not connected. Call connect() first.")
            
        self.req_id_counter += 1
        request_id = self.req_id_counter
        
        otid = generate_offline_threading_id()
        
        task_payload = {
            "otid": otid,
            "source": 524289,
            "sync_group": 1,
            "send_type": 6,
            "mark_thread_read": 0,
            "url": url or "https://www.facebook.com/",
            "text": text or "",
            "thread_id": thread_id,
            "initiating_source": 0
        }
        
        task = {
            "label": 46,
            "payload": json_minimal(task_payload),
            "queue_name": thread_id,
            "task_id": random.randint(0, 1000),
            "failure_count": None,
        }
        
        main_payload = {
            "tasks": [task],
            "epoch_id": generate_offline_threading_id(),
            "version_id": "7191105584331330",
        }
        
        message = {
            "app_id": "2220391788200892",
            "payload": json_minimal(main_payload),
            "request_id": request_id,
            "type": 3
        }
        
        if callback:
            self.req_callbacks[request_id] = callback
            
        try:
            result = self.mqtt_client.publish(
                topic="/ls_req",
                payload=json_minimal(message),
                qos=1,
                retain=False,
            )
            
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                print(f"🔗 Link share request sent successfully. Request ID: {request_id}")
                return True
            else:
                print(f"❌ Failed to send link share request. Error code: {result.rc}")
                if request_id in self.req_callbacks:
                    del self.req_callbacks[request_id]
                return False
                
        except Exception as e:
            print(f"❌ Error sending link share: {e}")
            if request_id in self.req_callbacks:
                del self.req_callbacks[request_id]
            return False

    def share_contact(self, contact_id: str, thread_id: str, text: str = "", callback: Optional[Callable] = None):
        """
        Share contact via MQTT
        
        Args:
            contact_id: ID of the contact to share (sender ID)
            thread_id: ID of the thread to share contact to
            text: Optional text message with the contact
            callback: Optional callback function for response
        """
        if not self.connected:
            raise Exception("❌ MQTT client not connected. Call connect() first.")
            
        self.ws_req_number += 1
        request_id = self.ws_req_number
        
        task_payload = {
            "contact_id": contact_id,
            "sync_group": 1,
            "text": text or "",
            "thread_id": thread_id
        }
        
        task = {
            "label": 359,
            "payload": json_minimal(task_payload),
            "queue_name": "xma_open_contact_share",
            "task_id": random.randint(0, 1000),
            "failure_count": None,
        }
        
        main_payload = {
            "tasks": [task],
            "epoch_id": generate_offline_threading_id(),
            "version_id": "7214102258676893",
        }
        
        message = {
            "app_id": "2220391788200892",
            "payload": json_minimal(main_payload),
            "request_id": request_id,
            "type": 3
        }
        
        if callback:
            self.req_callbacks[request_id] = callback
            
        try:
            result = self.mqtt_client.publish(
                topic="/ls_req",
                payload=json_minimal(message),
                qos=1,
                retain=False,
            )
            
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                print(f"👤 Contact share request sent successfully. Request ID: {request_id}")
                return True
            else:
                print(f"❌ Failed to send contact share request. Error code: {result.rc}")
                if request_id in self.req_callbacks:
                    del self.req_callbacks[request_id]
                return False
                
        except Exception as e:
            print(f"❌ Error sending contact share: {e}")
            if request_id in self.req_callbacks:
                del self.req_callbacks[request_id]
            return False

    # ========================================================================
    # POLL FUNCTIONS
    # ========================================================================
    
    def send_poll(self, thread_id: str, question: str, options: List[str], callback: Optional[Callable] = None):
        """
        Send poll using MQTT
        
        Args:
            thread_id: Thread ID to send poll to
            question: Poll question
            options: List of poll options
            callback: Optional callback function
        """
        if not self.connected:
            raise Exception("❌ MQTT not connected")
            
        self.ws_req_number += 1
        self.ws_task_number += 1
        
        try:
            task_payload = {
                "question_text": question,
                "thread_key": int(thread_id),
                "options": options,
                "sync_group": 1,
            }
            
            task = {
                "failure_count": None,
                "label": "163",
                "payload": json_minimal(task_payload),
                "queue_name": "poll_creation",
                "task_id": self.ws_task_number,
            }
            
            content = {
                "app_id": "2220391788200892",
                "payload": {
                    "data_trace_id": None,
                    "epoch_id": int(generate_offline_threading_id()),
                    "tasks": [task],
                    "version_id": "7158486590867448",
                },
                "request_id": self.ws_req_number,
                "type": 3,
            }
            
            content["payload"] = json_minimal(content["payload"])
            
            if callback:
                self.req_callbacks[self.ws_req_number] = callback
                
            self.mqtt_client.publish(
                topic="/ls_req",
                payload=json_minimal(content),
                qos=1,
                retain=False,
            )
            
            print(f"📊 Poll sent: '{question}' with {len(options)} options")
            return True
            
        except Exception as e:
            print(f"❌ Error sending poll: {e}")
            return False

    # ========================================================================
    # THEME FUNCTIONS
    # ========================================================================
    
    def get_theme_by_name(self, name: str) -> Optional[dict]:
        """Find theme by name"""
        for theme in THEMES:
            if theme["name"].lower() == name.lower():
                return theme
        return None

    def get_random_theme(self) -> dict:
        """Get random theme"""
        return random.choice(THEMES)

    def set_theme(self, thread_id: str, theme_id: Optional[str] = None, 
                  theme_name: Optional[str] = None, callback: Optional[Callable] = None) -> str:
        """
        Set theme for thread
        
        Args:
            thread_id: ID of thread
            theme_id: Theme ID (priority over theme_name)
            theme_name: Theme name
            callback: Callback function when completed
            
        Returns:
            ID of theme that was set
        """
        if not self.connected:
            raise Exception("❌ Not connected to MQTT! Call connect() first")
            
        # Determine theme ID
        selected_theme_id = None
        selected_theme_name = None
        
        if theme_id:
            theme_exists = any(theme["id"] == theme_id for theme in THEMES)
            if theme_exists:
                selected_theme_id = theme_id
                selected_theme = next((theme for theme in THEMES if theme["id"] == theme_id), None)
                selected_theme_name = selected_theme["name"] if selected_theme else "Unknown"
            else:
                raise ValueError(f"❌ Theme ID '{theme_id}' does not exist")
        elif theme_name:
            theme = self.get_theme_by_name(theme_name)
            if theme:
                selected_theme_id = theme["id"]
                selected_theme_name = theme["name"]
            else:
                raise ValueError(f"❌ Theme '{theme_name}' does not exist")
        else:
            random_theme = self.get_random_theme()
            selected_theme_id = random_theme["id"]
            selected_theme_name = random_theme["name"]
        
        self.ws_req_number += 1
        self.ws_task_number += 1
        
        task_payload = {
            "thread_key": thread_id,
            "theme_fbid": selected_theme_id,
            "source": None,
            "sync_group": 1,
            "payload": None
        }
        
        task = {
            "failure_count": None,
            "label": "43",
            "payload": json_minimal(task_payload),
            "queue_name": "thread_theme",
            "task_id": self.ws_task_number
        }
        
        content = {
            "app_id": "2220391788200892",
            "payload": json_minimal({
                "data_trace_id": None,
                "epoch_id": int(generate_offline_threading_id()),
                "tasks": [task],
                "version_id": "25095469420099952"
            }),
            "request_id": self.ws_req_number,
            "type": 3
        }
        
        if callback and callable(callback):
            self.req_callbacks[self.ws_req_number] = callback
            
        self.mqtt_client.publish(
            topic="/ls_req",
            payload=json_minimal(content),
            qos=1,
            retain=False,
        )
        
        print(f"🎨 Theme set to '{selected_theme_name}' for thread {thread_id}")
        return selected_theme_id

    # ========================================================================
    # ADDITIONAL TOOLS (Block, Add User, Rename Group)
    # ========================================================================
    
    def block_user(self, user_id: str):
        """Block user using standard HTTP request (not MQTT)"""
        try:
            friendly_name = "ProfileCometActionBlockUserMutation"
            doc_id = "6305880099497989"
            variables = json.dumps({
                "input": {
                    "blocksource": "PROFILE",
                    "user_id": int(user_id),
                    "actor_id": self.dataFB["FacebookID"],
                    "client_mutation_id": str(random.randint(1000, 9999))
                },
                "scale": 3
            })
            
            data_form = formAll(self.dataFB, friendly_name, doc_id)
            data_form["variables"] = variables
            
            response = requests.post(
                **mainRequests("https://www.facebook.com/api/graphql/", data_form, self.dataFB["cookieFacebook"])
            )
            
            res_data = json.loads(response.text)
            if "data" in res_data:
                print(f"🚫 Successfully blocked user {user_id}")
                return {"success": True, "message": "User blocked successfully"}
            else:
                return {"success": False, "message": "Failed to block user", "details": res_data.get("errors")}
                
        except Exception as e:
            print(f"❌ Error blocking user: {e}")
            return {"success": False, "message": f"Error: {e}"}

    def unblock_user(self, user_id: str):
        """Unblock user using standard HTTP request (not MQTT)"""
        try:
            friendly_name = "BlockingSettingsBlockMutation"
            doc_id = "6009824239038988"
            variables = json.dumps({
                "input": {
                    "block_action": "UNBLOCK",
                    "setting": "USER",
                    "target_id": str(user_id),
                    "actor_id": self.dataFB["FacebookID"],
                    "client_mutation_id": "1"
                }
            })
            
            data_form = formAll(self.dataFB, friendly_name, doc_id)
            data_form["variables"] = variables
            
            response = requests.post(
                **mainRequests("https://www.facebook.com/api/graphql/", data_form, self.dataFB["cookieFacebook"])
            )
            
            res_data = json.loads(response.text)
            if "data" in res_data:
                print(f"✅ Successfully unblocked user {user_id}")
                return {"success": True, "message": "User unblocked successfully"}
            else:
                return {"success": False, "message": "Failed to unblock user", "details": res_data.get("errors")}
                
        except Exception as e:
            print(f"❌ Error unblocking user: {e}")
            return {"success": False, "message": f"Error: {e}"}

    def add_user_to_group(self, user_ids: Union[str, List[str]], thread_id: str):
        """Add users to group using standard HTTP request (not MQTT)"""
        try:
            if isinstance(user_ids, str):
                user_ids = [user_ids]
                
            offline_threading_id = gen_threading_id()
            threading_id = gen_threading_id()
            timestamp = int(time.time() * 1000)
            
            form_data = {
                "client": "mercury",
                "action_type": "ma-type:log-message",
                "author": f"fbid:{self.dataFB['FacebookID']}",
                "thread_id": thread_id,
                "timestamp": timestamp,
                "timestamp_absolute": "Today",
                "timestamp_relative": str(int(time.time())),
                "timestamp_time_passed": "0",
                "is_unread": False,
                "is_cleared": False,
                "is_forward": False,
                "is_filtered_content": False,
                "is_filtered_content_bh": False,
                "is_filtered_content_account": False,
                "is_spoof_warning": False,
                "source": "source:chat:web",
                "source_tags[0]": "source:chat",
                "log_message_type": "log:subscribe",
                "status": "0",
                "offline_threading_id": offline_threading_id,
                "message_id": offline_threading_id,
                "threading_id": threading_id,
                "manual_retry_cnt": "0",
                "thread_fbid": thread_id,
                "fb_dtsg": self.dataFB["fb_dtsg"],
                "jazoest": self.dataFB["jazoest"],
                "__user": self.dataFB["FacebookID"],
                "__a": "1",
                "__req": "1",
                "__rev": self.dataFB.get("clientRevision", "1015919737")
            }
            
            for idx, user_id in enumerate(user_ids):
                form_data[f"log_message_data[added_participants][{idx}]"] = f"fbid:{user_id}"
                
            response = requests.post(
                **mainRequests("https://www.facebook.com/messaging/send/", form_data, self.dataFB["cookieFacebook"])
            )
            
            print(f"👥 Successfully added {len(user_ids)} users to group {thread_id}")
            return {
                "success": True,
                "message": f"Added {len(user_ids)} users to group",
                "users_added": user_ids,
                "thread_id": thread_id
            }
            
        except Exception as e:
            print(f"❌ Error adding users to group: {e}")
            return {
                "success": False,
                "error": str(e),
                "message": "Error adding users to group"
            }

    def rename_group(self, new_title: str, thread_id: str):
        """Rename group using standard HTTP request (not MQTT)"""
        try:
            messageAndOTID = gen_threading_id()
            current_timestamp = int(time.time() * 1000)
            
            form_data = {
                "client": "mercury",
                "action_type": "ma-type:log-message",
                "author": f"fbid:{self.dataFB['FacebookID']}",
                "thread_id": str(thread_id),
                "timestamp": current_timestamp,
                "timestamp_relative": str(int(time.time())),
                "source": "source:chat:web",
                "source_tags[0]": "source:chat",
                "offline_threading_id": messageAndOTID,
                "message_id": messageAndOTID,
                "threading_id": gen_threading_id(),
                "thread_fbid": str(thread_id),
                "thread_name": str(new_title),
                "log_message_type": "log:thread-name",
                "fb_dtsg": self.dataFB["fb_dtsg"],
                "jazoest": self.dataFB["jazoest"],
                "__user": str(self.dataFB["FacebookID"]),
                "__a": "1",
                "__req": "1",
                "__rev": self.dataFB.get("clientRevision", "1015919737")
            }
            
            url = "https://www.facebook.com/messaging/set_thread_name/"
            response = requests.post(**mainRequests(url, form_data, self.dataFB["cookieFacebook"]))
            
            if response.status_code == 200:
                print(f"✏️ Successfully renamed group to: {new_title}")
                return {
                    "success": True,
                    "message": f"Group renamed to: {new_title}"
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}"
                }
                
        except Exception as e:
            print(f"❌ Error renaming group: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    # ========================================================================
    # USER & GROUP MANAGEMENT FUNCTIONS
    # ========================================================================
    
    def get_user_info(self, user_id: str) -> dict:
        """
        Get user profile information
        
        Args:
            user_id: Facebook user ID
            
        Returns:
            dict: User information including name, profile URL, avatar, gender, etc.
        """
        try:
            form_data = formAll(self.dataFB, "CometHovercardQueryRendererQuery", "4055219691228498")
            form_data["variables"] = json.dumps({
                "actionBarRenderLocation": "WWW_COMET_HOVERCARD",
                "context": "DEFAULT",
                "entityID": str(user_id),
                "includeTdaInfo": True,
                "scale": 1
            })
            
            response = requests.post(
                **mainRequests("https://www.facebook.com/api/graphql/", form_data, self.dataFB["cookieFacebook"])
            )
            
            text = response.text
            if text.startswith("for (;;);"):
                text = text[9:]
            elif text.startswith("for(;;);"):
                text = text[8:]
            
            data = json.loads(text)
            
            if "data" in data and "node" in data["data"]:
                node = data["data"]["node"]
                return {
                    "success": True,
                    "userID": user_id,
                    "name": node.get("name", ""),
                    "firstName": node.get("short_name", ""),
                    "profileUrl": node.get("url", f"https://facebook.com/{user_id}"),
                    "avatarUrl": node.get("profile_picture", {}).get("uri", ""),
                    "gender": node.get("gender", ""),
                    "isFriend": node.get("is_viewer_friend", False),
                    "isVerified": node.get("is_verified", False)
                }
            else:
                return {"success": False, "error": "User not found"}
                
        except Exception as e:
            print(f"❌ Error getting user info: {e}")
            return {"success": False, "error": str(e)}

    def get_user_info_simple(self, user_id: str) -> dict:
        """
        Get simple user info using Graph API
        
        Args:
            user_id: Facebook user ID
            
        Returns:
            dict: Basic user information
        """
        try:
            url = f"https://graph.facebook.com/{user_id}/picture?width=720&height=720&redirect=false&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662"
            response = requests.get(url, timeout=10)
            avatar_data = response.json()
            
            return {
                "success": True,
                "userID": user_id,
                "avatarUrl": avatar_data.get("data", {}).get("url", ""),
                "profileUrl": f"https://facebook.com/{user_id}"
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def remove_user_from_group(self, user_id: str, thread_id: str) -> dict:
        """
        Remove (kick) user from group
        
        Args:
            user_id: User ID to remove
            thread_id: Thread/Group ID
            
        Returns:
            dict: Result of operation
        """
        try:
            form_data = {
                "uid": str(user_id),
                "tid": str(thread_id),
                "fb_dtsg": self.dataFB["fb_dtsg"],
                "jazoest": self.dataFB["jazoest"],
                "__user": str(self.dataFB["FacebookID"]),
                "__a": "1",
                "__req": "1",
                "__rev": self.dataFB.get("clientRevision", "1015919737")
            }
            
            response = requests.post(
                **mainRequests("https://www.facebook.com/chat/remove_participants/", form_data, self.dataFB["cookieFacebook"])
            )
            
            if response.status_code == 200:
                print(f"👢 Successfully removed user {user_id} from group {thread_id}")
                return {
                    "success": True,
                    "message": f"User {user_id} removed from group"
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}"
                }
                
        except Exception as e:
            print(f"❌ Error removing user from group: {e}")
            return {"success": False, "error": str(e)}

    def set_admin(self, user_id: str, thread_id: str, is_admin: bool = True) -> dict:
        """
        Add or remove admin role for user in group
        
        Args:
            user_id: User ID to set admin
            thread_id: Thread/Group ID
            is_admin: True to add admin, False to remove admin
            
        Returns:
            dict: Result of operation
        """
        try:
            form_data = {
                "add": "true" if is_admin else "false",
                "thread_fbid": str(thread_id),
                "admin_ids[0]": str(user_id),
                "fb_dtsg": self.dataFB["fb_dtsg"],
                "jazoest": self.dataFB["jazoest"],
                "__user": str(self.dataFB["FacebookID"]),
                "__a": "1",
                "__req": "1",
                "__rev": self.dataFB.get("clientRevision", "1015919737")
            }
            
            response = requests.post(
                **mainRequests("https://www.facebook.com/messaging/save_admins/?dpr=1", form_data, self.dataFB["cookieFacebook"])
            )
            
            if response.status_code == 200:
                action = "Added" if is_admin else "Removed"
                print(f"👑 Successfully {action.lower()} admin for user {user_id}")
                return {
                    "success": True,
                    "message": f"{action} admin role for user {user_id}"
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}"
                }
                
        except Exception as e:
            print(f"❌ Error setting admin: {e}")
            return {"success": False, "error": str(e)}

    def change_nickname(self, nickname: str, user_id: str, thread_id: str) -> dict:
        """
        Change nickname for user in group
        
        Args:
            nickname: New nickname to set
            user_id: User ID to change nickname for
            thread_id: Thread/Group ID
            
        Returns:
            dict: Result of operation
        """
        try:
            form_data = {
                "nickname": str(nickname),
                "participant_id": str(user_id),
                "thread_or_other_fbid": str(thread_id),
                "fb_dtsg": self.dataFB["fb_dtsg"],
                "jazoest": self.dataFB["jazoest"],
                "__user": str(self.dataFB["FacebookID"]),
                "__a": "1",
                "__req": "1",
                "__rev": self.dataFB.get("clientRevision", "1015919737")
            }
            
            response = requests.post(
                **mainRequests("https://www.facebook.com/messaging/save_thread_nickname/?source=thread_settings&dpr=1", form_data, self.dataFB["cookieFacebook"])
            )
            
            if response.status_code == 200:
                print(f"📝 Successfully changed nickname to '{nickname}' for user {user_id}")
                return {
                    "success": True,
                    "message": f"Nickname changed to: {nickname}"
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}"
                }
                
        except Exception as e:
            print(f"❌ Error changing nickname: {e}")
            return {"success": False, "error": str(e)}

    def get_thread_members(self, thread_id: str) -> dict:
        """
        Get list of members in a thread/group
        
        Args:
            thread_id: Thread/Group ID
            
        Returns:
            dict: List of members with their info
        """
        try:
            fb_tools_thread = fbTools(self.dataFB, thread_id)
            if fb_tools_thread.getAllThreadList():
                member_data = fb_tools_thread.typeCommand("exportMemberListToJson")
                if isinstance(member_data, list):
                    members = []
                    for member_json in member_data:
                        try:
                            member = json.loads(member_json)
                            for uid, info in member.items():
                                members.append({
                                    "userID": uid,
                                    "name": info.get("nameFB", ""),
                                    "profileUrl": info.get("profileUrl", ""),
                                    "avatarUrl": info.get("avatarUrl", ""),
                                    "gender": info.get("gender", ""),
                                    "username": info.get("usernameFB", "")
                                })
                        except:
                            continue
                    return {
                        "success": True,
                        "members": members,
                        "memberCount": len(members)
                    }
                else:
                    return {"success": False, "error": "Failed to parse member data"}
            else:
                return {"success": False, "error": "Failed to get thread list"}
                
        except Exception as e:
            print(f"❌ Error getting thread members: {e}")
            return {"success": False, "error": str(e)}

    def set_approval_mode(self, thread_id: str, enable: bool = True) -> dict:
        """
        Set approval mode (phê duyệt thành viên) for group
        
        Args:
            thread_id: Thread/Group ID
            enable: True to enable approval mode, False to disable
            
        Returns:
            dict: Result of operation
        """
        try:
            form_data = {
                "set_mode": "1" if enable else "0",
                "thread_fbid": str(thread_id),
                "fb_dtsg": self.dataFB["fb_dtsg"],
                "jazoest": self.dataFB["jazoest"],
                "__user": str(self.dataFB["FacebookID"]),
                "__a": "1",
                "__req": "1",
                "__rev": self.dataFB.get("clientRevision", "1015919737")
            }
            
            response = requests.post(
                **mainRequests("https://www.facebook.com/messaging/set_approval_mode/?dpr=1", form_data, self.dataFB["cookieFacebook"])
            )
            
            if response.status_code == 200:
                status = "enabled" if enable else "disabled"
                print(f"✅ Approval mode {status} for group {thread_id}")
                return {
                    "success": True,
                    "message": f"Approval mode {status}"
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}"
                }
                
        except Exception as e:
            print(f"❌ Error setting approval mode: {e}")
            return {"success": False, "error": str(e)}

    def handle_pending_request(self, user_ids: Union[str, List[str]], thread_id: str, approve: bool = True) -> dict:
        """
        Approve or deny pending member requests
        
        Args:
            user_ids: User ID(s) to approve/deny
            thread_id: Thread/Group ID
            approve: True to approve, False to deny
            
        Returns:
            dict: Result of operation
        """
        try:
            if isinstance(user_ids, str):
                user_ids = [user_ids]
            
            form_data = {
                "thread_fbid": str(thread_id),
                "fb_dtsg": self.dataFB["fb_dtsg"],
                "jazoest": self.dataFB["jazoest"],
                "__user": str(self.dataFB["FacebookID"]),
                "__a": "1",
                "__req": "1",
                "__rev": self.dataFB.get("clientRevision", "1015919737")
            }
            
            for idx, user_id in enumerate(user_ids):
                form_data[f"user_ids[{idx}]"] = str(user_id)
            
            endpoint = "approval" if approve else "deny"
            response = requests.post(
                **mainRequests(f"https://www.facebook.com/messaging/{endpoint}/?dpr=1", form_data, self.dataFB["cookieFacebook"])
            )
            
            if response.status_code == 200:
                action = "approved" if approve else "denied"
                print(f"✅ {len(user_ids)} user(s) {action}")
                return {
                    "success": True,
                    "message": f"{len(user_ids)} user(s) {action}",
                    "userIds": user_ids
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}"
                }
                
        except Exception as e:
            print(f"❌ Error handling pending request: {e}")
            return {"success": False, "error": str(e)}

    def set_emoji(self, emoji: str, thread_id: str) -> dict:
        """
        Set emoji for group
        
        Args:
            emoji: Emoji to set
            thread_id: Thread/Group ID
            
        Returns:
            dict: Result of operation
        """
        try:
            form_data = {
                "emoji_choice": str(emoji),
                "thread_or_other_fbid": str(thread_id),
                "fb_dtsg": self.dataFB["fb_dtsg"],
                "jazoest": self.dataFB["jazoest"],
                "__user": str(self.dataFB["FacebookID"]),
                "__a": "1",
                "__req": "1",
                "__rev": self.dataFB.get("clientRevision", "1015919737")
            }
            
            response = requests.post(
                **mainRequests("https://www.facebook.com/messaging/save_thread_emoji/?source=thread_settings&dpr=1", form_data, self.dataFB["cookieFacebook"])
            )
            
            if response.status_code == 200:
                print(f"😀 Successfully set emoji to '{emoji}' for group {thread_id}")
                return {
                    "success": True,
                    "message": f"Emoji changed to: {emoji}"
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}"
                }
                
        except Exception as e:
            print(f"❌ Error setting emoji: {e}")
            return {"success": False, "error": str(e)}

    def set_group_image(self, image_path_or_url: str, thread_id: str) -> dict:
        """
        Set group image/avatar
        
        Args:
            image_path_or_url: Path to local image or URL
            thread_id: Thread/Group ID
            
        Returns:
            dict: Result of operation
        """
        try:
            fbid = upload_image_get_fbid(image_path_or_url, self.dataFB["cookieFacebook"])
            
            if not fbid or not str(fbid).isdigit():
                return {"success": False, "error": f"Failed to upload image: {fbid}"}
            
            form_data = {
                "thread_image_id": str(fbid),
                "thread_id": str(thread_id),
                "fb_dtsg": self.dataFB["fb_dtsg"],
                "jazoest": self.dataFB["jazoest"],
                "__user": str(self.dataFB["FacebookID"]),
                "__a": "1",
                "__req": "1",
                "__rev": self.dataFB.get("clientRevision", "1015919737")
            }
            
            response = requests.post(
                **mainRequests("https://www.facebook.com/messaging/set_thread_image/?dpr=1", form_data, self.dataFB["cookieFacebook"])
            )
            
            if response.status_code == 200:
                print(f"🖼️ Successfully set group image for {thread_id}")
                return {
                    "success": True,
                    "message": "Group image updated",
                    "imageFbid": fbid
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}"
                }
                
        except Exception as e:
            print(f"❌ Error setting group image: {e}")
            return {"success": False, "error": str(e)}

    def get_thread_admins(self, thread_id: str) -> dict:
        """
        Get list of admins in a thread/group
        
        Args:
            thread_id: Thread/Group ID
            
        Returns:
            dict: List of admin IDs
        """
        try:
            fb_tools_thread = fbTools(self.dataFB, thread_id)
            if fb_tools_thread.getAllThreadList():
                admin_data = fb_tools_thread.typeCommand("getAdmin")
                if isinstance(admin_data, dict) and "adminThreadList" in admin_data:
                    return {
                        "success": True,
                        "adminIds": admin_data["adminThreadList"],
                        "adminCount": len(admin_data["adminThreadList"])
                    }
                else:
                    return {"success": False, "error": "Failed to get admin data"}
            else:
                return {"success": False, "error": "Failed to get thread list"}
                
        except Exception as e:
            print(f"❌ Error getting thread admins: {e}")
            return {"success": False, "error": str(e)}

    # ========================================================================
    # MEDIA SEND FUNCTIONS (send_image / send_audio)
    # ========================================================================

    # ====================================================================
    # MEDIA UPLOAD & SEND
    # ====================================================================

    def _upload_to_messenger(self, file_bytes: bytes, filename: str, mime_type: str) -> Optional[str]:
        """
        Upload file lên Facebook Messenger upload API.
        - Auth tokens nằm trong multipart body (KHÔNG phải URL query string)
        - Không set Content-Length thủ công (để requests tự tính cho multipart)
        - Xử lý response rỗng / non-JSON an toàn

        Returns:
            str: attachment_fbid nếu thành công, None nếu thất bại.
        """
        ck      = self.dataFB["cookieFacebook"]
        fb_dtsg = self.dataFB.get("fb_dtsg", "")
        jazoest = self.dataFB.get("jazoest", "")
        user_id = str(self.dataFB.get("FacebookID", ""))
        rev     = str(self.dataFB.get("clientRevision", "1015919737"))

        # Headers cho upload — KHÔNG set Content-Type/Content-Length thủ công
        # để requests tự xây multipart boundary
        headers = {
            "Host":             "upload.facebook.com",
            "Connection":       "keep-alive",
            "User-Agent":       "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept":           "*/*",
            "Origin":           "https://www.facebook.com",
            "Referer":          "https://www.facebook.com/",
            "Sec-Fetch-Site":   "cross-site",
            "Sec-Fetch-Mode":   "cors",
            "Sec-Fetch-Dest":   "empty",
            "Accept-Language":  "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
            "Accept-Encoding":  "gzip, deflate, br",
        }

        # Auth params đi trong body multipart (cùng với file)
        form_body = {
            "av":      user_id,
            "__user":  user_id,
            "__a":     "1",
            "__req":   "1b",
            "__rev":   rev,
            "fb_dtsg": fb_dtsg,
            "jazoest": jazoest,
        }

        files = {
            "upload_1024": (filename, BytesIO(file_bytes), mime_type),
        }

        try:
            resp = requests.post(
                "https://upload.facebook.com/ajax/mercury/upload.php",
                headers=headers,
                cookies=parse_cookie_string(ck),
                data=form_body,      # auth trong body, KHÔNG phải params=
                files=files,
                timeout=40,
            )

            print(f"[upload_to_messenger] HTTP {resp.status_code} | size={len(resp.content)}B")

            raw = resp.text.strip()
            if not raw:
                print("[upload_to_messenger] Response rỗng — cookie hết hạn hoặc sai endpoint")
                return None

            # Facebook thêm "for(;;);" ở đầu JSON để chống hijacking
            body = raw[8:] if raw.startswith("for(;;);") else raw

            # Thử parse JSON
            try:
                data = json.loads(body)
                # Cấu trúc thường gặp: payload.metadata[0].fbid
                meta = data.get("payload", {}).get("metadata", [])
                fbid = meta[0].get("fbid") if meta else None
                if not fbid:
                    fbid = data.get("payload", {}).get("fbid")
                if fbid:
                    print(f"[upload_to_messenger] ✅ fbid={fbid}")
                    return str(fbid)
            except json.JSONDecodeError:
                pass  # không phải JSON → thử regex bên dưới

            # Regex fallback trên raw text
            m = re.search(r'"fbid"\s*:\s*"?(\d{10,})"?', body)
            if m:
                print(f"[upload_to_messenger] ✅ fbid={m.group(1)} (regex)")
                return m.group(1)

            print(f"[upload_to_messenger] Không tìm được fbid.\nResponse: {body[:400]}")
            return None

        except Exception as e:
            print(f"[upload_to_messenger] Exception: {e}")
            return None

    def _send_media_via_mqtt(self, attachment_fbid: str, thread_id: str, caption: str = "") -> int:
        """
        Gửi attachment đã upload lên FB qua MQTT (send_type=3).
        Structure giống hệt send_message nhưng có thêm attachment_fbids.
        """
        if not self.connected:
            raise ValueError("❌ Not connected to MQTT. Call connect() first.")

        self.ws_req_number  += 1
        self.ws_task_number += 1

        # Task gửi ảnh/audio — send_type=3 nghĩa là attachment
        task_payload = {
            "initiating_source":    0,
            "multitab_env":         0,
            "otid":                 generate_offline_threading_id(),
            "send_type":            3,
            "skip_url_preview_gen": 0,
            "source":               0,
            "sync_group":           1,
            "text":                 "",
            "text_has_links":       0,
            "thread_id":            int(thread_id),
            "attachment_fbids":     [int(attachment_fbid)],
        }

        task = {
            "failure_count": None,
            "label":         "46",
            "payload":       json_minimal(task_payload),
            "queue_name":    str(thread_id),
            "task_id":       self.ws_task_number,
        }

        # Task đánh dấu đã đọc (giống send_message)
        self.ws_task_number += 1
        task_mark = {
            "failure_count": None,
            "label":         "21",
            "payload":       json_minimal({
                "last_read_watermark_ts": int(time.time() * 1000),
                "sync_group": 1,
                "thread_id":  int(thread_id),
            }),
            "queue_name": str(thread_id),
            "task_id":    self.ws_task_number,
        }

        # Content structure giống hệt send_message
        content = {
            "app_id":     "2220391788200892",
            "payload":    {
                "data_trace_id": None,
                "epoch_id":      int(generate_offline_threading_id()),
                "tasks":         [task, task_mark],
                "version_id":    "7545284305482586",
            },
            "request_id": self.ws_req_number,
            "type":        3,
        }
        content["payload"] = json_minimal(content["payload"])

        self.mqtt_client.publish(
            topic="/ls_req",
            payload=json_minimal(content),
            qos=1,
            retain=False,
        )

        if self.options.get("debug"):
            print(f"📤 Media sent | fbid={attachment_fbid} | req={self.ws_req_number}")

        # Gửi caption riêng sau (text thường)
        if caption:
            time.sleep(0.4)
            self.send_message(text=caption, thread_id=str(thread_id))

        return self.ws_req_number

    # ── Fallback helpers ────────────────────────────────────────────────

    def _fallback_upload_image(self, image_data: bytes, caption: str, thread_id: str) -> dict:
        """Upload ảnh lên imgbb (miễn phí, không cần key) rồi gửi link."""
        try:
            import base64 as _b64
            b64 = _b64.b64encode(image_data).decode()
            # imgbb public API
            r = requests.post(
                "https://api.imgbb.com/1/upload",
                data={"key": "2e46965f41e050e819bff5f00f2af47f", "image": b64},
                timeout=25,
            )
            url = r.json()["data"]["url"]
            msg = f"{caption}\n🖼️ {url}" if caption else f"🖼️ {url}"
            self.send_message(text=msg, thread_id=str(thread_id))
            return {"success": True, "method": "imgbb_fallback", "url": url}
        except Exception:
            pass
        # imgbb thất bại → thử freeimage.host
        try:
            import base64 as _b64
            b64 = _b64.b64encode(image_data).decode()
            r = requests.post(
                "https://freeimage.host/api/1/upload",
                data={"key": "6d207e02198a847aa98d0a2a901485a5",
                      "action": "upload", "source": b64, "format": "json"},
                timeout=25,
            )
            url = r.json()["image"]["url"]
            msg = f"{caption}\n🖼️ {url}" if caption else f"🖼️ {url}"
            self.send_message(text=msg, thread_id=str(thread_id))
            return {"success": True, "method": "freeimage_fallback", "url": url}
        except Exception as e:
            return {"success": False, "error": f"Tất cả fallback đều thất bại: {e}"}

    def _fallback_upload_audio(self, audio_data: bytes, fname: str, mime: str, caption: str, thread_id: str) -> dict:
        """Upload audio lên tmpfiles.org rồi gửi link download."""
        try:
            r = requests.post(
                "https://tmpfiles.org/api/v1/upload",
                files={"file": (fname, BytesIO(audio_data), mime)},
                timeout=30,
            )
            raw = r.json()["data"]["url"]
            dl  = raw.replace("tmpfiles.org/", "tmpfiles.org/dl/")
            msg = f"🎵 {caption}\n🔗 {dl}\n⏳ Link hết hạn sau 60 phút" if caption else f"🎵 Audio:\n🔗 {dl}\n⏳ Link hết hạn sau 60 phút"
            self.send_message(text=msg, thread_id=str(thread_id))
            return {"success": True, "method": "tmpfiles_fallback", "url": dl}
        except Exception as e:
            return {"success": False, "error": f"Audio fallback thất bại: {e}"}

    # ── Public API ──────────────────────────────────────────────────────

    def send_image(self, image_data: bytes, thread_id: str, caption: str = "") -> dict:
        """
        Gửi ảnh vào cuộc trò chuyện Messenger.

        Args:
            image_data: Dữ liệu ảnh dạng bytes (PNG / JPG / GIF).
            thread_id:  ID thread / nhóm.
            caption:    Chú thích kèm theo (tuỳ chọn).
        """
        try:
            # Phát hiện định dạng từ magic bytes
            if image_data[:8] == b'\x89PNG\r\n\x1a\n':
                mime, fname = "image/png",  "image.png"
            elif image_data[:6] in (b'GIF87a', b'GIF89a'):
                mime, fname = "image/gif",  "image.gif"
            elif image_data[:2] == b'\xff\xd8':
                mime, fname = "image/jpeg", "image.jpg"
            elif image_data[:4] == b'RIFF' and image_data[8:12] == b'WEBP':
                mime, fname = "image/webp", "image.webp"
            else:
                mime, fname = "image/png",  "image.png"

            fbid = self._upload_to_messenger(image_data, fname, mime)
            if fbid:
                self._send_media_via_mqtt(fbid, thread_id, caption)
                return {"success": True, "fbid": fbid, "method": "mqtt"}

            # Upload FB thất bại → dùng host bên ngoài
            print("[send_image] FB upload thất bại, dùng fallback...")
            return self._fallback_upload_image(image_data, caption, thread_id)

        except Exception as e:
            print(f"[send_image] Lỗi: {e}")
            return {"success": False, "error": str(e)}

    def send_audio(self, audio_data: bytes, thread_id: str, caption: str = "") -> dict:
        """
        Gửi file âm thanh vào cuộc trò chuyện Messenger.

        Args:
            audio_data: Dữ liệu audio dạng bytes (MP3 / OGG / WAV).
            thread_id:  ID thread / nhóm.
            caption:    Chú thích kèm theo (tuỳ chọn).
        """
        try:
            # Phát hiện định dạng từ magic bytes
            if audio_data[:3] == b'ID3' or (audio_data[:2] == b'\xff' and audio_data[1:2] in (b'\xfb', b'\xf3', b'\xf2', b'\xe3')):
                mime, fname = "audio/mpeg", "voice.mp3"
            elif audio_data[:4] == b'OggS':
                mime, fname = "audio/ogg",  "voice.ogg"
            elif audio_data[:4] == b'RIFF' and audio_data[8:12] == b'WAVE':
                mime, fname = "audio/wav",  "voice.wav"
            elif audio_data[:4] == b'fLaC':
                mime, fname = "audio/flac", "voice.flac"
            else:
                mime, fname = "audio/mpeg", "voice.mp3"

            fbid = self._upload_to_messenger(audio_data, fname, mime)
            if fbid:
                self._send_media_via_mqtt(fbid, thread_id, caption)
                return {"success": True, "fbid": fbid, "method": "mqtt"}

            # Upload FB thất bại → dùng tmpfiles
            print("[send_audio] FB upload thất bại, dùng fallback...")
            return self._fallback_upload_audio(audio_data, fname, mime, caption, thread_id)

        except Exception as e:
            print(f"[send_audio] Lỗi: {e}")
            return {"success": False, "error": str(e)}

    def send_attachment(self, attachment_path_or_url: str, thread_id: str, message: str = "", mentions: Union[dict, List[dict]] = None, message_id: str = None) -> dict:
        """
        Send attachment (image, video, file) to thread
        
        Args:
            attachment_path_or_url: Path to local file or URL
            thread_id: Thread/Group ID
            message: Optional message to send with attachment
            mentions: Optional mentions data for tagging users
            
        Returns:
            dict: Result of operation
        """
        try:
            is_url = attachment_path_or_url.startswith("http://") or attachment_path_or_url.startswith("https://")
            filename = ""
            
            if is_url:
                resp = requests.head(attachment_path_or_url, timeout=10, allow_redirects=True)
                if resp.status_code != 200:
                    return {"success": False, "error": "URL not accessible"}
                filename = attachment_path_or_url.split('/')[-1]
            else:
                if not os.path.isfile(attachment_path_or_url):
                    return {"success": False, "error": "File not found"}
                filename = basename(attachment_path_or_url)
            
            attachment_text = message if message else f"📎 {filename}"
            print(f"📸 Sending via MQTT: {filename}")
            print(f"📝 Message: {attachment_text[:50]}...")
            print(f"👥 Mentions count: {len(mentions) if mentions else 0}")
            
            result = self.send_message(
                text=attachment_text,
                thread_id=str(thread_id),
                mention=mentions,
                message_id=message_id
            )
            
            print(f"✅ MQTT send result: success")
            return {
                "success": True,
                "message": f"Attachment sent: {filename}",
                "attachmentName": filename,
                "attachmentType": "image" if any(ext in filename.lower() for ext in ['.jpg', '.jpeg', '.png', '.gif']) else "file"
            }
            
        except Exception as e:
            import traceback
            print(f"❌ Error sending attachment: {e}")
            traceback.print_exc()
            return {"success": False, "error": str(e)}

    def mute_thread(self, thread_id: str, mute_seconds: int = -1) -> dict:
        """
        Mute thread notifications
        
        Args:
            thread_id: Thread/Group ID
            mute_seconds: Duration to mute in seconds (-1 for forever, 0 to unmute)
            
        Returns:
            dict: Result of operation
        """
        try:
            form_data = {
                "thread_fbid": str(thread_id),
                "mute_settings": str(mute_seconds),
                "fb_dtsg": self.dataFB["fb_dtsg"],
                "jazoest": self.dataFB["jazoest"],
                "__user": str(self.dataFB["FacebookID"]),
                "__a": "1",
                "__req": "1",
                "__rev": self.dataFB.get("clientRevision", "1015919737")
            }
            
            response = requests.post(
                **mainRequests("https://www.facebook.com/ajax/mercury/change_mute_thread.php?dpr=1", form_data, self.dataFB["cookieFacebook"])
            )
            
            if response.status_code == 200:
                status = "unmuted" if mute_seconds == 0 else "muted"
                print(f"🔇 Thread {thread_id} {status}")
                return {
                    "success": True,
                    "message": f"Thread {status}"
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP Error: {response.status_code}"
                }
                
        except Exception as e:
            print(f"❌ Error muting thread: {e}")
            return {"success": False, "error": str(e)}

    # ========================================================================
    # UTILITY FUNCTIONS
    # ========================================================================
    
    def list_all_themes(self):
        """List all available themes"""
        print("🎨 Available themes:")
        for i, theme in enumerate(THEMES, 1):
            print(f"{i:2d}. {theme['name']} (ID: {theme['id']})")

    def get_thread_list(self):
        """Get list of threads"""
        if self.fb_tools.getAllThreadList():
            return self.fb_tools.getListThreadID()
        else:
            return {"ERR": "Failed to get thread list"}

    def get_thread_info(self, thread_id: str):
        """Get thread information"""
        fb_tools_thread = fbTools(self.dataFB, thread_id)
        if fb_tools_thread.getAllThreadList():
            return fb_tools_thread.typeCommand("threadInfomation")
        else:
            return {"ERR": "Failed to get thread information"}

    # Context manager support
    def __enter__(self):
        """Context manager entry"""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.disconnect()

# ============================================================================
# MULTI-COOKIE MANAGER
# ============================================================================

class MultiCookieManager:
    """Manager for multiple cookie accounts"""
    def __init__(self):
        self.accounts = []
        self.clients = {}
        self.stop_event = threading.Event()
        self.message_stats = {}

    def add_account(self, cookies: str, delay: float, account_name: str):
        """Add account to manager"""
        self.accounts.append({
            'cookies': cookies,
            'delay': delay,
            'name': account_name,
            'client': None
        })
        self.message_stats[account_name] = 0

    def worker_thread(self, account, thread_id, message_content):
        """Worker thread for each account"""
        account_name = account['name']
        try:
            # Create client for this account
            client = FacebookMQTTAllInOne(account['cookies'])
            account['client'] = client
            self.clients[account_name] = client
            
            if not client.connect():
                print(f"❌ [{account_name}] Failed to connect")
                return
                
            print(f"✅ [{account_name}] Connected successfully")
            
            while not self.stop_event.is_set():
                try:
                    client.send_message(message_content, thread_id)
                    self.message_stats[account_name] += 1
                    current_time = time.strftime("%H:%M:%S")
                    print(f"📤 [{current_time}] [{account_name}] Message #{self.message_stats[account_name]} sent")
                    
                    if account['delay'] > 0:
                        for _ in range(int(account['delay'] * 10)):
                            if self.stop_event.is_set():
                                break
                            time.sleep(0.1)
                            
                except Exception as e:
                    print(f"❌ ERROR [{account_name}]: {str(e)[:60]}")
                    time.sleep(5)
                    
        except Exception as e:
            print(f"💀 FATAL ERROR [{account_name}]: {str(e)}")
        finally:
            if account['client']:
                try:
                    account['client'].disconnect()
                except:
                    pass

    def start_all(self, thread_id: str, message_content: str):
        """Start all accounts with threading"""
        print(f"🚀 Starting {len(self.accounts)} accounts...")
        threads = []
        
        for account in self.accounts:
            thread = threading.Thread(
                target=self.worker_thread,
                args=(account, thread_id, message_content),
                daemon=True
            )
            threads.append(thread)
            thread.start()
            time.sleep(1)  # Stagger connections
            
        return threads

    def stop_all(self):
        """Stop all accounts"""
        print("🛑 Stopping all accounts...")
        self.stop_event.set()
        
        for account in self.accounts:
            if account['client']:
                try:
                    account['client'].disconnect()
                except:
                    pass

    def print_stats(self):
        """Print message statistics"""
        print("\n📊 Message Statistics:")
        total = 0
        for account_name, count in self.message_stats.items():
            print(f"  📱 [{account_name}]: {count} messages")
            total += count
        print(f"  📈 Total: {total} messages")

# ============================================================================
# UTILITY FUNCTIONS FOR EASY USAGE
# ============================================================================

def create_facebook_client(cookies: str, options: dict = None) -> FacebookMQTTAllInOne:
    """Create Facebook MQTT All-in-One client"""
    return FacebookMQTTAllInOne(cookies, options)

def send_simple_message(cookies: str, thread_id: str, message: str, options: dict = None):
    """Simple function to send a message"""
    with create_facebook_client(cookies, options) as client:
        return client.send_message(text=message, thread_id=thread_id)

def share_simple_link(cookies: str, thread_id: str, url: str, text: str = "", options: dict = None):
    """Simple function to share a link"""
    with create_facebook_client(cookies, options) as client:
        return client.share_link(url, thread_id, text)

def share_simple_contact(cookies: str, thread_id: str, contact_id: str, text: str = "", options: dict = None):
    """Simple function to share a contact"""
    with create_facebook_client(cookies, options) as client:
        return client.share_contact(contact_id, thread_id, text)

def send_simple_poll(cookies: str, thread_id: str, question: str, options: List[str], client_options: dict = None):
    """Simple function to send a poll"""
    with create_facebook_client(cookies, client_options) as client:
        return client.send_poll(thread_id, question, options)

def set_simple_theme(cookies: str, thread_id: str, theme_name: str = "main", options: dict = None):
    """Simple function to set theme"""
    with create_facebook_client(cookies, options) as client:
        return client.set_theme(thread_id, theme_name=theme_name)

def list_themes():
    """List all available themes"""
    print("Available themes:")
    for i, theme in enumerate(THEMES, 1):
        print(f"{i:2d}. {theme['name']} (ID: {theme['id']})")

# ============================================================================
# NEW API FUNCTIONS FOR BOT SUPPORT
# ============================================================================

def api_request(client, endpoint, data_dict):
    """
    Gửi POST request đến Facebook API sử dụng mainRequests.
    Trả về response object của requests.
    """
    cookies = parse_cookie_string(client.cookies)
    headers = Headers(cookies)
    fb_data = client.dataFB
    data = {
        "fb_dtsg": fb_data.get("fb_dtsg", ""),
        "jazoest": fb_data.get("jazoest", ""),
        "__user": str(fb_data.get("FacebookID", "")),
        "av": str(fb_data.get("FacebookID", "")),
        "__a": "1",
        "__req": "1",
        "__rev": fb_data.get("clientRevision", ""),
    }
    data.update(data_dict)
    request_params = mainRequests(endpoint, data, client.cookies)
    response = requests.post(
        request_params["url"],
        data=request_params["data"],
        headers=request_params["headers"],
        cookies=request_params["cookies"],
        timeout=10
    )
    return response


def kick_user(client, uid, thread_id):
    """Kick thành viên khỏi nhóm"""
    data = {
        "uid": str(uid),
        "tid": str(thread_id),
    }
    return api_request(client, "https://www.facebook.com/chat/remove_participants/", data)


def toggle_link_sharing(client, thread_id, disable=True):
    """Bật/tắt chế độ duyệt thành viên (approval mode) - thay thế link sharing không còn hỗ trợ"""
    data = {
        "set_mode": "1" if disable else "0",
        "thread_fbid": str(thread_id),
    }
    return api_request(client, "https://www.facebook.com/messaging/set_approval_mode/?dpr=1", data)


def set_thread_name(client, thread_id, new_name):
    """Đổi tên nhóm chat"""
    data = {
        "thread_fbid": thread_id,
        "thread_name": new_name
    }
    return api_request(client, "https://www.facebook.com/messaging/set_thread_name/", data)


def send_reaction(client, emoji, thread_id, message_id):
    """Gửi reaction (cảm xúc) vào một tin nhắn"""
    data = {
        "thread_fbid": thread_id,
        "message_id": message_id,
        "reaction": emoji,
        "action_type": "1"
    }
    return api_request(client, "https://www.facebook.com/messaging/set_message_reaction/", data)


def join_group_via_link(link, client):
    """Tham gia nhóm qua link (trả về (True/False, message))"""
    m = re.search(r'facebook\.com/groups/(\d+)', link)
    if not m:
        m = re.search(r'facebook\.com/messages/t/(\d+)', link)
    if not m:
        return False, "Không tìm thấy ID box trong link"
    thread_id = m.group(1)
    data = {
        "thread_fbid": thread_id,
        "action": "join"
    }
    resp = api_request(client, "https://www.facebook.com/messaging/join/", data)
    try:
        result = resp.json()
    except:
        return False, f"Lỗi phản hồi: {resp.text[:100]}"
    if result.get("status") == "ok" or "ok" in resp.text.lower():
        return True, f"Đã tham gia box {thread_id}"
    return False, f"Lỗi: {result.get('error', 'unknown')}"

# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    # Example usage
    print("""
    🌟 Facebook MQTT All-in-One Tool 🌟
    
    Tích hợp đầy đủ các tính năng:
    ✅ Send Message (với mention, reply)
    ✅ Typing Indicator (normal, burst, forever)
    ✅ Share Link
    ✅ Share Contact  
    ✅ Send Poll
    ✅ Set Theme
    ✅ Block/Unblock User
    ✅ Add User to Group
    ✅ Rename Group
    ✅ Multi-Cookie Support
    """)
    
    # Example cookies - replace with your actual cookies
    cookies = "sb=8JKEaAMiZOtU4aM6oJJtqfxp;dpr=2.1162948608398438;c_user=100090096111312;wd=926x1801;fr=1yESPUuXtqcPlPi7a.AWfwzvC2_dwOV2_1T5lST_PePf647rWP_kzfyqlQw2oKvvy2Bzw.BoiU04..AAA.0.0.BoiU04.AWchXWGaGmr0yPiGlmayXBSVL4Q;xs=18%3AUofM5NWZBbXUFw%3A2%3A1753828350%3A-1%3A-1%3A%3AAcXtWZrXAdXUnni8Sqb9OvMmd1t8--c_C1k40Glfxw;"
    thread_id = "24065311806495886"
    
    try:
        # Method 1: Using context manager for single operations
        with create_facebook_client(cookies, {"debug": True}) as client:
            print("🔗 Connected to Facebook MQTT")
            
            # Send text message
            client.send_message("Hello from All-in-One MQTT! 🚀", thread_id)
            
            # Send message with mention
            client.send_message(
                "Hello @John Doe! 👋",
                thread_id,
                mention={"id": "61550687319101", "tag": "@John Doe"}
            )
            
            # Send typing indicator
            client.send_typing_indicator(thread_id, True)
            time.sleep(3)
            client.send_typing_indicator(thread_id, False)
            
            # Share a link
            client.share_link(
                "https://github.com",
                thread_id,
                "Check out this awesome repository! 🔥"
            )
            
            # Send a poll
            client.send_poll(
                thread_id,
                "What's your favorite programming language? 💻",
                ["Python 🐍", "JavaScript 🟨", "Java ☕", "C++ ⚡"]
            )
            
            # Set random theme
            client.set_theme(thread_id)
            
            # Set specific theme
            client.set_theme(thread_id, theme_name="Love")
            
            # Get thread info
            thread_info = client.get_thread_info(thread_id)
            print(f"📋 Thread info: {thread_info}")
            
            # List available themes
            client.list_all_themes()
            
            print("✅ All operations completed successfully!")
            
        # Method 2: Manual connection management
        print("\n🔧 Testing manual connection...")
        client = create_facebook_client(cookies)
        
        if client.connect():
            # Typing burst example
            client.send_typing_burst(thread_id, count=5, interval=1.0)
            
            # Add user to group example
            # client.add_user_to_group("user_id_here", thread_id)
            
            # Rename group example
            # client.rename_group("New Group Name! 🎉", thread_id)
            
            # Block user example
            # client.block_user("user_id_to_block")
            
            client.disconnect()
            
        print("✨ Demo completed!")
        
    except KeyboardInterrupt:
        print("\n🛑 Interrupted by user")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    print("👋 Goodbye!")