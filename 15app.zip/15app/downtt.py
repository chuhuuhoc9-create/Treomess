"""
downtt.py — Tải TikTok cho Facebook Messenger bot
Cú pháp: /downtt <url_tiktok>
"""

import requests
import time
import threading
from datetime import datetime
from io import BytesIO

API_URL = "https://www.tikwm.com/api/"

# ── helper: tải bytes từ URL ─────────────────────────────────────────
def _fetch_bytes(url: str, timeout: int = 30) -> bytes:
    headers = {"User-Agent": "Mozilla/5.0"}
    r = requests.get(url, headers=headers, timeout=timeout)
    r.raise_for_status()
    return r.content

# ── lệnh chính ──────────────────────────────────────────────────────
def cmd_downtt(client, thread_id: str, full_args: str):
    """Dispatcher cho /downtt — chạy trong thread riêng."""
    if not full_args or not full_args.strip().startswith("http"):
        client.send_message(
            text="⚠️ Cú pháp: /downtt <url_tiktok>\nVí dụ: /downtt https://vt.tiktok.com/xxx",
            thread_id=thread_id,
        )
        return
    threading.Thread(
        target=_worker, args=(client, thread_id, full_args.strip()), daemon=True
    ).start()


def _worker(client, thread_id: str, url: str):
    try:
        client.send_message(text="⏳ Đang xử lý TikTok...", thread_id=thread_id)

        # ── gọi TikWM API ────────────────────────────────────────────
        resp = requests.get(API_URL, params={"url": url}, timeout=20)
        data = resp.json()

        if data.get("code") != 0:
            client.send_message(
                text=f"🚫 Lỗi API: {data.get('msg', 'URL không hợp lệ hoặc video đã bị xóa')}",
                thread_id=thread_id,
            )
            return

        item       = data["data"]
        title      = item.get("title") or "Không có tiêu đề"
        username   = item.get("author", {}).get("unique_id", "unknown")
        nickname   = item.get("author", {}).get("nickname", "Không rõ")
        video_id   = item.get("id", "unknown")
        region     = item.get("region", "N/A")
        duration   = item.get("duration", 0)
        size_mb    = item.get("size", 0) / 1048576 if item.get("size") else 0
        play_count = item.get("play_count", 0)
        like_count = item.get("digg_count", 0)
        ct         = item.get("create_time", 0)
        created    = datetime.fromtimestamp(ct).strftime("%Y-%m-%d %H:%M") if ct else "N/A"

        info_msg = (
            f"🎥 {title}\n"
            f"{'─'*28}\n"
            f"👤 Tác giả: {nickname} (@{username})\n"
            f"🌍 Khu vực: {region} | 🗓️ {created}\n"
            f"📊 View: {play_count:,} | ❤️ Like: {like_count:,}\n"
            f"🗂️ Dung lượng: {round(size_mb, 2)} MB"
        )

        video_url = item.get("play")
        images    = item.get("images", [])

        # ── trường hợp 1: VIDEO ──────────────────────────────────────
        if video_url and duration > 0:
            if size_mb > 25:
                # Quá lớn → gửi link thay vì file
                client.send_message(
                    text=f"{info_msg}\n{'─'*28}\n▶️ Link video (quá lớn để gửi):\n{video_url}",
                    thread_id=thread_id,
                )
            else:
                # Tải về rồi gửi ảnh thumbnail + link (MQTT chưa hỗ trợ send_video)
                client.send_message(
                    text=f"{info_msg}\n{'─'*28}\n▶️ Xem/tải video:\n{video_url}",
                    thread_id=thread_id,
                )
                # Gửi thumbnail nếu có
                thumb_url = item.get("cover") or item.get("origin_cover")
                if thumb_url:
                    try:
                        thumb_bytes = _fetch_bytes(thumb_url, timeout=15)
                        client.send_image(
                            image_data=thumb_bytes,
                            thread_id=thread_id,
                            caption="🖼️ Thumbnail",
                        )
                    except Exception:
                        pass

        # ── trường hợp 2: ALBUM ảnh (Slideshow) ─────────────────────
        elif images:
            client.send_message(text=info_msg, thread_id=thread_id)
            for idx, img_url in enumerate(images, 1):
                try:
                    img_bytes = _fetch_bytes(img_url, timeout=20)
                    client.send_image(
                        image_data=img_bytes,
                        thread_id=thread_id,
                        caption=f"🖼️ Ảnh {idx}/{len(images)}",
                    )
                    time.sleep(0.5)  # tránh flood
                except Exception as ie:
                    client.send_message(
                        text=f"⚠️ Không gửi được ảnh {idx}: {ie}", thread_id=thread_id
                    )

        else:
            client.send_message(
                text=f"{info_msg}\n⚠️ Không tìm thấy nội dung tải được.", thread_id=thread_id
            )

        # ── gửi thêm nhạc nền ────────────────────────────────────────
        music = item.get("music_info", {})
        if music.get("play"):
            try:
                audio_bytes = _fetch_bytes(music["play"], timeout=30)
                music_title = music.get("title", "TikTok Music")
                music_author = music.get("author", nickname)
                client.send_audio(
                    audio_data=audio_bytes,
                    thread_id=thread_id,
                    caption=f"🎵 {music_title} — {music_author}",
                )
            except Exception as ae:
                client.send_message(
                    text=f"⚠️ Không tải được nhạc nền: {ae}", thread_id=thread_id
                )

    except Exception as e:
        client.send_message(text=f"🚫 Lỗi /downtt: {e}", thread_id=thread_id)