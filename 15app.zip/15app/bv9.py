import discord
from discord.ext import commands
import threading
import time
import json
import uuid
import ssl
import paho.mqtt.client as mqtt
import warnings
import re
import random
import gc
import os
import hashlib
import ctypes
import string
import aiohttp
import asyncio
import wave
import struct
import math
import signal
import multiprocessing
from urllib.parse import urlparse
from collections import defaultdict
from datetime import datetime
from typing import List
import requests
import json
import base64
from Crypto.Cipher import AES
from enum import Enum
import smtplib
import ssl
from email.mime.text import MIMEText
import httpx
import certifi
import sys
import os
import imageio_ffmpeg
import threading
import time
import subprocess
import aiohttp
import datetime
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
import asyncio
import qrcode
# Import bot chat (cùng folder)
try:
    import botchat
    print("✅ Đã import botchat.py thành công!")
except ImportError as e:
    print(f"⚠️ Không import được botchat.py: {e}")
    print("💡 Hãy đảm bảo file botchat.py cùng folder với bot.py")

# Biến quản lý bot chat
chat_bot_thread = None
chat_bot_running = False

def run_chat_bot(cookie, admin_uid):
    """Chạy bot chat trong thread riêng"""
    global chat_bot_running
    
    # Redirect input để tự động nhập
    import builtins
    original_input = builtins.input
    
    def mock_input(prompt):
        if "Cookie" in prompt:
            return cookie
        elif "UID Admin" in prompt:
            return admin_uid
        elif "box" in prompt:
            return ""
        return original_input(prompt)
    
    try:
        builtins.input = mock_input
        # Gọi hàm main của bot chat
        if hasattr(botchat, 'main'):
            botchat.main()
        else:
            print("❌ botchat.py không có hàm main()")
    except Exception as e:
        print(f"❌ Lỗi bot chat: {e}")
    finally:
        builtins.input = original_input
        chat_bot_running = False
# ============= FAKE AIRLINE TICKET =============
TEMPLATE_TICKET_URL = "https://i.imgur.com/Avtwk83.png"
# ============= FAKE VIETNAM AIRLINES =============
PHOI_VA_URL = "https://i.imgur.com/alus95l.png"        
# ============= FAKE MB BANK =============
PHOI_LIST = {
    "1": "https://i.imgur.com/PxAvv1c.png", "2": "https://i.imgur.com/rTJ5ETf.png",
    "3": "https://i.imgur.com/qTCMUtq.png", "4": "https://i.imgur.com/s09skKS.png",
    "5": "https://i.imgur.com/LeT3Kda.png", "6": "https://i.imgur.com/y2hAIV7.png",
    "7": "https://i.imgur.com/U5W9HaR.png", "8": "https://i.imgur.com/jmCD60P.png",
    "9": "https://i.imgur.com/dRxiFNh.png", "10": "https://i.imgur.com/iu7Vfqr.png",
    "11": "https://i.imgur.com/57j1W8S.png", "12": "https://i.imgur.com/1cwo7yO.png",
    "13": "https://i.imgur.com/K1JVXaK.png", "14": "https://i.imgur.com/htXWkry.png",
    "15": "https://i.imgur.com/1GK1mlM.jpeg", "16": "https://i.imgur.com/2iCnlaj.jpeg",
    "17": "https://i.imgur.com/4n7PaQW.jpeg", "18": "https://i.imgur.com/S0gQ5Bf.jpeg",
    "19": "https://i.imgur.com/Eq5eK9q.jpeg", "20": "https://i.imgur.com/8W7Ss1E.jpeg",
    "21": "https://i.imgur.com/4K0jjEj.jpeg"
}

PHOI_CONFIG = {
    "1": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "white", "time_color": "white"},
    "2": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "white", "time_color": "white"},
    "3": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#331725", "time_color": "#222222"},
    "4": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#222222", "time_color": "#222222"},
    "5": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "white", "time_color": "#222222"},
    "6": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "white", "time_color": "white"},
    "7": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "white", "time_color": "white"},
    "8": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "white", "time_color": "white"},
    "9": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "white", "time_color": "white"},
    "10": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#222222", "time_color": "#222222"},
    "11": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#222222", "time_color": "#222222"},
    "12": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#222222", "time_color": "#222222"},
    "13": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#222222", "time_color": "#222222"},
    "14": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#222222", "time_color": "#222222"},
    "15": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#222222", "time_color": "#222222"},
    "16": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "white", "time_color": "white"},
    "17": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "white", "time_color": "white"},
    "18": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#222222", "time_color": "#222222"},
    "19": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "white", "time_color": "white"},
    "20": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#222222", "time_color": "#222222"},
    "21": {"money": (370, 460), "time": (50, 45), "pin": (835, 45), "money_color": "#222222", "time_color": "#222222"}
}

PIN_ICONS = {
    "100": "https://i.imgur.com/8sZpcNS.png", "80": "https://i.imgur.com/1sOMWFG.png",
    "60": "https://i.imgur.com/yNRzY1J.png", "40": "https://i.imgur.com/35UiCk0.png",
    "35": "https://i.imgur.com/RBjkxE2.png", "22": "https://i.imgur.com/iCy35zv.png",
    "10": "https://i.imgur.com/utEDaj5.png",
}

FONT_MONEY = "handlers/fonts/SF-Pro-Rounded-Bold.otf"
FONT_TIME = "handlers/fonts/SF-Pro-Rounded-Bold.otf"

NEN_NAMES = {
    "1": "MB Mặc định", "2": "MB Cánh én mùa xuân", "3": "MB Dịu dàng",
    "4": "MB Mèo thần tài", "5": "MB Monday Mood", "6": "MB Năm mới rực rỡ",
    "7": "MB Nhịp đập sân cỏ", "8": "MB Tiến bước vững vàng", "9": "MB Tự hào Việt Nam",
    "10": "MB Hi Green", "11": "MB Khát vọng vươn cao", "12": "MB Bình an",
    "13": "MB Be The Sky", "14": "MB Sweet Love", "15": "MB Khám phá",
    "16": "MB Phố làng", "17": "MB Chinh phục đỉnh cao", "18": "MB Pickleball",
    "19": "MB Dream Big", "20": "MB Trẻ trung", "21": "MB Trường Sa xanh"
}
def format_money(value):
    try:
        return f"{int(value):,}"
    except:
        return str(value)

async def load_image(url, retries=3):
    headers = {"User-Agent": "Mozilla/5.0"}
    for i in range(retries):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as resp:
                    if resp.status == 200:
                        return await resp.read()
        except Exception as e:
            print(f"Lỗi tải ảnh: {e}, thử lại {i+1}/{retries}")
        await asyncio.sleep(1)
    return None
PHP_DIR = os.path.join(os.path.dirname(__file__), "cccd")
BASE_PORT = 8080
current_port = BASE_PORT
last_template = {}

def get_next_port():
    global current_port
    current_port += 1
    return current_port
   
# ============= FAKE SUNWIN =============
TEMPLATE_SUNWIN_URL = "https://i.imgur.com/DCPRwwE.jpeg"
FONT_NAME_SUNWIN = "handlers/fonts/SF-Pro-Rounded-Bold.otf"
FONT_AMOUNT_SUNWIN = "handlers/fonts/SVN-Arial Regular.ttf"
def format_amount(num):
    try:
        return f"{int(num):,}"
    except:
        return str(num)
# ============= FAKE VIETCOMBANK =============
PHOI_VCB_URL = "https://i.imgur.com/R0qWfzv.jpeg"        
# ============= FAKE OKX =============
PHOI_OKX_URL = "https://i.imgur.com/goAaOJp.jpeg"
PIN_ICONS_OKX = {
    "100": "https://i.imgur.com/8sZpcNS.png", "80": "https://i.imgur.com/1sOMWFG.png",
    "60": "https://i.imgur.com/yNRzY1J.png", "40": "https://i.imgur.com/35UiCk0.png",
    "35": "https://i.imgur.com/RBjkxE2.png", "22": "https://i.imgur.com/iCy35zv.png",
    "10": "https://i.imgur.com/utEDaj5.png",
}
FONT_BOLD = "handlers/fonts/SF-Pro-Rounded-Bold.otf"
FONT_REG = "handlers/fonts/SF-Pro-Rounded-Regular.otf"

async def load_image(url, retries=3):
    headers = {"User-Agent": "Mozilla/5.0"}
    for i in range(retries):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as resp:
                    if resp.status == 200:
                        return await resp.read()
        except Exception as e:
            print(f"Lỗi tải ảnh: {e}, thử lại {i+1}/{retries}")
        await asyncio.sleep(1)
    return None

def generate_txid(length=67):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def generate_ref():
    return ''.join(random.choices(string.digits, k=9))
    
# ============= FAKE BANK TRANSACTION =============
PHOIS = {
    "1": {"url": "https://i.imgur.com/1MRU5dt.png", "money_color": "#1F1DA4"},
    "2": {"url": "https://i.imgur.com/2oTl8a1.png", "money_color": "#A3412E"},
    "3": {"url": "https://i.imgur.com/e3n8f8J.png", "money_color": "#D5517E"},
}

BANK_INFO = {
    "MB": {"logo": "https://i.imgur.com/dJXJiMz.png", "name": "MBBank (MB)"},
    "VCB": {"logo": "https://i.imgur.com/elWpyWR.png", "name": "Vietcombank (VCB)"},
    "TCB": {"logo": "https://i.imgur.com/Pjn8MYL.png", "name": "Techcombank (TCB)"},
    "BIDV": {"logo": "https://i.imgur.com/30zY8oB.png", "name": "BIDV"},
    "TPBANK": {"logo": "https://i.imgur.com/Hz4Q2wm.png", "name": "TP Bank (TPB)"},
    "OCB": {"logo": "https://i.imgur.com/JBgN9yl.png", "name": "OCB"},
    "AGB": {"logo": "https://i.imgur.com/h8E7kuk.png", "name": "Agribank (AGB)"},
    "SHB": {"logo": "https://i.imgur.com/6J3HHG7.png", "name": "SHB"},
    "VPBANK": {"logo": "https://i.imgur.com/HrgjHZ6.png", "name": "VP Bank (VPB)"},
    "ACB": {"logo": "https://i.imgur.com/VyhnvZZ.png", "name": "ACB"},
    "VTB": {"logo": "https://i.imgur.com/GwdNaXo.png", "name": "Vietinbank (CTG)"},
}
def format_money(amount):
    try:
        num = int(str(amount).replace(".", "").replace(",", ""))
        return f"{num:,} VND"
    except:
        return f"{amount} VND"
# ============= HÀM ĐỌC FILE CHUẨN =============
def get_file_path(ctx, filename, default_to_root=True):
    """Lấy đường dẫn file ưu tiên: user_folder -> root"""
    if not filename.endswith('.txt'):
        filename += '.txt'
    
    # Thư mục user
    user_folder = os.path.join(UPLOAD_DIR, str(ctx.author.id))
    user_filepath = os.path.join(user_folder, filename)
    
    if os.path.exists(user_filepath):
        return user_filepath, True
    
    if default_to_root:
        if os.path.exists(filename):
            return filename, False
    
    return None, False

def read_file_lines(ctx, filename, default_to_root=True):
    """Đọc file trả về list dòng"""
    filepath, is_user = get_file_path(ctx, filename, default_to_root)
    if not filepath:
        return None, None, False
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = [l.strip() for l in f if l.strip()]
    return lines, filepath, is_user

VOICE_SESSIONS = {}  
# ============= TASK SMS =============
sms_tasks = {}

def sms_spam_task(phone, count, stop_event, task_id, user_id):
    """Task spam SMS"""
    try:
        from spm import run_spam_direct
        
        print(f"[SMS Task {task_id}] Bắt đầu spam {phone} - {count} lần")
        
        # Gọi hàm spam trực tiếp
        for i in range(1, count + 1):
            if stop_event.is_set():
                print(f"[SMS Task {task_id}] Đã dừng giữa chừng!")
                break
            
            print(f"[SMS Task {task_id}] Lần {i}/{count}")
            run(phone, i)  # Gọi hàm run từ spm.py
            
            if i < count and not stop_event.is_set():
                # Delay 4 giây giữa các lần
                for j in range(4, 0, -1):
                    if stop_event.is_set():
                        break
                    time.sleep(1)
        
        print(f"[SMS Task {task_id}] ✅ Hoàn thành!")
        
    except Exception as e:
        print(f"[SMS Task {task_id}] Lỗi: {e}")


# ============= CPU GUARD =============
TARGET_CPU_PERCENT = float(os.getenv("CPU_GUARD_TARGET_PERCENT", "30.0"))
CHECK_INTERVAL = float(os.getenv("CPU_GUARD_CHECK_INTERVAL", "1.0"))
RESUME_FACTOR = float(os.getenv("CPU_GUARD_RESUME_FACTOR", "0.75"))
MAX_SUSPEND_SECONDS = float(os.getenv("CPU_GUARD_MAX_SUSPEND", "5"))
MIN_SUSPEND_SECONDS = float(os.getenv("CPU_GUARD_MIN_SUSPEND", "0.1"))

try:
    import psutil
    USE_PSUTIL = True
except:
    psutil = None
    USE_PSUTIL = False

NUM_CPUS = os.cpu_count() or 1
PARENT_PID = os.getpid()

def _measure_process_cpu_percent_fallback(pid, interval):
    try:
        if pid != os.getpid():
            return 0.0
        t0 = time.perf_counter()
        cpu0 = time.process_time()
        time.sleep(interval)
        t1 = time.perf_counter()
        cpu1 = time.process_time()
        wall = t1 - t0
        if wall <= 0:
            return 0.0
        cpu_delta = cpu1 - cpu0
        percent = (cpu_delta / wall) * 100.0
        return max(0.0, percent)
    except:
        return 0.0

def _suspend_process_unix(pid):
    try:
        os.kill(pid, signal.SIGSTOP)
        return True
    except:
        return False

def _resume_process_unix(pid):
    try:
        os.kill(pid, signal.SIGCONT)
        return True
    except:
        return False

def _suspend_process_psutil(p_proc):
    try:
        p_proc.suspend()
        return True
    except:
        return False

def _resume_process_psutil(p_proc):
    try:
        p_proc.resume()
        return True
    except:
        return False

def _watchdog_main(target_percent, check_interval, resume_factor, max_suspend, min_suspend, pid):
    use_ps = USE_PSUTIL and (psutil is not None)
    if use_ps:
        try:
            p = psutil.Process(pid)
        except:
            p = None
            use_ps = False
    else:
        p = None

    target = float(target_percent)
    resume_threshold = target * float(resume_factor)
    
    while True:
        try:
            if use_ps:
                if not p.is_running():
                    break
            else:
                try:
                    os.kill(pid, 0)
                except OSError:
                    break

            if use_ps:
                try:
                    usage = p.cpu_percent(interval=check_interval)
                except:
                    try:
                        usage = psutil.cpu_percent(interval=check_interval) / NUM_CPUS
                    except:
                        usage = 0.0
            else:
                usage = _measure_process_cpu_percent_fallback(pid, check_interval)

            if usage is None:
                usage = 0.0
            usage = float(usage)

            if usage > target:
                try:
                    factor = max(0.1, (usage / target) - 1.0)
                except:
                    factor = 1.0
                suspend_time = check_interval * min(max(1.0, factor), max(10.0))
                suspend_time = max(min_suspend, min(suspend_time, max_suspend))

                suspended = False
                if use_ps and p is not None:
                    suspended = _suspend_process_psutil(p)
                else:
                    if hasattr(signal, "SIGSTOP"):
                        suspended = _suspend_process_unix(pid)

                if suspended:
                    time.sleep(suspend_time)
                    if use_ps and p is not None:
                        _resume_process_psutil(p)
                    else:
                        if hasattr(signal, "SIGCONT"):
                            _resume_process_unix(pid)
                    time.sleep(max(0.01, check_interval * 0.1))
                else:
                    time.sleep(min(suspend_time, max(1.0, check_interval)))
            else:
                time.sleep(max(0.01, check_interval * 0.5))
        except:
            try:
                time.sleep(1.0)
            except:
                break

def _start_watchdog_subprocess():
    if os.getenv("CPU_GUARD_DISABLE", "0") == "1":
        return None
    try:
        tgt = float(os.getenv("CPU_GUARD_TARGET_PERCENT", str(TARGET_CPU_PERCENT)))
    except:
        tgt = TARGET_CPU_PERCENT
    try:
        chk = float(os.getenv("CPU_GUARD_CHECK_INTERVAL", str(CHECK_INTERVAL)))
    except:
        chk = CHECK_INTERVAL
    try:
        rf = float(os.getenv("CPU_GUARD_RESUME_FACTOR", str(RESUME_FACTOR)))
    except:
        rf = RESUME_FACTOR
    try:
        ms = float(os.getenv("CPU_GUARD_MAX_SUSPEND", str(MAX_SUSPEND_SECONDS)))
    except:
        ms = MAX_SUSPEND_SECONDS
    try:
        mins = float(os.getenv("CPU_GUARD_MIN_SUSPEND", str(MIN_SUSPEND_SECONDS)))
    except:
        mins = MIN_SUSPEND_SECONDS

    p = multiprocessing.Process(
        target=_watchdog_main,
        args=(tgt, chk, rf, ms, mins, PARENT_PID),
        daemon=False
    )
    p.start()
    return p

try:
    _cpu_guard_watchdog_process = _start_watchdog_subprocess()
except:
    _cpu_guard_watchdog_process = None

# ============= AUTO CLEAN MEMORY =============
def auto_clean():
    while True:
        gc.collect()
        try:
            ctypes.CDLL('libc.so.6').malloc_trim(0)
        except:
            pass
        time.sleep(3600)

threading.Thread(target=auto_clean, daemon=True).start()

# ============= NHẬP THÔNG TIN =============
print("=" * 50)
print("🤖 FACEBOOK + TELEGRAM + DISCORD BOT 🤖")
print("=" * 50)
BOT_TOKEN = input("📌 Token Discord Bot: ").strip()
ADMIN_ID = int(input("👑 ID Admin Gốc: ").strip())
PREFIX = input("⚙️ Prefix (VD: ! / . / $): ").strip()
print("=" * 50)
print("✅ Đang khởi động bot...")
print("=" * 50)

ADMIN_IDS = {ADMIN_ID}
active_tasks = {}
task_counter = 0
UPLOAD_DIR = "uploaded_files"
os.makedirs(UPLOAD_DIR, exist_ok=True)
AUDIO_PATH = os.path.join(UPLOAD_DIR, "voice.mp3")

# ============= EMAIL CLASS =============
class EmailSender:
    def __init__(self, email, password, server="smtp.gmail.com", port=465):
        self.email = email
        self.password = password
        self.server = server
        self.port = port
        self.active = True
    
    def send(self, to_email, content):
        if not self.active:
            return False, "Account disabled"
        
        context = ssl.create_default_context()
        try:
            with smtplib.SMTP_SSL(self.server, self.port, context=context) as server:
                server.login(self.email, self.password)
                msg = MIMEText(content)
                msg["From"] = self.email
                msg["To"] = to_email
                msg["Subject"] = " "
                server.sendmail(self.email, to_email, msg.as_string())
                return True, None
        except smtplib.SMTPAuthenticationError:
            self.active = False
            return False, "Sai email/pass"
        except smtplib.SMTPDataError as e:
            if b'Quota' in str(e).encode() or b'limit' in str(e).encode():
                self.active = False
                return False, "Hết quota"
            return False, str(e)
        except Exception as e:
            return False, str(e)

# ============= HÀM XỬ LÝ =============
def parse_email_accounts(accounts_str):
    """Parse email|pass/email|pass/... thành list"""
    accounts = []
    for entry in accounts_str.strip().split("/"):
        if "|" in entry:
            email, password = entry.strip().split("|", 1)
            accounts.append({"email": email.strip(), "password": password.strip(), "active": True})
    return accounts

# ============= TASK EMAIL =============
def treogmail_task(accounts, to_email, content, delay, stop_event, task_id, user_id):
    """Vòng lặp gửi email spam"""
    senders = [EmailSender(acc["email"], acc["password"]) for acc in accounts]
    
    if not senders:
        print(f"[Email Task {task_id}] Không có tài khoản nào!")
        return
    
    acc_index = 0
    while not stop_event.is_set():
        active = [s for s in senders if s.active]
        if not active:
            print(f"[Email Task {task_id}] Tất cả tài khoản bị lỗi! Reset...")
            for s in senders:
                s.active = True
            active = senders
        
        sender = active[acc_index % len(active)]
        success, error = sender.send(to_email, content)
        
        if success:
            print(f"[Email Task {task_id}] ✅ Đã gửi từ {sender.email} -> {to_email}")
        else:
            print(f"[Email Task {task_id}] ❌ {sender.email}: {error}")
        
        acc_index += 1
        
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)

# ============= THEMES DATA =============
THEMES = [
    {"id": "3650637715209675", "name": "Besties"},
    {"id": "769656934577391", "name": "Women's History Month"},
    {"id": "702099018755409", "name": "Dune: Part Two"},
    {"id": "1480404512543552", "name": "Avatar: The Last Airbender"},
    {"id": "952656233130616", "name": "J.Lo"},
    {"id": "741311439775765", "name": "Love"},
    {"id": "215565958307259", "name": "Bob Marley: One Love"},
    {"id": "194982117007866", "name": "Football"},
    {"id": "1743641112805218", "name": "Soccer"},
    {"id": "730357905262632", "name": "Mean Girls"},
    {"id": "1270466356981452", "name": "Wonka"},
    {"id": "704702021720552", "name": "Pizza"},
    {"id": "1013083536414851", "name": "Wish"},
    {"id": "359537246600743", "name": "Trolls"},
    {"id": "173976782455615", "name": "The Marvels"},
    {"id": "2317258455139234", "name": "One Piece"},
    {"id": "6685081604943977", "name": "1989"},
    {"id": "1508524016651271", "name": "Avocado"},
    {"id": "265997946276694", "name": "Loki Season 2"},
    {"id": "6584393768293861", "name": "olivia rodrigo"},
    {"id": "845097890371902", "name": "Baseball"},
    {"id": "292955489929680", "name": "Lollipop"},
    {"id": "976389323536938", "name": "Loops"},
    {"id": "810978360551741", "name": "Parenthood"},
    {"id": "195296273246380", "name": "Bubble Tea"},
    {"id": "6026716157422736", "name": "Basketball"},
    {"id": "693996545771691", "name": "Elephants & Flowers"},
    {"id": "390127158985345", "name": "Chill"},
    {"id": "365557122117011", "name": "Support"},
    {"id": "339021464972092", "name": "Music"},
    {"id": "1060619084701625", "name": "Lo-Fi"},
    {"id": "3190514984517598", "name": "Sky"},
    {"id": "627144732056021", "name": "Celebration"},
    {"id": "275041734441112", "name": "Care"},
    {"id": "3082966625307060", "name": "Astrology"},
    {"id": "539927563794799", "name": "Cottagecore"},
    {"id": "527564631955494", "name": "Ocean"},
    {"id": "230032715012014", "name": "Tie-Dye"},
    {"id": "788274591712841", "name": "Monochrome"},
    {"id": "3259963564026002", "name": "Default"},
    {"id": "724096885023603", "name": "Berry"},
    {"id": "624266884847972", "name": "Candy"},
    {"id": "273728810607574", "name": "Unicorn"},
    {"id": "262191918210707", "name": "Tropical"},
    {"id": "2533652183614000", "name": "Maple"},
    {"id": "909695489504566", "name": "Sushi"},
    {"id": "582065306070020", "name": "Rocket"},
    {"id": "557344741607350", "name": "Citrus"},
    {"id": "280333826736184", "name": "Lollipop"},
    {"id": "271607034185782", "name": "Shadow"},
    {"id": "1257453361255152", "name": "Rose"},
    {"id": "571193503540759", "name": "Lavender"},
    {"id": "2873642949430623", "name": "Tulip"},
    {"id": "3273938616164733", "name": "Classic"},
    {"id": "403422283881973", "name": "Apple"},
    {"id": "3022526817824329", "name": "Peach"},
    {"id": "672058580051520", "name": "Honey"},
    {"id": "3151463484918004", "name": "Kiwi"},
    {"id": "736591620215564", "name": "Ocean"},
    {"id": "193497045377796", "name": "Grape"}
]

# ============= UTILITY FUNCTIONS =============
def generate_offline_threading_id() -> str:
    ret = int(time.time() * 1000)
    value = random.randint(0, 4294967295)
    binary_str = format(value, "022b")[-22:]
    msgs = bin(ret)[2:] + binary_str
    return str(int(msgs, 2))

def json_minimal(data) -> str:
    return json.dumps(data, separators=(",", ":"))

def parse_cookie_string(cookie_string: str) -> dict:
    cookies = {}
    for part in cookie_string.split(";"):
        if "=" in part:
            key, value = part.strip().split("=", 1)
            cookies[key] = value
    return cookies

def gen_cid():
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=8)) + '-' + \
           ''.join(random.choices(string.ascii_lowercase + string.digits, k=4)) + '-' + \
           ''.join(random.choices(string.ascii_lowercase + string.digits, k=4)) + '-' + \
           ''.join(random.choices(string.ascii_lowercase + string.digits, k=4)) + '-' + \
           ''.join(random.choices(string.ascii_lowercase + string.digits, k=12))

def gen_sid():
    return random.randint(1, 2 ** 53)

def runtime(start):
    sec = int(time.time() - start)
    d = sec // 86400
    h = (sec % 86400) // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    if d > 0:
        return f"{d}d {h}h"
    elif h > 0:
        return f"{h}h {m}m"
    elif m > 0:
        return f"{m}m {s}s"
    return f"{s}s"

def add_task(user_id, task_type, target, stop_event):
    global task_counter
    task_counter += 1
    task_id = task_counter
    if user_id not in active_tasks:
        active_tasks[user_id] = []
    active_tasks[user_id].append({
        "id": task_id,
        "type": task_type,
        "target": target,
        "stop": stop_event,
        "start": time.time()
    })
    return task_id

# ============= DISCORD API FUNCTIONS =============
DISCORD_API = "https://discord.com/api/v10"

# ============= DISCORD SPAM SAFE - CHUNG CÓ TYPING + UA RANDOM =============

# Danh sách User Agent cho Discord
DISCORD_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36 Edg/118.0.2088.76",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Android 13; Mobile; rv:109.0) Gecko/121.0 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 OPR/106.0.0.0",
]

def get_random_ua():
    return random.choice(DISCORD_USER_AGENTS)

async def discord_typing(token: str, channel_id: str):
    """Gửi typing indicator (đang gõ)"""
    headers = {"Authorization": token, "User-Agent": get_random_ua()}
    async with aiohttp.ClientSession() as session:
        async with session.post(f"{DISCORD_API}/channels/{channel_id}/typing", headers=headers) as resp:
            return resp.status == 204

async def discord_send(token: str, channel_id: str, content: str, mention_ids: List[str] = None):
    """Gửi tin nhắn Discord có typing + UA random"""
    # Bước 1: Gửi typing indicator
    await discord_typing(token, channel_id)
    
    # Bước 2: Đợi 1-3 giây (giống người đang gõ)
    await asyncio.sleep(random.uniform(1, 3))
    
    # Bước 3: Gửi tin nhắn
    headers = {"Authorization": token, "Content-Type": "application/json", "User-Agent": get_random_ua()}
    if mention_ids:
        mentions = " ".join([f"<@{uid}>" for uid in mention_ids])
        content = f"{mentions} {content}"
    
    async with aiohttp.ClientSession() as session:
        async with session.post(f"{DISCORD_API}/channels/{channel_id}/messages", json={"content": content}, headers=headers) as resp:
            return resp.status == 200

async def discord_send_poll(token: str, channel_id: str, question: str, options: List[str], mention_ids: List[str] = None):
    """Gửi poll có typing + UA random"""
    # Bước 1: Gửi typing indicator
    await discord_typing(token, channel_id)
    
    # Bước 2: Đợi 1-3 giây
    await asyncio.sleep(random.uniform(1, 3))
    
    # Bước 3: Gửi poll
    headers = {"Authorization": token, "Content-Type": "application/json", "User-Agent": get_random_ua()}
    if mention_ids:
        mentions = " ".join([f"<@{uid}>" for uid in mention_ids])
        question = f"{mentions} {question}"
    
    payload = {
        "content": question,
        "components": [{
            "type": 1,
            "components": [{
                "type": 2,
                "label": opt[:80],
                "style": 1,
                "custom_id": f"poll_{i}"
            } for i, opt in enumerate(options[:5])]
        }]
    }
    async with aiohttp.ClientSession() as session:
        async with session.post(f"{DISCORD_API}/channels/{channel_id}/messages", json=payload, headers=headers) as resp:
            return resp.status == 200

# ============= TREODIS (GỬI FULL NỘI DUNG FILE TRONG 1 TIN NHẮN) =============
async def treodis_safe_async(token, channel_id, full_message, delay, stop_event, task_id, user_id):
    """Gửi FULL nội dung file trong 1 tin nhắn + typing"""
    while not stop_event.is_set():
        try:
            success = await discord_send(token, channel_id, full_message)
            if success:
                print(f"[Discord Task {task_id}] ✅ Đã gửi (full {len(full_message)} chars)")
        except Exception as e:
            print(f"[Discord Task {task_id}] Lỗi: {e}")
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            await asyncio.sleep(0.1)

def treodis_safe(token, channel_id, file_path, delay, stop_event, task_id, user_id):
    """Treo Discord - gửi FULL nội dung file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            full_message = f.read().strip()
        if not full_message:
            print(f"[Discord Task {task_id}] File rỗng!")
            return
        asyncio.run(treodis_safe_async(token, channel_id, full_message, delay, stop_event, task_id, user_id))
    except Exception as e:
        print(f"[Discord Task {task_id}] Lỗi: {e}")

# ============= NHAYDIS (GỬI TỪNG DÒNG + TYPING) =============
async def nhaydis_safe_async(token, channel_id, messages, delay, mention_ids, stop_event, task_id, user_id):
    """Gửi từng dòng + typing + UA random"""
    idx = 0
    while not stop_event.is_set():
        try:
            msg = messages[idx % len(messages)]
            success = await discord_send(token, channel_id, msg, mention_ids)
            if success:
                print(f"[Discord Task {task_id}] ✅ Đã gửi: {msg[:50]}")
            idx += 1
        except Exception as e:
            print(f"[Discord Task {task_id}] Lỗi: {e}")
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            await asyncio.sleep(0.1)

def nhaydis_safe(token, channel_id, messages, delay, mention_ids, stop_event, task_id, user_id):
    asyncio.run(nhaydis_safe_async(token, channel_id, messages, delay, mention_ids, stop_event, task_id, user_id))

# ============= POLLDIS (GỬI POLL + TYPING) =============
async def polldis_safe_async(token, channel_id, messages, delay, mention_ids, stop_event, task_id, user_id):
    """Gửi poll + typing + UA random"""
    if len(messages) < 3:
        return
    idx = 0
    while not stop_event.is_set():
        try:
            question = messages[idx % len(messages)]
            other_options = [m for m in messages if m != question]
            if len(other_options) >= 2:
                poll_options = random.sample(other_options, 2)
            else:
                poll_options = ["👍", "👎"]
            
            success = await discord_send_poll(token, channel_id, question, poll_options, mention_ids)
            if success:
                print(f"[Discord Task {task_id}] ✅ Đã gửi poll: {question[:50]}")
            idx += 1
        except Exception as e:
            print(f"[Discord Task {task_id}] Lỗi: {e}")
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            await asyncio.sleep(0.1)

def polldis_safe(token, channel_id, messages, delay, mention_ids, stop_event, task_id, user_id):
    asyncio.run(polldis_safe_async(token, channel_id, messages, delay, mention_ids, stop_event, task_id, user_id))

def create_blank_audio():
    if os.path.exists(AUDIO_PATH):
        return
    try:
        with wave.open(AUDIO_PATH, "w") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(44100)
            frames = [struct.pack('<h', 0) for _ in range(int(44100 * 0.5))]
            wf.writeframes(b"".join(frames))
    except:
        pass

async def send_discord_voice(token: str, channel_id: str):
    create_blank_audio()
    async with aiohttp.ClientSession() as session:
        with open(AUDIO_PATH, "rb") as f:
            form = aiohttp.FormData()
            form.add_field("file", f, filename="voice.mp3", content_type="audio/mpeg")
            headers = {"Authorization": token}
            async with session.post(f"{DISCORD_API}/channels/{channel_id}/messages", data=form, headers=headers) as resp:
                return resp.status in (200, 201)

# ============= DISCORD TASK FUNCTIONS =============

def voicedis_task(token, channel_id, delay, stop_event, task_id, user_id):
    asyncio.run(voicedis_task_async(token, channel_id, delay, stop_event, task_id, user_id))

# ============= MQTT BASE CLIENT =============
class MQTTBaseClient:
    def __init__(self, cookie: str):
        self.cookie = cookie
        self.user_id = self._extract_user_id()
        self.client = None
        self.connected = False
        self.req_num = 0
        
    def _extract_user_id(self):
        match = re.search(r"c_user=(\d+)", self.cookie)
        if not match:
            raise Exception("Cookie không hợp lệ")
        return match.group(1)
    
    def connect(self):
        try:
            sid = gen_sid()
            user_data = {
                "u": self.user_id,
                "s": sid,
                "chat_on": True,
                "fg": False,
                "d": gen_cid(),
                "ct": "websocket",
                "aid": 219994525426954,
                "mqtt_sid": "",
                "cp": 3,
                "ecp": 10,
                "st": [],
                "pm": [],
                "dc": "",
                "no_auto_fg": True,
                "gas": None,
                "pack": [],
            }
            
            self.client = mqtt.Client(
                client_id="mqttwsclient",
                clean_session=True,
                protocol=mqtt.MQTTv31,
                transport="websockets"
            )
            
            self.client.tls_set(certfile=None, keyfile=None, cert_reqs=ssl.CERT_NONE, tls_version=ssl.PROTOCOL_TLSv1_2)
            self.client.username_pw_set(username=json.dumps(user_data, separators=(",", ":")))
            
            cookie_dict = parse_cookie_string(self.cookie)
            cookie_str = "; ".join([f"{k}={v}" for k, v in cookie_dict.items()])
            
            self.client.ws_set_options(
                path="/chat",
                headers={
                    "Cookie": cookie_str,
                    "Origin": "https://www.facebook.com",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Referer": "https://www.facebook.com/",
                    "Host": "edge-chat.facebook.com",
                },
            )
            
            def on_connect(client, userdata, flags, rc):
                self.connected = (rc == 0)
                if self.connected:
                    client.subscribe("/ls_resp", qos=1)
            
            self.client.on_connect = on_connect
            self.client.connect("edge-chat.facebook.com", 443, 10)
            self.client.loop_start()
            
            timeout = 10
            while not self.connected and timeout > 0:
                time.sleep(0.1)
                timeout -= 0.1
            return self.connected
        except Exception as e:
            print(f"Lỗi MQTT: {e}")
            return False
    
    def disconnect(self):
        if self.client and self.connected:
            self.client.loop_stop()
            self.client.disconnect()
            self.connected = False

# ============= MESSENGER CLIENT =============
class MessengerClient(MQTTBaseClient):
    def send_typing(self, thread_id: str, is_typing: bool = True):
        if not self.connected:
            return False
        self.req_num += 1
        try:
            task_payload = {
                "thread_key": str(thread_id),
                "is_group_thread": 1,
                "is_typing": 1 if is_typing else 0,
                "attribution": 0
            }
            content = {
                "app_id": "2220391788200892",
                "payload": json.dumps({
                    "label": "3",
                    "payload": json.dumps(task_payload, separators=(",", ":")),
                    "version": "25393437286970779",
                }, separators=(",", ":")),
                "request_id": self.req_num,
                "type": 4,
            }
            self.client.publish("/ls_req", json.dumps(content, separators=(",", ":")), qos=1)
            return True
        except:
            return False
    
    def send_message(self, thread_id: str, message: str):
        if not self.connected:
            return False, "Chưa kết nối MQTT"
        self.req_num += 1
        try:
            task_payload = {
                "thread_key": thread_id,
                "message_text": message,
                "offline_threading_id": generate_offline_threading_id(),
                "sync_group": 1,
            }
            task = {
                "label": "46",
                "payload": json.dumps(task_payload, separators=(",", ":")),
                "queue_name": "message_creation",
                "task_id": self.req_num,
            }
            content = {
                "app_id": "2220391788200892",
                "payload": json.dumps({
                    "epoch_id": int(generate_offline_threading_id()),
                    "tasks": [task],
                    "version_id": "7158486590867448",
                }, separators=(",", ":")),
                "request_id": self.req_num,
                "type": 3,
            }
            self.client.publish("/ls_req", json.dumps(content, separators=(",", ":")), qos=1)
            return True, None
        except Exception as e:
            return False, str(e)
    
    def send_message_with_typing(self, thread_id: str, message: str, typing_delay: float = 3):
        self.send_typing(thread_id, True)
        for _ in range(int(typing_delay * 10)):
            time.sleep(0.1)
        success, error = self.send_message(thread_id, message)
        self.send_typing(thread_id, False)
        return success, error

# ============= POLL CLIENT =============
class PollClient(MQTTBaseClient):
    def send_poll(self, thread_id: str, question: str, options: List[str]):
        if not self.connected:
            return False
        self.req_num += 1
        try:
            task_payload = {
                "question_text": question,
                "thread_key": int(thread_id),
                "options": options[:2],
                "sync_group": 1,
            }
            task = {
                "label": "163",
                "payload": json.dumps(task_payload, separators=(",", ":")),
                "queue_name": "poll_creation",
                "task_id": self.req_num,
            }
            content = {
                "app_id": "2220391788200892",
                "payload": json.dumps({
                    "epoch_id": int(generate_offline_threading_id()),
                    "tasks": [task],
                    "version_id": "7158486590867448",
                }, separators=(",", ":")),
                "request_id": self.req_num,
                "type": 3,
            }
            self.client.publish("/ls_req", json.dumps(content, separators=(",", ":")), qos=1)
            return True
        except:
            return False

# ============= THEME CLIENT =============
class ThemeClient(MQTTBaseClient):
    def get_theme_by_name(self, name: str):
        for theme in THEMES:
            if theme["name"].lower() == name.lower():
                return theme
        return None
    
    def set_theme(self, thread_id: str, theme_name: str = None):
        if not self.connected:
            return False
        if theme_name:
            theme = self.get_theme_by_name(theme_name)
            if not theme:
                return False
            theme_id = theme["id"]
        else:
            theme_id = random.choice(THEMES)["id"]
        self.req_num += 1
        try:
            task_payload = {
                "thread_key": thread_id,
                "theme_fbid": theme_id,
                "source": None,
                "sync_group": 1,
                "payload": None
            }
            task = {
                "failure_count": None,
                "label": "43",
                "payload": json_minimal(task_payload),
                "queue_name": "thread_theme",
                "task_id": self.req_num
            }
            content = {
                "app_id": "2220391788200892",
                "payload": json_minimal({
                    "data_trace_id": None,
                    "epoch_id": int(generate_offline_threading_id()),
                    "tasks": [task],
                    "version_id": "25095469420099952"
                }),
                "request_id": self.req_num,
                "type": 3
            }
            self.client.publish("/ls_req", json_minimal(content), qos=1)
            return True
        except:
            return False

class NameBoxClient(MQTTBaseClient):
    def change_name(self, thread_id: str, new_name: str):
        if not self.connected:
            return False, "Chưa kết nối MQTT"
        self.req_num += 1
        try:
            task_payload = {
                "thread_key": thread_id,
                "name": new_name,
                "sync_group": 1,
            }
            task = {
                "label": "44",
                "payload": json.dumps(task_payload, separators=(",", ":")),
                "queue_name": "thread_name_update",
                "task_id": self.req_num,
            }
            content = {
                "app_id": "2220391788200892",
                "payload": json.dumps({
                    "epoch_id": int(generate_offline_threading_id()),
                    "tasks": [task],
                    "version_id": "7158486590867448",
                }, separators=(",", ":")),
                "request_id": self.req_num,
                "type": 3,
            }
            self.client.publish("/ls_req", json.dumps(content, separators=(",", ":")), qos=1)
            return True, None
        except Exception as e:
            return False, str(e)
# ============= THÊM VÀO ĐẦU FILE (PHẦN IMPORT) =============
import base64

# ============= FACEBOOK COMMENT SPAM CLASS =============
class FacebookCommentSpam:
    def __init__(self, cookie):
        self.cookie = cookie
        self.user_id = None
        self.fb_dtsg = None
        self.jazoest = None
        self.rev = None
        self.req = None
        self.a = None
        self._init_session()
    
    def _init_session(self):
        """Khởi tạo session và lấy token"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Cookie': self.cookie
            }
            response = requests.get('https://www.facebook.com/', headers=headers, timeout=15)
            
            # Lấy user_id
            user_match = re.search(r'"userID":"(\d+)"', response.text)
            if not user_match:
                user_match = re.search(r'\"actorID\":\"(\d+)\"', response.text)
            if user_match:
                self.user_id = user_match.group(1)
            
            # Lấy fb_dtsg
            fb_dtsg_match = re.search(r'"token":"(.*?)"', response.text)
            if not fb_dtsg_match:
                fb_dtsg_match = re.search(r'name="fb_dtsg" value="(.*?)"', response.text)
            if fb_dtsg_match:
                self.fb_dtsg = fb_dtsg_match.group(1)
            
            # Lấy jazoest
            jazoest_match = re.search(r'jazoest=(\d+)', response.text)
            if jazoest_match:
                self.jazoest = jazoest_match.group(1)
            
            # Lấy rev
            rev_match = re.search(r'"client_revision":(\d+)', response.text)
            if rev_match:
                self.rev = rev_match.group(1)
            
            self.req = "1b"
            self.a = "1"
            
            return self.user_id and self.fb_dtsg and self.jazoest
        except Exception as e:
            print(f"Lỗi init: {e}")
            return False
    
    def get_user_info(self, uid):
        """Lấy thông tin user theo UID"""
        try:
            form = {
                "ids[0]": uid,
                "fb_dtsg": self.fb_dtsg,
                "__a": self.a,
                "__req": self.req,
                "__rev": self.rev
            }
            headers = {
                'Cookie': self.cookie,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            response = requests.post("https://www.facebook.com/chat/user_info/", data=form, headers=headers)
            text = response.text
            if text.startswith("for (;;);"):
                text = text[9:]
            data = json.loads(text)
            if "payload" in data and "profiles" in data["payload"]:
                profiles = data["payload"]["profiles"]
                first_id = next(iter(profiles))
                return profiles[first_id].get("name", "")
        except:
            pass
        return None
    
    def extract_ids(self, post_link):
        """Lấy post_id và group_id từ link"""
        post_match = re.search(r'permalink[/:](\d+)', post_link)
        group_match = re.search(r'groups[/:](\d+)', post_link)
        if not post_match:
            post_match = re.search(r'facebook\.com/.+/posts/(\d+)', post_link)
        return post_match.group(1) if post_match else None, group_match.group(1) if group_match else None
    
    def post_comment(self, group_id, post_id, content, tag_uid=None, tag_name=None):
        """Gửi comment vào bài viết"""
        try:
            pstid_enc = base64.b64encode(f"feedback:{post_id}".encode()).decode()
            client_mutation_id = str(int(time.time() * 1000))
            session_id = str(uuid.uuid4())
            
            variables = {
                "feedLocation": "DEDICATED_COMMENTING_SURFACE",
                "feedbackSource": 110,
                "groupID": group_id,
                "input": {
                    "client_mutation_id": client_mutation_id,
                    "actor_id": self.user_id,
                    "attachments": None,
                    "feedback_id": pstid_enc,
                    "formatting_style": None,
                    "message": {
                        "ranges": [],
                        "text": content
                    },
                    "attribution_id_v2": f"SearchCometGlobalSearchDefaultTabRoot.react,comet.search_results.default_tab,tap_search_bar,{int(time.time()*1000)},775647,391724414624676,,",
                    "is_tracking_encrypted": True,
                    "tracking": [],
                    "feedback_source": "DEDICATED_COMMENTING_SURFACE",
                    "session_id": session_id
                },
                "inviteShortLinkKey": None,
                "renderLocation": None,
                "scale": 3,
                "useDefaultActor": False,
                "focusCommentID": None,
                "__relay_internal__pv__IsWorkUserrelayprovider": False
            }
            
            if tag_uid and tag_name:
                name_position = content.find(tag_name)
                if name_position != -1:
                    variables["input"]["message"]["ranges"] = [{
                        "entity": {"id": tag_uid},
                        "length": len(tag_name),
                        "offset": name_position
                    }]
            
            payload = {
                'av': self.user_id,
                '__crn': 'comet.fbweb.CometGroupDiscussionRoute',
                'fb_dtsg': self.fb_dtsg,
                'jazoest': self.jazoest,
                'fb_api_caller_class': 'RelayModern',
                'fb_api_req_friendly_name': 'useCometUFICreateCommentMutation',
                'variables': json.dumps(variables),
                'server_timestamps': 'true',
                'doc_id': '24323081780615819'
            }
            
            headers = {
                'Cookie': self.cookie,
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0'
            }
            
            response = requests.post('https://www.facebook.com/api/graphql', data=payload, headers=headers)
            return response.status_code == 200
        except Exception as e:
            print(f"Lỗi post comment: {e}")
            return False

# ============= TASK TREOTOP =============
def treotop_task(cookie, post_link, messages, delay, tag_uid, stop_event, task_id, user_id):
    """Vòng lặp spam comment Facebook"""
    fb = FacebookCommentSpam(cookie)
    if not fb.user_id or not fb.fb_dtsg:
        print(f"[Treotop Task {task_id}] ❌ Cookie không hợp lệ!")
        return
    
    # Lấy group_id và post_id
    group_id, post_id = fb.extract_ids(post_link)
    if not group_id or not post_id:
        print(f"[Treotop Task {task_id}] ❌ Link bài viết không hợp lệ!")
        return
    
    # Lấy tên người tag
    tag_name = None
    if tag_uid:
        tag_name = fb.get_user_info(tag_uid)
        if not tag_name:
            print(f"[Treotop Task {task_id}] ⚠️ Không lấy được tên UID {tag_uid}, sẽ không tag")
            tag_uid = None
    
    idx = 0
    while not stop_event.is_set():
        try:
            msg = messages[idx % len(messages)]
            
            # Nếu có tag, thêm tên vào nội dung
            if tag_uid and tag_name:
                if random.choice([True, False]):
                    final_msg = f"{tag_name} {msg}"
                else:
                    final_msg = f"{msg} {tag_name}"
            else:
                final_msg = msg
            
            success = fb.post_comment(group_id, post_id, final_msg, tag_uid, tag_name)
            
            if success:
                print(f"[Treotop Task {task_id}] ✅ Đã comment: {final_msg[:50]}")
            else:
                print(f"[Treotop Task {task_id}] ❌ Comment thất bại")
            
            idx += 1
            
        except Exception as e:
            print(f"[Treotop Task {task_id}] Lỗi: {e}")
        
        # Delay
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)


# ============= TELEGRAM BOT CLASS =============
class TelegramBot:
    def __init__(self, token: str):
        self.token = token
        self.api_url = f"https://api.telegram.org/bot{token}"
        self.session = None
    
    async def get_session(self):
        if self.session is None:
            self.session = aiohttp.ClientSession()
        return self.session
    
    async def send_message(self, chat_id: str, text: str):
        session = await self.get_session()
        try:
            async with session.post(f"{self.api_url}/sendMessage", json={"chat_id": chat_id, "text": text, "parse_mode": "HTML"}) as resp:
                return resp.status == 200
        except:
            return False
    
    async def send_poll(self, chat_id: str, question: str, options: list):
        session = await self.get_session()
        try:
            async with session.post(f"{self.api_url}/sendPoll", json={"chat_id": chat_id, "question": question, "options": options, "is_anonymous": False}) as resp:
                return resp.status == 200
        except:
            return False
    
    async def send_message_with_tag(self, chat_id: str, text: str, user_ids: list):
        session = await self.get_session()
        try:
            mentions = ""
            for uid in user_ids:
                mentions += f'<a href="tg://user?id={uid}">​</a>'
            full_text = text + mentions
            async with session.post(f"{self.api_url}/sendMessage", json={"chat_id": chat_id, "text": full_text, "parse_mode": "HTML"}) as resp:
                return resp.status == 200
        except:
            return False
    
    async def close(self):
        if self.session:
            await self.session.close()

# ============= FACEBOOK TASK FUNCTIONS =============
def ngonmes_task(cookie, idbox, messages, delay, stop_event, task_id, user_id):
    client = MessengerClient(cookie)
    if not client.connect():
        return
    idx = 0
    while not stop_event.is_set():
        try:
            msg = messages[idx % len(messages)]
            client.send_message(idbox, msg)
            idx += 1
        except:
            pass
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)
    client.disconnect()

def nhaymes_task(cookie, idbox, messages, delay, typing_delay, stop_event, task_id, user_id):
    client = MessengerClient(cookie)
    if not client.connect():
        return
    idx = 0
    while not stop_event.is_set():
        try:
            msg = messages[idx % len(messages)]
            client.send_message_with_typing(idbox, msg, typing_delay)
            idx += 1
        except:
            pass
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)
    client.disconnect()

def npollmes_task(cookie, idbox, messages, delay, stop_event, task_id, user_id):
    if len(messages) < 3:
        return
    client = PollClient(cookie)
    if not client.connect():
        return
    idx = 0
    while not stop_event.is_set():
        try:
            question = messages[idx % len(messages)]
            other_options = [m for m in messages if m != question]
            poll_options = random.sample(other_options, 2) if len(other_options) >= 2 else ["👍", "👎"]
            client.send_poll(idbox, question, poll_options)
            idx += 1
        except:
            pass
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)
    client.disconnect()

def tpollmes_task(cookie, idbox, file_path, delay, stop_event, task_id, user_id):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = [l.strip() for l in f if l.strip()]
        polls = []
        for i in range(0, len(lines) - 2, 3):
            polls.append({"question": lines[i], "options": [lines[i+1], lines[i+2]]})
        if not polls:
            return
        client = PollClient(cookie)
        if not client.connect():
            return
        idx = 0
        while not stop_event.is_set():
            try:
                poll = polls[idx % len(polls)]
                client.send_poll(idbox, poll["question"], poll["options"])
                idx += 1
            except:
                pass
            for _ in range(int(delay * 10)):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
        client.disconnect()
    except:
        pass

def theme_task(cookie, idbox, delay, theme_name, stop_event, task_id, user_id):
    client = ThemeClient(cookie)
    if not client.connect():
        return
    while not stop_event.is_set():
        try:
            client.set_theme(idbox, theme_name)
        except:
            pass
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)
    client.disconnect()

def namebox_task(cookie, idbox, names, delay, stop_event, task_id, user_id):
    client = NameBoxClient(cookie)
    if not client.connect():
        return
    idx = 0
    while not stop_event.is_set():
        try:
            new_name = names[idx % len(names)]
            client.change_name(idbox, new_name)
            idx += 1
        except:
            pass
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)
    client.disconnect()

# ============= TELEGRAM TASK FUNCTIONS =============
async def nhaytele_task_async(token, chat_id, messages, delay, stop_event, task_id, user_id):
    bot = TelegramBot(token)
    idx = 0
    while not stop_event.is_set():
        try:
            await bot.send_message(chat_id, messages[idx % len(messages)])
            idx += 1
        except:
            pass
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            await asyncio.sleep(0.1)
    await bot.close()

def nhaytele_task(token, chat_id, messages, delay, stop_event, task_id, user_id):
    asyncio.run(nhaytele_task_async(token, chat_id, messages, delay, stop_event, task_id, user_id))

async def treotele_task_async(token, chat_id, polls, delay, stop_event, task_id, user_id):
    bot = TelegramBot(token)
    idx = 0
    while not stop_event.is_set():
        try:
            poll = polls[idx % len(polls)]
            await bot.send_poll(chat_id, poll["question"], poll["options"])
            idx += 1
        except:
            pass
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            await asyncio.sleep(0.1)
    await bot.close()

def treotele_task(token, chat_id, file_path, delay, stop_event, task_id, user_id):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = [l.strip() for l in f if l.strip()]
        polls = []
        for i in range(0, len(lines) - 2, 3):
            polls.append({"question": lines[i], "options": [lines[i+1], lines[i+2]]})
        if polls:
            asyncio.run(treotele_task_async(token, chat_id, polls, delay, stop_event, task_id, user_id))
    except:
        pass

async def polltele_task_async(token, chat_id, messages, delay, stop_event, task_id, user_id):
    if len(messages) < 3:
        return
    bot = TelegramBot(token)
    idx = 0
    while not stop_event.is_set():
        try:
            question = messages[idx % len(messages)]
            other_options = [m for m in messages if m != question]
            poll_options = random.sample(other_options, 2) if len(other_options) >= 2 else ["👍", "👎"]
            await bot.send_poll(chat_id, question, poll_options)
            idx += 1
        except:
            pass
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            await asyncio.sleep(0.1)
    await bot.close()

def polltele_task(token, chat_id, messages, delay, stop_event, task_id, user_id):
    asyncio.run(polltele_task_async(token, chat_id, messages, delay, stop_event, task_id, user_id))

async def nhaytagtele_task_async(token, chat_id, messages, user_ids, delay, stop_event, task_id, user_id):
    bot = TelegramBot(token)
    idx = 0
    while not stop_event.is_set():
        try:
            await bot.send_message_with_tag(chat_id, messages[idx % len(messages)], user_ids)
            idx += 1
        except:
            pass
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            await asyncio.sleep(0.1)
    await bot.close()

def nhaytagtele_task(token, chat_id, messages, user_ids, delay, stop_event, task_id, user_id):
    asyncio.run(nhaytagtele_task_async(token, chat_id, messages, user_ids, delay, stop_event, task_id, user_id))

# ============= CLASS YESCAPTCHA =============
class YesCaptchaService:
    def __init__(self, client_key):
        self.clientKey = client_key
        self.createTask_API = "https://api.yescaptcha.com/createTask"
        self.getTask_API = "https://api.yescaptcha.com/getTaskResult"

    def solve_hcaptcha(self, site_key, page_url):
        if not self.clientKey:
            return None
        try:
            task = {
                "type": "HCaptchaTaskProxyless",
                "websiteURL": page_url,
                "websiteKey": site_key
            }
            res = requests.post(self.createTask_API, json={
                "clientKey": self.clientKey,
                "task": task
            }, timeout=30).json()
            task_id = res.get("taskId")
            if not task_id:
                return None
            for _ in range(60):
                time.sleep(3)
                result = requests.post(self.getTask_API, json={
                    "clientKey": self.clientKey,
                    "taskId": task_id
                }, timeout=30).json()
                if result.get("status") == "ready":
                    return result.get("solution", {}).get("gRecaptchaResponse")
                if result.get("status") == "error":
                    break
            return None
        except:
            return None

    def get_balance(self):
        if not self.clientKey:
            return "N/A"
        try:
            res = requests.post(
                "https://api.yescaptcha.com/getBalance",
                json={"clientKey": self.clientKey},
                timeout=30
            ).json()
            return res.get("balance", 0)
        except:
            return 0

# ============= CLASS BOT HOSTING =============
class BotHosting:
    def __init__(self, token):
        self.token = token
        self.me_API = "https://bot-hosting.net/api/me"
        self.status_API = "https://bot-hosting.net/api/freeCoinsStatus"
        self.earn_API = "https://bot-hosting.net/api/freeCoins"
        self.site_key = "21335a07-5b97-4a79-b1e9-b197dc35017a"
        self.headers = {
            "authorization": self.token,
            "user-agent": "Mozilla/5.0",
            "referer": "https://bot-hosting.net/panel/earn"
        }

    def get_info(self):
        try:
            res = requests.get(self.me_API, headers=self.headers, timeout=10).json()
            return res.get("username"), res.get("coins", 0)
        except:
            return None, 0

    def check_status(self):
        try:
            res = requests.get(self.status_API, headers=self.headers, timeout=10).json()
            return res.get("claimable"), res.get("captcha"), res.get("message", "")
        except:
            return False, False, ""

    def earn_coins(self, captcha_token=None):
        payload = {"hCaptchaResponse": captcha_token} if captcha_token else {}
        try:
            res = requests.post(self.earn_API, headers=self.headers, json=payload, timeout=15)
            return res.status_code == 200, res.text
        except:
            return False, "Connection Error"

# ============= BIẾN LƯU TRỮ COIN TASKS =============
coin_tasks = {}  # {user_id: {"stop": event, "token": str, "apikey": str, "start": time}}

# ============= TASK COIN FUNCTION =============
def coin_task_loop(auth_token, api_key, stop_event, task_id, user_id):
    """Vòng lặp nhận coin tự động"""
    bot = BotHosting(auth_token)
    solver = YesCaptchaService(api_key) if api_key else None
    
    name, coins = bot.get_info()
    if not name:
        print(f"[Coin Task {task_id}] ❌ Token sai!")
        return
    
    print(f"[Coin Task {task_id}] ✅ Đã chạy cho: {name} | {coins} xu")
    
    while not stop_event.is_set():
        try:
            claimable, need_captcha, msg = bot.check_status()
            
            if claimable:
                captcha_token = None
                if need_captcha:
                    if solver:
                        print(f"[Coin Task {task_id}] Đang giải captcha...")
                        captcha_token = solver.solve_hcaptcha(bot.site_key, "https://bot-hosting.net/panel/earn")
                        if not captcha_token:
                            print(f"[Coin Task {task_id}] ❌ Lỗi captcha!")
                            for _ in range(100):
                                if stop_event.is_set():
                                    break
                                time.sleep(0.1)
                            continue
                    else:
                        print(f"[Coin Task {task_id}] ⚠️ Cần captcha nhưng không có API key!")
                        for _ in range(100):
                            if stop_event.is_set():
                                break
                            time.sleep(0.1)
                        continue
                
                success, _ = bot.earn_coins(captcha_token)
                if success:
                    _, new_coins = bot.get_info()
                    print(f"[Coin Task {task_id}] ✅ [{datetime.now().strftime('%H:%M:%S')}] + Nhận xu! Tổng: {new_coins}")
                else:
                    print(f"[Coin Task {task_id}] ❌ Claim thất bại")
            
            # Delay 15 giây mỗi lần check
            for _ in range(150):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
                
        except Exception as e:
            print(f"[Coin Task {task_id}] Lỗi: {e}")
            for _ in range(100):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
                



# ============= ZALO API CLASS =============
class ThreadType(Enum):
    USER = 1
    GROUP = 2

def zalo_encode(params, key):
    key = base64.b64decode(key)
    iv = bytes(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    plaintext = json.dumps(params).encode()
    pad_len = AES.block_size - len(plaintext) % AES.block_size
    padded = plaintext + bytes([pad_len] * pad_len)
    return base64.b64encode(cipher.encrypt(padded)).decode()

def zalo_decode(encrypted_data, key):
    key = base64.b64decode(key)
    iv = bytes(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(base64.b64decode(encrypted_data))
    pad_len = decrypted[-1]
    return decrypted[:-pad_len].decode('utf-8', errors='ignore')

class ZaloAPI:
    def __init__(self, imei, cookies):
        self.session = requests.Session()
        self.imei = imei
        self.secret_key = None
        self.uid = None
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0",
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://chat.zalo.me",
            "Referer": "https://chat.zalo.me/",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        })
        self.session.cookies.update(cookies)
        self._login()
    
    def _login(self):
        url = "https://wpa.chat.zalo.me/api/login/getLoginInfo"
        params = {"imei": self.imei, "type": 30, "client_version": 645, "ts": int(time.time() * 1000)}
        response = self.session.get(url, params=params)
        data = response.json()
        user_data = data.get("data")
        if not user_data:
            raise Exception("❌ Đăng nhập thất bại! Sai IMEI hoặc Cookie")
        self.uid = user_data.get("send2me_id")
        self.secret_key = user_data.get("zpw_enk")
        if not self.secret_key:
            raise Exception("❌ Không lấy được secret_key")
    
    def fetch_friends(self):
        url = "https://profile-wpa.chat.zalo.me/api/social/friend/getfriends"
        params = {"zpw_ver": 645, "zpw_type": 30}
        encoded = zalo_encode({"offset": 0, "count": 1000}, self.secret_key)
        response = self.session.post(url, params=params, data={"params": encoded})
        result = response.json()
        decrypted = zalo_decode(result["data"], self.secret_key)
        parsed = json.loads(decrypted)
        data_section = parsed.get("data", [])
        users = data_section if isinstance(data_section, list) else data_section.get("users", [])
        return [{"id": u.get("userId"), "name": u.get("zaloName", "Unknown")} for u in users]
    
    def fetch_groups(self):
        url = "https://tt-group-wpa.chat.zalo.me/api/group/getlg/v4"
        params = {"zpw_ver": 645, "zpw_type": 30}
        response = self.session.get(url, params=params)
        data = response.json()
        decoded = zalo_decode(data["data"], self.secret_key)
        parsed = json.loads(decoded)
        grid_map = parsed.get("data", {}).get("gridVerMap", {})
        groups = []
        for group_id in grid_map.keys():
            info = self._fetch_group_info(group_id)
            groups.append({"id": group_id, "name": info.get("name", "Unknown"), "members": info.get("totalMember", 0)})
        return groups
    
    def _fetch_group_info(self, group_id):
        url = "https://tt-group-wpa.chat.zalo.me/api/group/getmg-v2"
        params = {"zpw_ver": 645, "zpw_type": 30}
        encoded = zalo_encode({"gridVerMap": json.dumps({str(group_id): 0})}, self.secret_key)
        response = self.session.post(url, params=params, data={"params": encoded})
        result = response.json()
        decoded = zalo_decode(result["data"], self.secret_key)
        parsed = json.loads(decoded)
        return parsed.get("data", {}).get("gridInfoMap", {}).get(str(group_id), {})
    
    def fetch_members(self, group_id):
        info = self._fetch_group_info(group_id)
        mem_ver_list = info.get("memVerList", [])
        members = []
        for mem in mem_ver_list:
            uid = mem.split("_")[0]
            try:
                user_info = self._fetch_user_info(uid)
                members.append({"id": uid, "name": user_info.get("displayName", f"User_{uid}")})
            except:
                members.append({"id": uid, "name": f"User_{uid}"})
        return members
    
    def _fetch_user_info(self, uid):
        url = "https://profile-wpa.chat.zalo.me/api/profile/get"
        params = {"zpw_ver": 645, "zpw_type": 30}
        encoded = zalo_encode({"userId": uid}, self.secret_key)
        response = self.session.post(url, params=params, data={"params": encoded})
        result = response.json()
        decrypted = zalo_decode(result["data"], self.secret_key)
        return json.loads(decrypted).get("data", {})
    
    def send_message(self, message, thread_id, thread_type):
        if thread_type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/sendmsg"
            payload = {"message": message, "clientId": str(int(time.time() * 1000)), "imei": self.imei, "visibility": 0, "grid": str(thread_id)}
        else:
            url = "https://tt-chat2-wpa.chat.zalo.me/api/message/sms"
            payload = {"message": message, "clientId": str(int(time.time() * 1000)), "imei": self.imei, "toid": str(thread_id)}
        encoded = zalo_encode(payload, self.secret_key)
        response = self.session.post(url, params={"zpw_ver": 645, "zpw_type": 30}, data={"params": encoded})
        return response.json()
    
    def send_typing(self, thread_id, thread_type):
        params = {"zpw_ver": 645, "zpw_type": 30}
        if thread_type == ThreadType.USER:
            url = "https://tt-chat1-wpa.chat.zalo.me/api/message/typing"
            payload = {"imei": self.imei, "toid": str(thread_id), "destType": 3}
        else:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/typing"
            payload = {"imei": self.imei, "grid": str(thread_id)}
        encoded = zalo_encode(payload, self.secret_key)
        self.session.post(url, params=params, data={"params": encoded})
    
    def send_poll(self, thread_id, thread_type, question, options):
        """Gửi poll (dạng tin nhắn thường vì Zalo API không có poll native)"""
        poll_text = f"📊 {question}\n\n"
        for i, opt in enumerate(options[:5], 1):
            poll_text += f"{i}. {opt}\n"
        poll_text += f"\n👉 Trả lời bằng số thứ tự (1-{len(options[:5])})"
        return self.send_message(poll_text, thread_id, thread_type)
    
    def change_group_name(self, group_id, new_name):
        url = "https://tt-group-wpa.chat.zalo.me/api/group/updategroupinfo"
        params = {"zpw_ver": 645, "zpw_type": 30}
        payload = {"grid": str(group_id), "name": new_name, "imei": self.imei}
        encoded = zalo_encode(payload, self.secret_key)
        response = self.session.post(url, params=params, data={"params": encoded})
        return response.json()
    
    def join_group(self, link):
        url = "https://tt-group-wpa.chat.zalo.me/api/group/joinv2"
        params = {"zpw_ver": 645, "zpw_type": 30}
        payload = {"link": link, "imei": self.imei}
        encoded = zalo_encode(payload, self.secret_key)
        response = self.session.post(url, params=params, data={"params": encoded})
        return response.json()

# ============= ZALO TASK FUNCTIONS =============
def zalo_send_task(imei, cookies, target_id, target_type, messages, delay, use_typing, stop_event, task_id, user_id):
    try:
        api = ZaloAPI(imei, cookies)
        idx = 0
        while not stop_event.is_set():
            try:
                msg = messages[idx % len(messages)]
                if use_typing:
                    api.send_typing(target_id, target_type)
                    for _ in range(15):
                        if stop_event.is_set():
                            break
                        time.sleep(0.1)
                api.send_message(msg, target_id, target_type)
                print(f"[Zalo Task {task_id}] ✅ Đã gửi: {msg[:50]}")
                idx += 1
            except Exception as e:
                print(f"[Zalo Task {task_id}] Lỗi: {e}")
            for _ in range(int(delay * 10)):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
    except Exception as e:
        print(f"[Zalo Task {task_id}] Lỗi kết nối: {e}")

def zalo_poll_task(imei, cookies, target_id, target_type, questions, delay, stop_event, task_id, user_id):
    try:
        api = ZaloAPI(imei, cookies)
        idx = 0
        while not stop_event.is_set():
            try:
                question = questions[idx % len(questions)]
                other_q = [q for q in questions if q != question]
                options = random.sample(other_q, 2) if len(other_q) >= 2 else ["👍", "👎"]
                api.send_poll(target_id, target_type, question, options)
                print(f"[Zalo Task {task_id}] ✅ Đã gửi poll: {question[:50]}")
                idx += 1
            except Exception as e:
                print(f"[Zalo Task {task_id}] Lỗi: {e}")
            for _ in range(int(delay * 10)):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
    except Exception as e:
        print(f"[Zalo Task {task_id}] Lỗi: {e}")

def zalo_namebox_task(imei, cookies, group_id, names, delay, stop_event, task_id, user_id):
    try:
        api = ZaloAPI(imei, cookies)
        idx = 0
        while not stop_event.is_set():
            try:
                new_name = names[idx % len(names)]
                api.change_group_name(group_id, new_name)
                print(f"[Zalo Task {task_id}] ✅ Đã đổi tên nhóm thành: {new_name}")
                idx += 1
            except Exception as e:
                print(f"[Zalo Task {task_id}] Lỗi: {e}")
            for _ in range(int(delay * 10)):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
    except Exception as e:
        print(f"[Zalo Task {task_id}] Lỗi: {e}")

def zalo_join_task(imei, cookies, link, stop_event, task_id, user_id):
    try:
        api = ZaloAPI(imei, cookies)
        result = api.join_group(link)
        error_messages = {
            0: "✅ Tham gia nhóm thành công!",
            240: "⏳ Đã gửi yêu cầu, chờ duyệt!",
            178: "⚠️ Đã là thành viên của nhóm!",
            227: "❌ Link không tồn tại!",
            175: "❌ Tài khoản bị block!",
            1003: "❌ Nhóm đã đầy!",
            1022: "⚠️ Đã yêu cầu trước đó!"
        }
        code = result.get("error_code", -1)
        msg = error_messages.get(code, f"❌ Lỗi: {result}")
        print(f"[Zalo Join Task {task_id}] {msg}")
    except Exception as e:
        print(f"[Zalo Join Task {task_id}] Lỗi: {e}")

def zalo_call_task(imei, cookies, target_id, target_type, repeat_count, stop_event, task_id, user_id):
    """Spam call Zalo (gửi tin nhắn dạng call request)"""
    try:
        api = ZaloAPI(imei, cookies)
        for i in range(repeat_count):
            if stop_event.is_set():
                break
            try:
                # Gửi call request
                if target_type == ThreadType.USER:
                    url = "https://tt-chat1-wpa.chat.zalo.me/api/call/request"
                    payload = {"toid": str(target_id), "imei": imei, "type": 1}
                else:
                    url = "https://tt-group-wpa.chat.zalo.me/api/group/call/request"
                    payload = {"grid": str(target_id), "imei": imei, "type": 1}
                encoded = zalo_encode(payload, api.secret_key)
                response = api.session.post(url, params={"zpw_ver": 645, "zpw_type": 30}, data={"params": encoded})
                print(f"[Zalo Call Task {task_id}] 📞 Đã gọi lần {i+1}/{repeat_count}")
            except Exception as e:
                print(f"[Zalo Call Task {task_id}] Lỗi gọi: {e}")
            for _ in range(30):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
    except Exception as e:
        print(f"[Zalo Call Task {task_id}] Lỗi: {e}")

def zalo_sticker_task(imei, cookies, target_id, target_type, sticker_count, delay, stop_event, task_id, user_id):
    """Spam sticker"""
    try:
        api = ZaloAPI(imei, cookies)
        sticker_type = 3
        sticker_id = "23339"
        category_id = "10425"
        for i in range(sticker_count):
            if stop_event.is_set():
                break
            try:
                # Gửi sticker
                url = "https://tt-group-wpa.chat.zalo.me/api/group/sendsticker" if target_type == ThreadType.GROUP else "https://tt-chat2-wpa.chat.zalo.me/api/message/sendsticker"
                payload = {
                    "stickerType": sticker_type,
                    "stickerId": sticker_id,
                    "categoryId": category_id,
                    "clientId": str(int(time.time() * 1000)),
                    "imei": imei
                }
                if target_type == ThreadType.GROUP:
                    payload["grid"] = str(target_id)
                else:
                    payload["toid"] = str(target_id)
                encoded = zalo_encode(payload, api.secret_key)
                api.session.post(url, params={"zpw_ver": 645, "zpw_type": 30}, data={"params": encoded})
                print(f"[Zalo Sticker Task {task_id}] ✅ Đã gửi sticker {i+1}/{sticker_count}")
            except Exception as e:
                print(f"[Zalo Sticker Task {task_id}] Lỗi: {e}")
            for _ in range(int(delay * 10)):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
    except Exception as e:
        print(f"[Zalo Sticker Task {task_id}] Lỗi: {e}")

# ============= THÊM VÀO ĐẦU FILE (PHẦN IMPORT) =============
from instagrapi import Client
from getpass import getpass

# ============= INSTAGRAM CLASS =============
class InstagramAPI:
    def __init__(self, login_method, credential):
        """
        login_method: 'cookie' hoặc 'password'
        credential: cookie_string hoặc (username, password)
        """
        self.client = Client()
        self.user_id = None
        self._login(login_method, credential)
    
    def _login(self, method, credential):
        if method == 'cookie':
            cookie_dict = self._parse_cookie(credential)
            sessionid = cookie_dict.get("sessionid")
            if not sessionid:
                raise Exception("Thiếu sessionid trong cookie!")
            self.client.login_by_sessionid(sessionid=sessionid)
        elif method == 'password':
            username, password = credential
            self.client.login(username, password)
        self.user_id = self.client.user_id
        
    def _parse_cookie(self, cookie_str):
        return dict(item.strip().split('=') for item in cookie_str.split(';') if '=' in item)
    
    def get_user_id(self, username):
        return self.client.user_id_from_username(username)
    
    def get_thread_id(self, user_id):
        threads = self.client.direct_threads(user_id)
        return threads[0].id if threads else None
    
    def send_typing(self, thread_id, duration=2):
        try:
            self.client.direct_thread_update(thread_id, typing=True)
            time.sleep(duration)
            self.client.direct_thread_update(thread_id, typing=False)
            return True
        except:
            return False
    
    def send_message(self, target, message, target_is_id=True):
        if target_is_id:
            self.client.direct_send(message, thread_ids=[target])
        else:
            user_id = self.get_user_id(target)
            self.client.direct_send(message, [user_id])
        return True
    
    def send_message_with_typing(self, target, message, target_is_id=True, typing_delay=2):
        # Lấy thread_id
        if target_is_id:
            thread_id = target
        else:
            user_id = self.get_user_id(target)
            thread_id = self.get_thread_id(user_id)
        
        if not thread_id:
            return False, "Không tìm thấy thread"
        
        # Gửi typing indicator
        self.send_typing(thread_id, typing_delay)
        
        # Gửi tin nhắn
        self.send_message(target, message, target_is_id)
        return True, None

# ============= INSTAGRAM TASK FUNCTIONS =============
def ig_send_task(login_method, credential, targets, messages, delay, use_typing, stop_event, task_id, user_id):
    """Gửi tin nhắn Instagram (treoig)"""
    try:
        ig = InstagramAPI(login_method, credential)
        idx = 0
        while not stop_event.is_set():
            for target in targets:
                if stop_event.is_set():
                    break
                try:
                    msg = messages[idx % len(messages)]
                    if use_typing:
                        ig.send_message_with_typing(target, msg, target_is_id=True)
                    else:
                        ig.send_message(target, msg, target_is_id=True)
                    print(f"[IG Task {task_id}] ✅ Đã gửi tới {target}: {msg[:50]}")
                    idx += 1
                except Exception as e:
                    print(f"[IG Task {task_id}] Lỗi gửi {target}: {e}")
                for _ in range(int(delay * 10)):
                    if stop_event.is_set():
                        break
                    time.sleep(0.1)
    except Exception as e:
        print(f"[IG Task {task_id}] Lỗi khởi tạo: {e}")

def ig_spam_task(login_method, credential, targets, messages, delay, stop_event, task_id, user_id):
    """Gửi tin nhắn spam từ file (không typing)"""
    ig_send_task(login_method, credential, targets, messages, delay, False, stop_event, task_id, user_id)

def ig_nhay_task(login_method, credential, targets, messages, delay, stop_event, task_id, user_id):
    """Gửi tin nhắn có typing từ file nhay.txt"""
    ig_send_task(login_method, credential, targets, messages, delay, True, stop_event, task_id, user_id)

def ig_poll_task(login_method, credential, targets, questions, delay, stop_event, task_id, user_id):
    """Gửi poll Instagram (tạo poll từ tin nhắn dạng câu hỏi)"""
    try:
        ig = InstagramAPI(login_method, credential)
        idx = 0
        while not stop_event.is_set():
            for target in targets:
                if stop_event.is_set():
                    break
                try:
                    question = questions[idx % len(questions)]
                    other_q = [q for q in questions if q != question]
                    options = random.sample(other_q, 2) if len(other_q) >= 2 else ["👍", "👎"]
                    poll_text = f"📊 POLL: {question}\n\n1. {options[0]}\n2. {options[1]}\n\n👉 Reply số 1 hoặc 2"
                    ig.send_message(target, poll_text, target_is_id=True)
                    print(f"[IG Poll Task {task_id}] ✅ Đã gửi poll: {question[:50]}")
                    idx += 1
                except Exception as e:
                    print(f"[IG Poll Task {task_id}] Lỗi: {e}")
                for _ in range(int(delay * 10)):
                    if stop_event.is_set():
                        break
                    time.sleep(0.1)
    except Exception as e:
        print(f"[IG Poll Task {task_id}] Lỗi: {e}")

def ig_tpoll_task(login_method, credential, targets, file_path, delay, stop_event, task_id, user_id):
    """Gửi poll từ file (3 dòng: câu hỏi, option1, option2)"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = [l.strip() for l in f if l.strip()]
        
        polls = []
        for i in range(0, len(lines) - 2, 3):
            polls.append({
                "question": lines[i],
                "options": [lines[i+1], lines[i+2]]
            })
        
        if not polls:
            print(f"[IG TPoll Task {task_id}] File poll không hợp lệ!")
            return
        
        ig = InstagramAPI(login_method, credential)
        idx = 0
        while not stop_event.is_set():
            for target in targets:
                if stop_event.is_set():
                    break
                try:
                    poll = polls[idx % len(polls)]
                    poll_text = f"📊 {poll['question']}\n\n1. {poll['options'][0]}\n2. {poll['options'][1]}\n\n👉 Reply số 1 hoặc 2"
                    ig.send_message(target, poll_text, target_is_id=True)
                    print(f"[IG TPoll Task {task_id}] ✅ Đã gửi poll: {poll['question'][:50]}")
                    idx += 1
                except Exception as e:
                    print(f"[IG TPoll Task {task_id}] Lỗi: {e}")
                for _ in range(int(delay * 10)):
                    if stop_event.is_set():
                        break
                    time.sleep(0.1)
    except Exception as e:
        print(f"[IG TPoll Task {task_id}] Lỗi: {e}")

# ============= HÀM XỬ LÝ ĐĂNG NHẬP INSTAGRAM =============
def parse_ig_credential(credential_str):
    """Parse credential từ chuỗi nhập vào"""
    credential_str = credential_str.strip()
    if credential_str.startswith('{') or '=' in credential_str:
        # Dạng cookie
        return ('cookie', credential_str)
    else:
        # Dạng username:password
        if ':' in credential_str:
            parts = credential_str.split(':', 1)
            return ('password', (parts[0], parts[1]))
        else:
            return ('username', credential_str)


# ============= BIẾN TOÀN CỤC =============
da_doi_avt_dict = {}

# ============= HÀM KIỂM TRA COOKIE =============
def kiem_tra_cookie(cookie):
    try:
        if 'c_user=' not in cookie:
            return {"status": "failed", "msg": "Cookie không chứa user_id"}
        user_id = cookie.split('c_user=')[1].split(';')[0]
        url = f"https://graph2.facebook.com/v3.3/{user_id}/picture?redirect=0"
        response = requests.get(url, timeout=30)
        check_data = response.json()
        if not check_data.get('data', {}).get('height') or not check_data.get('data', {}).get('width'):
            return {"status": "failed", "msg": "Cookie không hợp lệ"}
        headers = {
            'authority': 'm.facebook.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
            'cookie': cookie,
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        profile_response = requests.get(f'https://m.facebook.com/profile.php?id={user_id}', headers=headers, timeout=30)
        name = profile_response.text.split('<title>')[1].split('<')[0].strip()
        return {"status": "success", "name": name, "user_id": user_id, "msg": "thành công"}
    except Exception as e:
        return {"status": "failed", "msg": f"Lỗi: {str(e)}"}

# ============= HÀM TẠO TÊN VIỆT NAM =============
def tao_ten_viet_nam():
    ho = ['Nguyễn', 'Trần', 'Lê', 'Phạm', 'Hoàng', 'Vũ', 'Đặng', 'Bùi', 'Đỗ', 'Hồ']
    ten_dem = ['Văn', 'Thị', 'Ngọc', 'Minh', 'Hồng', 'Anh', 'Hải', 'Bích', 'Đức', 'Lan']
    ten = ['An', 'Bình', 'Cường', 'Duy', 'Hà', 'Hùng', 'Hương', 'Khang', 'Lan', 'Linh']
    
    ten_viet_nam = []
    for i in range(1000):
        ho_random = random.choice(ho)
        structure = random.choice([2, 3])
        if structure == 2:
            ten_random = random.choice(ten)
            name = f"{ho_random} {ten_random}"
        else:
            ten_dem_random = random.choice(ten_dem)
            ten_random = random.choice(ten)
            name = f"{ho_random} {ten_dem_random} {ten_random}"
        ten_viet_nam.append(name)
    return ten_viet_nam

# ============= CLASS FACEBOOK =============
class Facebook:
    def __init__(self, cookie):
        self.fb_dtsg = ''
        self.jazoest = ''
        self.cookie = cookie
        self.session = requests.Session()
        self.id = self.cookie.split('c_user=')[1].split(';')[0]
        self.commented_posts = set()
        self.headers = {
            'authority': 'www.facebook.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
            'accept-language': 'vi',
            'cookie': self.cookie,
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        url = self.session.get(f'https://www.facebook.com/{self.id}', headers=self.headers).url
        response = self.session.get(url, headers=self.headers).text
        matches = re.findall(r'\["DTSGInitialData",\[\],\{"token":"(.*?)"\}', response)
        if len(matches) > 0:
            self.fb_dtsg = matches[0]
            jazoest_match = re.findall(r'jazoest=(.*?)\"', response)
            if jazoest_match:
                self.jazoest = jazoest_match[0]

    def thong_tin(self):
        try:
            get = self.session.get('https://www.facebook.com/me', headers=self.headers).url
            url = 'https://www.facebook.com/' + get.split('%2F')[-2] + '/' if 'next=' in get else get
            response = self.session.get(url, headers=self.headers, params={"locale": "vi_VN"})
            data_split = response.text.split('"CurrentUserInitialData",[],{')
            json_data = '{' + data_split[1].split('},')[0] + '}'
            parsed_data = json.loads(json_data)
            id = parsed_data.get('USER_ID', '0')
            name = parsed_data.get('NAME', '')
            if id == '0' and name == '':
                return 'cookieout'
            else:
                return {'success': 200, 'id': id, 'name': name}
        except:
            return 'cookieout'

    def tim_ban(self, text):
        try:
            data = {
                'av': self.id,
                'fb_dtsg': self.fb_dtsg,
                'jazoest': self.jazoest,
                'fb_api_caller_class': 'RelayModern',
                'variables': json.dumps({"args": {"text": text}, "count": 5}),
                'doc_id': '9545374252239656'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data).json()
            profile = response["data"]["serpResponse"]["results"]["edges"][0]['rendering_strategy']['result_rendering_strategies'][0]['view_model']['profile']
            return {'status': 'success', 'id': profile.get('id'), 'name': profile.get('name')}
        except:
            return {'status': 'error'}

    def ket_ban(self, idkb):
        try:
            data = {
                'av': self.id,
                'fb_dtsg': self.fb_dtsg,
                'jazoest': self.jazoest,
                'variables': json.dumps({"input": {"friend_requestee_ids": [idkb], "actor_id": self.id}}),
                'doc_id': '8805328442902902'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data).json()
            trangthai = response["data"]["friend_request_send"]["friend_requestees"]
            if trangthai and trangthai[0].get('friendship_status') == 'OUTGOING_REQUEST':
                return {'status': 'success'}
            return {'status': 'error'}
        except:
            return {'status': 'error'}

    def lay_id_bai_viet(self):
        try:
            variables = {"count": 10, "feedLocation": "NEWSFEED", "scale": 1}
            data = {
                'av': self.id,
                'fb_dtsg': self.fb_dtsg,
                'jazoest': self.jazoest,
                'variables': json.dumps(variables),
                'doc_id': '29492828377027602'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data).text
            post_ids = re.findall(r'"post_id":"(\d+)"', response)
            if post_ids:
                for post_id in post_ids:
                    if post_id not in self.commented_posts:
                        return {'status': 'success', 'idpost': post_id}
                self.commented_posts.clear()
                return {'status': 'success', 'idpost': post_ids[0]}
            return {'status': 'error'}
        except:
            return {'status': 'error'}

    def binh_luan(self, id, msg):
        try:
            feedback_id = base64.b64encode(f"feedback:{id}".encode()).decode()
            data = {
                'av': self.id,
                'fb_dtsg': self.fb_dtsg,
                'jazoest': self.jazoest,
                'variables': json.dumps({"input": {"feedback_id": feedback_id, "message": {"text": msg}, "actor_id": self.id}}),
                'doc_id': '24323081780615819'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data)
            if response.status_code == 200:
                self.commented_posts.add(id)
                return {'status': 'success'}
            return {'status': 'error'}
        except:
            return {'status': 'error'}

    def dang_bai(self, noi_dung):
        try:
            data = {
                'av': self.id,
                'fb_dtsg': self.fb_dtsg,
                'jazoest': self.jazoest,
                'variables': json.dumps({"input": {"message": {"text": noi_dung}, "actor_id": self.id}}),
                'doc_id': '9676012065790356'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data)
            return {'status': 'success'} if response.status_code == 200 else {'status': 'error'}
        except:
            return {'status': 'error'}

    def tim_nhom(self, keyword):
        try:
            data = {
                'av': self.id,
                'fb_dtsg': self.fb_dtsg,
                'jazoest': self.jazoest,
                'variables': json.dumps({"args": {"text": keyword}, "count": 5}),
                'doc_id': '24016506881293628'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data).json()
            thongtin = response['data']["serpResponse"]["results"]['edges'][0]['rendering_strategy']['view_model']['profile']
            return {'status': 'success', 'id': thongtin.get('id'), 'name': thongtin.get('name')}
        except:
            return {'status': 'error'}

    def tham_gia_nhom(self, group_id):
        try:
            data = {
                'av': self.id,
                'fb_dtsg': self.fb_dtsg,
                'jazoest': self.jazoest,
                'variables': json.dumps({"groupID": group_id, "input": {"group_id": group_id, "actor_id": self.id}}),
                'doc_id': '5853134681430324'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data)
            return {'status': 'success'} if group_id in response.text else {'status': 'error'}
        except:
            return {'status': 'error'}

    def doi_anh_dai_dien(self, image_path):
        try:
            if da_doi_avt_dict.get(self.id, False):
                return {'status': 'skip'}
            
            # Upload ảnh
            files = {'file': open(image_path, 'rb')}
            params = {'profile_id': self.id, 'fb_dtsg': self.fb_dtsg, 'jazoest': self.jazoest}
            response = self.session.post('https://www.facebook.com/profile/picture/upload', params=params, files=files)
            text = response.text[9:] if response.text.startswith('for (;;);') else response.text
            data = json.loads(text)
            fbid = data.get('payload', {}).get('fbid')
            
            if fbid:
                # Set ảnh đại diện
                payload = {
                    'av': self.id,
                    'fb_dtsg': self.fb_dtsg,
                    'variables': json.dumps({"input": {"existing_photo_id": fbid, "profile_id": self.id}}),
                    'doc_id': '24342990855357700'
                }
                response = self.session.post('https://www.facebook.com/api/graphql/', data=payload)
                if response.status_code == 200:
                    da_doi_avt_dict[self.id] = True
                    return {'status': 'success'}
            return {'status': 'error'}
        except Exception as e:
            print(f"Lỗi đổi ảnh: {e}")
            return {'status': 'error'}

# ============= TASK NUOI =============
def nuoi_task(cookie, image_folder, delay, stop_event, task_id, user_id):
    """Vòng lặp nuôi tài khoản Facebook"""
    fb = Facebook(cookie)
    
    # Kiểm tra cookie
    info = fb.thong_tin()
    if info == 'cookieout':
        print(f"[Nuoi Task {task_id}] ❌ Cookie không hợp lệ!")
        return
    
    print(f"[Nuoi Task {task_id}] ✅ Bắt đầu nuôi: {info['name']} (ID: {info['id']})")
    
    # Lấy danh sách ảnh
    images = []
    if os.path.exists(image_folder):
        images = [os.path.join(image_folder, f) for f in os.listdir(image_folder) 
                  if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
    
    # Danh sách tên để tìm bạn
    ten_tim = tao_ten_viet_nam()
    
    # Danh sách từ khóa tìm nhóm
    tu_khoa_nhom = ['công nghệ', 'kinh doanh', 'giải trí', 'ẩm thực', 'du lịch']
    
    idx_content = 0
    while not stop_event.is_set():
        # 1. Đổi ảnh đại diện
        if images and not stop_event.is_set():
            anh = random.choice(images)
            result = fb.doi_anh_dai_dien(anh)
            if result['status'] == 'success':
                print(f"[Nuoi Task {task_id}] ✅ Đổi ảnh: {os.path.basename(anh)}")
            elif result['status'] == 'skip':
                print(f"[Nuoi Task {task_id}] ⏭️ Bỏ qua đổi ảnh (đã đổi lần trước)")
            
            for _ in range(int(delay * 5)):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
        
        # 2. Tìm và kết bạn
        if not stop_event.is_set():
            ten = random.choice(ten_tim)
            tim = fb.tim_ban(ten)
            if tim.get('status') == 'success':
                ket_ban = fb.ket_ban(tim['id'])
                if ket_ban.get('status') == 'success':
                    print(f"[Nuoi Task {task_id}] ✅ Kết bạn: {tim['name']}")
                else:
                    print(f"[Nuoi Task {task_id}] ❌ Kết bạn thất bại với {tim['name']}")
            else:
                print(f"[Nuoi Task {task_id}] ❌ Không tìm thấy bạn với tên {ten}")
            
            for _ in range(int(delay * 5)):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
        
        # 3. Bình luận bài viết
        if not stop_event.is_set():
            bv = fb.lay_id_bai_viet()
            if bv.get('status') == 'success':
                noi_dung_cmt = f"Hay quá! {random.choice(['👍', '❤️', '😊', '👏'])}"
                cmt = fb.binh_luan(bv['idpost'], noi_dung_cmt)
                if cmt.get('status') == 'success':
                    print(f"[Nuoi Task {task_id}] ✅ Bình luận bài {bv['idpost']}: {noi_dung_cmt}")
                else:
                    print(f"[Nuoi Task {task_id}] ❌ Bình luận thất bại")
            else:
                print(f"[Nuoi Task {task_id}] ❌ Không tìm thấy bài viết")
            
            for _ in range(int(delay * 5)):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
        
        # 4. Đăng bài (nếu có file nuoi.txt)
        nuoi_file = os.path.join(UPLOAD_DIR, str(user_id), "nuoi.txt")
        if os.path.exists(nuoi_file):
            with open(nuoi_file, 'r', encoding='utf-8') as f:
                contents = [l.strip() for l in f if l.strip()]
            if contents:
                noi_dung = contents[idx_content % len(contents)]
                dang = fb.dang_bai(noi_dung)
                if dang.get('status') == 'success':
                    print(f"[Nuoi Task {task_id}] ✅ Đăng bài: {noi_dung[:50]}...")
                    idx_content += 1
                else:
                    print(f"[Nuoi Task {task_id}] ❌ Đăng bài thất bại")
        
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)
        
        # 5. Tham gia nhóm
        if not stop_event.is_set():
            tu_khoa = random.choice(tu_khoa_nhom)
            nhom = fb.tim_nhom(tu_khoa)
            if nhom.get('status') == 'success':
                tham_gia = fb.tham_gia_nhom(nhom['id'])
                if tham_gia.get('status') == 'success':
                    print(f"[Nuoi Task {task_id}] ✅ Tham gia nhóm: {nhom['name']}")
                else:
                    print(f"[Nuoi Task {task_id}] ❌ Tham gia nhóm thất bại")
            else:
                print(f"[Nuoi Task {task_id}] ❌ Không tìm thấy nhóm với từ khóa {tu_khoa}")
        
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)

# ============= THÊM VÀO ĐẦU FILE (PHẦN IMPORT) =============
import re
import json

# ============= CLASS FACEBOOK SESSION =============
class FacebookSession:
    def __init__(self, cookie):
        self.cookie = cookie
        self.uid = self.get_uid()
        self.fb_dtsg, self.jazoest = self.init_params()

    def get_uid(self):
        try:
            return re.search(r"c_user=(\d+)", self.cookie).group(1)
        except:
            raise Exception("Cookie không hợp lệ (thiếu c_user)")

    def init_params(self):
        headers = {
            'Cookie': self.cookie,
            'User-Agent': 'Mozilla/5.0'
        }
        try:
            response = requests.get('https://www.facebook.com', headers=headers, timeout=10)
            fb_dtsg_match = re.search(r'"token":"(.*?)"', response.text)
            jazoest_match = re.search(r'name="jazoest" value="(\d+)"', response.text)

            if not fb_dtsg_match:
                response = requests.get('https://mbasic.facebook.com', headers=headers, timeout=10)
                fb_dtsg_match = re.search(r'name="fb_dtsg" value="(.*?)"', response.text)
                jazoest_match = re.search(r'name="jazoest" value="(\d+)"', response.text)

            if fb_dtsg_match:
                fb_dtsg = fb_dtsg_match.group(1)
                jazoest = jazoest_match.group(1) if jazoest_match else "22036"
                return fb_dtsg, jazoest
            else:
                raise Exception("Không thể lấy fb_dtsg")
        except Exception as e:
            raise Exception(f"Lỗi: {str(e)}")

# ============= HÀM LẤY DANH SÁCH BOX =============
def get_thread_list(cookie, limit=100):
    try:
        session = FacebookSession(cookie)
    except Exception as e:
        return {"error": str(e)}

    form_data = {
        "av": session.uid,
        "__user": session.uid,
        "fb_dtsg": session.fb_dtsg,
        "jazoest": session.jazoest,
        "__a": "1",
        "__req": "1b",
        "__rev": "1015919737",
        "__comet_req": "15",
        "__spin_r": "999999999",
        "__spin_b": "trunk",
        "__spin_t": str(int(time.time())),
    }

    queries = {
        "o0": {
            "doc_id": "3336396659757871",
            "query_params": {
                "limit": limit,
                "before": None,
                "tags": ["INBOX"],
                "includeDeliveryReceipts": False,
                "includeSeqID": True,
            }
        }
    }

    form_data["queries"] = json.dumps(queries)

    headers = {
        "Cookie": cookie,
        "User-Agent": "Mozilla/5.0",
        "Content-Type": "application/x-www-form-urlencoded",
    }

    try:
        response = requests.post(
            "https://www.facebook.com/api/graphqlbatch/",
            data=form_data,
            headers=headers,
            timeout=15
        )

        data_raw = response.text.split('{"successful_results"')[0]
        data = json.loads(data_raw)

        threads = data["o0"]["data"]["viewer"]["message_threads"]["nodes"]

        result = []
        for thread in threads:
            if not thread.get("thread_key") or not thread["thread_key"].get("thread_fbid"):
                continue
            result.append({
                "thread_id": thread["thread_key"]["thread_fbid"],
                "thread_name": thread.get("name") or "Không có tên",
                "thread_type": thread.get("thread_type", "UNKNOWN")
            })

        return result

    except Exception as e:
        return {"error": f"Lỗi: {e}"}

# ============= TASK NGONMESANH (GỬI HẾT NỘI DUNG TRONG 1 TIN NHẮN) =============
def ngonmesanh_task(cookie, recipient_id, image_url, messages, delay, stop_event, task_id, user_id):
    """
    Gửi tin nhắn kèm ảnh - Dồn toàn bộ nội dung file vào 1 tin nhắn
    """
    client = NanhMessengerMQTT(cookie)
    if not client.connected:
        print(f"[Task {task_id}] ❌ Không thể kết nối MQTT")
        return
    
    # Tải và upload ảnh trước
    print(f"[Task {task_id}] 📥 Đang tải ảnh từ: {image_url}")
    image_path = download_image(image_url)
    if not image_path:
        print(f"[Task {task_id}] ❌ Không thể tải ảnh")
        return
    
    print(f"[Task {task_id}] 📤 Đang upload ảnh lên Facebook...")
    image_id = client.upload_image(image_url)
    if not image_id:
        print(f"[Task {task_id}] ❌ Không thể upload ảnh")
        if os.path.exists(image_path):
            os.remove(image_path)
        return
    
    print(f"[Task {task_id}] ✅ Upload ảnh thành công! ID: {image_id}")
    
    # Gộp toàn bộ nội dung file thành 1 tin nhắn duy nhất
    full_message = "\n\n".join(messages)  # Cách nhau 2 dòng
    print(f"[Task {task_id}] 📝 Nội dung gộp: {len(full_message)} ký tự, {len(messages)} dòng")
    
    while not stop_event.is_set():
        try:
            success, error = client.send_message(recipient_id, full_message, image_id)
            
            if success:
                print(f"[Task {task_id}] ✅ Đã gửi (gộp {len(messages)} dòng): {full_message[:100]}...")
            else:
                print(f"[Task {task_id}] ❌ Gửi thất bại: {error}")
            
        except Exception as e:
            print(f"[Task {task_id}] Lỗi: {e}")
        
        # Delay giữa các lần gửi
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)
    
    # Dọn dẹp
    if os.path.exists(image_path):
        os.remove(image_path)
    client.disconnect()

# ============= THÊM VÀO ĐẦU FILE (PHẦN IMPORT) =============
import requests

# ============= WECHAT WORK CLASS =============
class WeComBot:
    def __init__(self, corp_id, secret, agent_id):
        self.corp_id = corp_id
        self.secret = secret
        self.agent_id = agent_id
        self.access_token = None
        self.token_expire = 0
    
    def get_access_token(self):
        """Lấy access_token từ WeChat Work"""
        if self.access_token and time.time() < self.token_expire:
            return self.access_token
        
        url = f'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={self.corp_id}&corpsecret={self.secret}'
        try:
            response = requests.get(url, timeout=10).json()
            if 'access_token' in response:
                self.access_token = response['access_token']
                self.token_expire = time.time() + 7000
                return self.access_token
            else:
                print(f"Lỗi token: {response}")
                return None
        except Exception as e:
            print(f"Lỗi: {e}")
            return None
    
    def send_message(self, user, message):
        """Gửi tin nhắn text"""
        token = self.get_access_token()
        if not token:
            return False, "Không lấy được access_token"
        
        send_url = f'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={token}'
        data = {
            "touser": user,
            "msgtype": "text",
            "agentid": self.agent_id,
            "text": {"content": message},
            "safe": 0
        }
        try:
            response = requests.post(send_url, json=data, timeout=10).json()
            if response.get('errcode') == 0:
                return True, "Gửi thành công"
            else:
                return False, response.get('errmsg', 'Lỗi')
        except Exception as e:
            return False, str(e)

# ============= TASK TREOWECHAT (GỬI HẾT NỘI DUNG 1 LẦN) =============
def treowechat_task(access_token, agent_id, user, messages, delay, stop_event, task_id, user_id):
    """
    Gửi toàn bộ nội dung file trong 1 tin nhắn, lặp lại
    """
    # Gộp toàn bộ nội dung
    full_message = "\n\n".join(messages)
    print(f"[WeCom Task {task_id}] 📝 Nội dung gộp: {len(full_message)} ký tự, {len(messages)} dòng")
    
    while not stop_event.is_set():
        try:
            send_url = f'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={access_token}'
            data = {
                "touser": user,
                "msgtype": "text",
                "agentid": agent_id,
                "text": {"content": full_message},
                "safe": 0
            }
            response = requests.post(send_url, json=data, timeout=10).json()
            
            if response.get('errcode') == 0:
                print(f"[WeCom Task {task_id}] ✅ Đã gửi: {full_message[:100]}...")
            else:
                print(f"[WeCom Task {task_id}] ❌ Lỗi: {response.get('errmsg')}")
            
        except Exception as e:
            print(f"[WeCom Task {task_id}] Lỗi: {e}")
        
        # Delay
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)

# ============= TASK NHAYWECHAT (GỬI TỪNG DÒNG) =============
def nhaywechat_task(access_token, agent_id, user, messages, delay, stop_event, task_id, user_id):
    """
    Gửi từng dòng nội dung, mỗi dòng 1 tin nhắn
    """
    idx = 0
    while not stop_event.is_set():
        try:
            msg = messages[idx % len(messages)]
            
            send_url = f'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={access_token}'
            data = {
                "touser": user,
                "msgtype": "text",
                "agentid": agent_id,
                "text": {"content": msg},
                "safe": 0
            }
            response = requests.post(send_url, json=data, timeout=10).json()
            
            if response.get('errcode') == 0:
                print(f"[WeCom Task {task_id}] ✅ Đã gửi: {msg[:50]}")
            else:
                print(f"[WeCom Task {task_id}] ❌ Lỗi: {response.get('errmsg')}")
            
            idx += 1
            
        except Exception as e:
            print(f"[WeCom Task {task_id}] Lỗi: {e}")
        
        # Delay
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)

# ============= CẤU HÌNH NGL =============
NGL_USER_AGENTS = [
    "Mozilla/5.0 (Linux; Android 9; Infinix X604) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
]

# ========== HÀM GỬI TIN NHẮN NGL ==========
def send_ngl_message(target, message):
    """Gửi tin nhắn đến NGL link"""
    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9,vi;q=0.8',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'origin': 'https://ngl.link',
        'referer': f'https://ngl.link/{target}',
        'x-requested-with': 'XMLHttpRequest',
        'user-agent': random.choice(NGL_USER_AGENTS),
    }
    
    data = {
        'username': str(target),
        'question': str(message),
        'deviceId': str(uuid.uuid4()),
        'gameSlug': '',
        'referrer': '',
    }
    
    try:
        response = requests.post("https://ngl.link/api/submit", data=data, headers=headers, timeout=10)
        return response.status_code == 200, response.status_code
    except Exception as e:
        return False, str(e)

# ========== TASK NHAYNGL ==========
def nhayngl_task(targets, messages, delay, stop_event, task_id, user_id):
    """Task spam NGL link - 1 thread xoay vòng qua các target"""
    print(f"[NGL Task {task_id}] Bắt đầu spam {len(targets)} target, {len(messages)} tin nhắn")
    
    target_index = 0
    message_index = 0
    total_targets = len(targets)
    total_messages = len(messages)
    
    while not stop_event.is_set():
        target = targets[target_index % total_targets]
        message = messages[message_index % total_messages]
        
        success, status = send_ngl_message(target, message)
        
        if success:
            print(f"[NGL Task {task_id}] ✅ @{target} - {message[:50]}...")
        else:
            print(f"[NGL Task {task_id}] ❌ @{target} - Lỗi: {status}")
        
        target_index += 1
        message_index += 1
        
        # Delay
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)
    
    print(f"[NGL Task {task_id}] Đã dừng")

# ========== HÀM LẤY 3 DÒNG ĐẦU FILE ==========
def get_first_3_lines(file_path):
    """Đọc 3 dòng đầu tiên của file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = [line.strip() for line in f if line.strip()]
        return lines[:3]  # Chỉ lấy 3 dòng đầu
    except Exception as e:
        print(f"Lỗi đọc file: {e}")
        return None

# ========== TASK TREONGL ==========
def treongl_task(targets, messages, delay, stop_event, task_id, user_id):
    """Task treo NGL - gửi 3 dòng đầu lặp lại"""
    print(f"[TreoNGL Task {task_id}] Bắt đầu treo {len(targets)} target, {len(messages)} tin nhắn")
    
    target_index = 0
    message_index = 0
    total_targets = len(targets)
    total_messages = len(messages)
    
    while not stop_event.is_set():
        target = targets[target_index % total_targets]
        message = messages[message_index % total_messages]
        
        success, status = send_ngl_message(target, message)
        
        if success:
            print(f"[TreoNGL Task {task_id}] ✅ @{target} - {message[:50]}...")
        else:
            print(f"[TreoNGL Task {task_id}] ❌ @{target} - Lỗi: {status}")
        
        target_index += 1
        message_index += 1
        
        # Delay
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)
    
    print(f"[TreoNGL Task {task_id}] Đã dừng")
# ============= KIỂM TRA QUYỀN =============
def has_permission(user_id):
    """Kiểm tra user có quyền dùng bot không"""
    # Admin luôn có quyền
    if user_id == ADMIN_ID or user_id in ADMIN_IDS:
        return True
    
    # Kiểm tra user có task active không
    if user_id in user_active_tasks:
        task = user_active_tasks[user_id]
        if task["expiration"] > datetime.now():
            return True
        else:
            # Hết hạn, xóa task
            del user_active_tasks[user_id]
    
    return False
    
import base64
import secrets
import requests
from datetime import datetime, timedelta

# API rút gọn link
LINK4M_TOKEN = "68fd7b44c0965516d95135ce"  # Token của bạn

def get_shortened_link(url):
    """Rút gọn URL bằng link4m.co"""
    try:
        api_url = f"https://link4m.co/api-shorten/v2?api={LINK4M_TOKEN}&url={url}"
        response = requests.get(api_url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == "success":
                return data.get("shortenedUrl", url)
        return url
    except Exception as e:
        print(f"Lỗi rút gọn link: {e}")
        return url

def generate_task_key(ip_address, user_id):
    """Tạo key dựa trên IP và user_id"""
    ngay = datetime.now().day
    key1 = str(ngay * 27 + 27)
    ip_numbers = ''.join(filter(str.isdigit, ip_address))
    # Thêm user_id để key độc nhất
    key = f'NDK{key1}{ip_numbers}{user_id}{secrets.token_hex(4)}'
    return key

def create_task_link(ip_address, user_id, days=7):
    """Tạo link task cho user"""
    key = generate_task_key(ip_address, user_id)
    expiration = datetime.now() + timedelta(days=days)
    # Đặt hết hạn lúc 23:59:59
    expiration = expiration.replace(hour=23, minute=59, second=59, microsecond=0)
    
    url = f'https://xuanthangcubu.x10.network/?ma={key}'
    
    # Rút gọn link
    short_url = get_shortened_link(url)
    
    return {
        "key": key,
        "url": url,
        "short_url": short_url,
        "expiration": expiration,
        "days": days
    }

# Lưu trữ task đã tạo
created_tasks = {}  # {key: {"user_id": int, "expiration": datetime, "used": bool}}
user_active_tasks = {}  # {user_id: {"key": str, "expiration": datetime, "activated_at": datetime}}
# ============= DANH SÁCH CÁC BƯỚC DAME =============
list_dzi_chuyen_nghiep = [
    "Bước 1: Fake Profile → Me",
    "Bước 2: Fake tên vào biệt danh (nếu không có avatar)",
    "Bước 3: Chọn dòng 'Giả mạo danh tính' → Lựa chọn 'Giả mạo tôi hoặc người tôi biết'",
    "Bước 4: Chọn dòng 'Nội dung không phù hợp' → Lựa chọn 'Spam hoặc gây hiểu lầm'",
    "Bước 5: Chọn dòng 'Vi phạm cộng đồng' → Lựa chọn 'Ngôn từ kích động thù địch'",
    "Bước 6: Đang xử lý các bài post (chủ yếu cắn post để die nhanh)",
    "Bước 7: Chọn dòng 'Giả mạo danh tính' → Lựa chọn 'Giả mạo tôi hoặc người tôi biết'"
]

list_dzi_clone = [
    "Bước 1: Fake Profile → Me",
    "Bước 2: Fake Profile người nổi tiếng → 'markzuckerberg'",
    "Bước 3: Fake Profile doanh nghiệp → 'meta for business'",
    "Bước 4: Chọn dòng 'Nội dung người lớn' → Lựa chọn 'Vi phạm nội dung 18+'",
    "Bước 5: Chọn dòng 'Giả mạo danh tính' → Lựa chọn 'Tài khoản giả mạo'",
    "Bước 6: Chọn dòng 'Spam hoặc lừa đảo' → Lựa chọn 'Lừa đảo tài chính'",
    "Bước 7: Chọn dòng 'Vi phạm cộng đồng' → Lựa chọn 'Bạo lực hoặc tổ chức nguy hiểm'",
    "Bước 8: Chọn dòng 'Nội dung sai sự thật' → Lựa chọn 'Tin giả hoặc gây hiểu lầm'",
    "Bước 9: Chọn dòng 'Quấy rối' → Lựa chọn 'Quấy rối hoặc bắt nạt'",
    "Bước 10: Đang kẹp clone (để dễ die hơn)",
    "Bước 11: Chọn dòng 'Hành vi đáng ngờ' → Lựa chọn 'Tài khoản spam'",
    "Bước 12: Chọn dòng 'Bán hàng trái phép' → Lựa chọn 'Bán hàng vi phạm chính sách'"
]

list_dzi_profile_thuong = [
    "Bước 1: Fake Profile → Me",
    "Bước 2: Fake Profile người nổi tiếng → 'markzuckerberg'",
    "Bước 3: Fake Profile doanh nghiệp → 'meta for business'",
    "Bước 4: Chọn dòng 'Nội dung người lớn' → Lựa chọn 'Vi phạm nội dung 18+'",
    "Bước 5: Chọn dòng 'Giả mạo danh tính' → Lựa chọn 'Tài khoản giả mạo'",
    "Bước 6: Chọn dòng 'Vi phạm cộng đồng' → Lựa chọn 'Ngôn từ kích động thù địch'",
    "Bước 7: Chọn dòng 'Spam hoặc lừa đảo' → Lựa chọn 'Lừa đảo tài chính'",
    "Bước 8: Chọn dòng 'Bạo lực' → Lựa chọn 'Nội dung bạo lực hoặc đồ máu'",
    "Bước 9: Chọn dòng 'Quấy rối' → Lựa chọn 'Quấy rối hoặc bắt nạt'",
    "Bước 10: Chọn dòng 'Vi phạm quyền riêng tư' → Lựa chọn 'Chia sẻ thông tin cá nhân'",
    "Bước 11: Đang xử lý các bài post: Report all dòng 'Fraud or Scam'",
    "Bước 12: Chọn dòng 'Hành vi đáng ngờ' → Lựa chọn 'Tài khoản spam'"
]

# ============= CLASS FACEBOOK DAME MANAGER =============
class FacebookDameManager:
    def __init__(self, cookie):
        self.cookie = cookie
        self.fb_dtsg = None
        self.jazoest = None
        self.uid = None
        self.user_info = None
        
        try:
            self.uid = self._extract_user_id()
            self._init_params()
            self.user_info = self._get_own_info()
        except Exception as e:
            raise Exception(f"Lỗi khởi tạo: {str(e)}")
    
    def _extract_user_id(self):
        try:
            c_user = re.search(r"c_user=(\d+)", self.cookie).group(1)
            return c_user
        except:
            raise Exception("Cookie không hợp lệ hoặc đã hết hạn")

    def _init_params(self):
        headers = {
            'Cookie': self.cookie,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
            'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8'
        }

        response = requests.get('https://www.facebook.com', headers=headers, timeout=15)
        fb_dtsg_match = re.search(r'"token":"(.*?)"', response.text)
        jazoest_match = re.search(r'jazoest=(\d+)', response.text)
        
        if jazoest_match:
            self.jazoest = jazoest_match.group(1)
        
        if not fb_dtsg_match:
            response = requests.get('https://mbasic.facebook.com', headers=headers, timeout=15)
            fb_dtsg_match = re.search(r'name="fb_dtsg" value="(.*?)"', response.text)
        
        if fb_dtsg_match:
            self.fb_dtsg = fb_dtsg_match.group(1)
        else:
            raise Exception("Không lấy được fb_dtsg - Cookie có thể đã hết hạn")

    def _get_own_info(self):
        return self.get_user_info(self.uid)

    def get_user_info(self, uid):
        try:
            form = {
                "ids[0]": uid,
                "fb_dtsg": self.fb_dtsg,
                "__a": 1,
                "__req": "1b",
                "__rev": "1015919737"
            }
            
            headers = {
                'Cookie': self.cookie,
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0'
            }
            
            response = requests.post("https://www.facebook.com/chat/user_info/", headers=headers, data=form, timeout=10)
            
            text_response = response.text
            if text_response.startswith("for (;;);"):
                text_response = text_response[9:]
            
            res_data = json.loads(text_response)
            
            if "payload" in res_data and "profiles" in res_data["payload"]:
                profiles = res_data["payload"]["profiles"]
                first_id = next(iter(profiles))
                profile = profiles[first_id]
                return {
                    "id": first_id,
                    "name": profile.get("name", ""),
                    "url": profile.get("url", ""),
                    "gender": profile.get("gender", "")
                }
            return {"error": "Không tìm thấy thông tin"}
        except Exception as e:
            return {"error": str(e)}

    def get_uid_from_link(self, link):
        url = "https://id.traodoisub.com/api.php"
        headers = {"user-agent": "Mozilla/5.0"}
        data = {"link": link}
        
        try:
            response = requests.post(url, headers=headers, data=data, timeout=10)
            if response.status_code == 200:
                return response.json().get("id")
            return None
        except:
            return None

    def check_uid_status(self, uid):
        try:
            response = requests.get(f"https://graph.facebook.com/{uid}/picture?redirect=0", timeout=5)
            if response.status_code == 200:
                return "live"
            return "die"
        except:
            return "unknown"

# ============= TASK DAME =============
dame_tasks = {}

def dame_task(cookie, target_link, dame_type, stop_event, task_id, user_id):
    """Task dame tài khoản Facebook"""
    try:
        # Chọn danh sách bước
        if dame_type == "1":
            steps = list_dzi_chuyen_nghiep
            type_name = "Chuyên Nghiệp"
        elif dame_type == "2":
            steps = list_dzi_clone
            type_name = "Clone"
        else:
            steps = list_dzi_profile_thuong
            type_name = "Profile Bình Thường"
        
        # Khởi tạo manager
        manager = FacebookDameManager(cookie)
        
        # Lấy UID từ link
        target_uid = manager.get_uid_from_link(target_link)
        if not target_uid:
            print(f"[Dame Task {task_id}] ❌ Không lấy được UID từ link!")
            return
        
        # Lấy thông tin target
        target_info = manager.get_user_info(target_uid)
        if "error" in target_info:
            print(f"[Dame Task {task_id}] ❌ {target_info['error']}")
            return
        
        target_name = target_info.get("name", "Unknown")
        
        print(f"[Dame Task {task_id}] 🎯 Mục tiêu: {target_name} (UID: {target_uid})")
        print(f"[Dame Task {task_id}] 📋 Loại dame: {type_name}")
        
        cycle = 1
        while not stop_event.is_set():
            print(f"[Dame Task {task_id}] 🔄 Vòng lặp #{cycle}")
            
            for step in steps:
                if stop_event.is_set():
                    break
                print(f"[Dame Task {task_id}] ⏳ {step}")
                # Delay giữa các bước
                for _ in range(int(random.uniform(0.8, 2.0) * 10)):
                    if stop_event.is_set():
                        break
                    time.sleep(0.1)
            
            # Kiểm tra trạng thái
            status = manager.check_uid_status(target_uid)
            
            if status == "die":
                print(f"[Dame Task {task_id}] 🎉 THÀNH CÔNG! Tài khoản {target_name} đã bị khóa")
                break
            else:
                print(f"[Dame Task {task_id}] 📊 Tài khoản vẫn đang hoạt động, tiếp tục vòng #{cycle}")
                cycle += 1
                # Delay giữa các vòng
                for _ in range(int(random.uniform(2, 4) * 10)):
                    if stop_event.is_set():
                        break
                    time.sleep(0.1)
        
        print(f"[Dame Task {task_id}] Đã dừng")
        
    except Exception as e:
        print(f"[Dame Task {task_id}] ❌ Lỗi: {e}")
        
# ============= TIKTOK DAME CLASS =============
class TikTokDame:
    def __init__(self, cookie):
        self.cookie = cookie
        self.headers = {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'ar,en-US;q=0.9,en;q=0.8',
            'content-type': 'application/json',
            'cookie': cookie,
            'origin': 'https://www.tiktok.com',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    
    def get_user_id(self, username):
        """Lấy user_id từ username"""
        try:
            url = f'https://www.tiktok.com/@{username}?'
            response = requests.get(url, timeout=10)
            user_id = re.findall('"pageId":"(.*?)"', response.text)
            return user_id[0] if user_id else None
        except:
            return None
    
    def report(self, user_id, reason):
        """Gửi report với lý do cụ thể"""
        url = 'https://www.tiktok.com/node/report/reasons_put?aid=1988&app_name=tiktok_web'
        data = {
            'object_id': str(user_id),
            'owner_id': str(user_id),
            'reason': reason,
            'report_type': "user"
        }
        try:
            response = requests.post(url, json=data, headers=self.headers, timeout=10)
            return response.status_code == 200
        except:
            return False
    
    def dame_full(self, username):
        """Dame tài khoản với 3 lý do"""
        user_id = self.get_user_id(username)
        if not user_id:
            return False, "Không tìm thấy user!"
        
        reasons = ['310', '306', '3051']  # 3 lý do report
        results = []
        
        for reason in reasons:
            success = self.report(user_id, reason)
            results.append(success)
            time.sleep(1)
        
        success_count = results.count(True)
        if success_count >= 2:
            return True, f"✅ Dame thành công! Đã report {success_count}/3 lần"
        else:
            return False, f"❌ Dame thất bại! Chỉ thành công {success_count}/3 lần"

# ============= TASK DAME TIKTOK =============
dame_tiktok_tasks = {}

def dame_tiktok_task(cookie, username, delay, stop_event, task_id, user_id):
    """Task dame TikTok"""
    dame = TikTokDame(cookie)
    
    print(f"[Dame TikTok Task {task_id}] 🎯 Bắt đầu dame: @{username}")
    
    while not stop_event.is_set():
        success, msg = dame.dame_full(username)
        
        if success:
            print(f"[Dame TikTok Task {task_id}] {msg}")
        else:
            print(f"[Dame TikTok Task {task_id}] {msg}")
        
        # Delay giữa các lần dame
        for _ in range(int(delay * 10)):
            if stop_event.is_set():
                break
            time.sleep(0.1)
    
    print(f"[Dame TikTok Task {task_id}] Đã dừng")
    
# ============= THÊM VÀO ĐẦU FILE (PHẦN IMPORT) =============
import requests

# ============= CLASS MINHLOI =============
class MinhLoi:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://dash.lemonhost.me/api/user/billingafk"
        self.headers = {
            "accept": "application/json, text/plain, */*",
            "accept-language": "vi-VN",
            "content-type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "origin": "https://dash.lemonhost.me",
            "referer": "https://dash.lemonhost.me/components/billingafk//billingafk/dist/afk.html",
            "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36"
        }
    
    def get_status(self):
        try:
            response = requests.get(f"{self.base_url}/status", headers=self.headers, timeout=10)
            response.raise_for_status()
            return response.json()
        except:
            return None
    
    def send_afk(self, minutes=1):
        try:
            payload = {"minutes_afk": minutes}
            response = requests.post(f"{self.base_url}/work", headers=self.headers, json=payload, timeout=10)
            response.raise_for_status()
            return response.json()
        except:
            return None

# ============= BIẾN LƯU TRỮ TASK AFK =============
afk_tasks = {}

# ============= TASK AFK LOOP =============
def afk_task_loop(api_key, interval, stop_event, task_id, user_id):
    afk = MinhLoi(api_key)
    count = 0
    
    status = afk.get_status()
    if status and status.get('success'):
        data = status.get('data', {})
        print(f"[AFK Task {task_id}] 💰 Credits: {data.get('user_credits_formatted', 'N/A')}")
    
    while not stop_event.is_set():
        try:
            result = afk.send_afk(minutes=1)
            if result and result.get('success'):
                count += 1
                data = result.get('data', {})
                print(f"[AFK Task {task_id}] ✅ AFK #{count} | +{data.get('credits_awarded', 0)} | Tổng: {data.get('total_credits', 0)}")
            else:
                print(f"[AFK Task {task_id}] ⚠️ Lỗi: {result.get('error_message', 'Unknown') if result else 'No response'}")
            
            for _ in range(int(interval * 10)):
                if stop_event.is_set():
                    break
                time.sleep(0.1)
        except:
            time.sleep(interval)


# ============= LỆNH SETFILE SỬA LẠI PHÂN QUYỀN =============
# Mỗi user chỉ thấy file của mình
user_files = {}  # {user_id: [filename1, filename2]}

# ============= DISCORD BOT =============
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents)
# ============= PHÂN QUYỀN ADMIN =============

ADMIN_FILE = "admin_ids.json"

        # ============= ĐỊNH NGHĨA HÀM KIỂM TRA QUYỀN (THÊM ĐẦU FILE) =============
def is_admin(user_id):
    return user_id == ADMIN_ID or user_id in ADMIN_IDS

def save_admin_ids():
    try:
        with open(ADMIN_FILE, 'w', encoding='utf-8') as f:
            json.dump({"admin_ids": list(ADMIN_IDS)}, f, indent=2)
    except:
        pass

# ============= LỆNH DAME TIKTOK =============
@bot.command()
async def dametiktok(ctx, cookie: str = None, username: str = None, delay: float = 10):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not cookie or not username:
        await ctx.send("❌ Cú pháp: `dametiktok <cookie> <username> [delay]`")
        await ctx.send("📌 VD: `dametiktok sessionid=xxx; tiktokuser 10`")
        return
    username = username.replace('@', '').strip()
    if delay < 5:
        delay = 5
    await ctx.send(f"🎯 **Đang dame tài khoản TikTok: @{username}**")
    await ctx.send(f"⏱️ Delay: {delay} giây mỗi lần")
    test = TikTokDame(cookie)
    user_id = test.get_user_id(username)
    if not user_id:
        await ctx.send(f"❌ Không tìm thấy tài khoản TikTok: @{username}")
        return
    await ctx.send(f"✅ Đã tìm thấy user ID: `{user_id}`")
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "dametiktok", username, stop_event)
    dame_tiktok_tasks[task_id] = stop_event
    threading.Thread(target=dame_tiktok_task, args=(cookie, username, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | Đang dame @{username} | Delay {delay}s")

# ============= LỆNH AFK =============
@bot.command()
async def afk(ctx, api_key: str = None, interval: int = 60):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    
    if not api_key:
        await ctx.send("❌ Cú pháp: `afk <api_key> [interval_giây]`")
        await ctx.send("📌 VD: `afk eyJhbGciOiJIUzI1NiIs... 60`")
        return
    
    if interval < 30:
        interval = 30
    
    if ctx.author.id in afk_tasks:
        await ctx.send("⚠️ Bạn đã có task AFK đang chạy! Dùng `stop <task_id>` để dừng.")
        return
    
    test = MinhLoi(api_key)
    status = test.get_status()
    if not status or not status.get('success'):
        await ctx.send("❌ API Key không hợp lệ!")
        return
    
    data = status.get('data', {})
    credits = data.get('user_credits_formatted', 'N/A')
    
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "afk", "LemonHost", stop_event)
    
    afk_tasks[ctx.author.id] = {"stop": stop_event, "task_id": task_id}
    
    threading.Thread(target=afk_task_loop, args=(api_key, interval, stop_event, task_id, ctx.author.id), daemon=True).start()
    
    await ctx.send(f"✅ **Task #{task_id}** | afk | Interval: {interval}s | Credits: {credits}")    
# ============= LỆNH DAME FACEBOOK =============
@bot.command()
async def damefb(ctx, cookie: str = None, link: str = None, dame_type: str = "3"):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not cookie or not link:
        await ctx.send("❌ Cú pháp: `damefb <cookie> <link> [loại]`")
        await ctx.send("📌 VD: `damefb c_user=123;xs=456 https://facebook.com/username 3`")
        await ctx.send("📌 Loại: 1 - Chuyên Nghiệp, 2 - Clone, 3 - Profile Bình Thường")
        return
    type_name = ""
    if dame_type == "1":
        type_name = "Chuyên Nghiệp"
    elif dame_type == "2":
        type_name = "Clone"
    else:
        dame_type = "3"
        type_name = "Profile Bình Thường"
    await ctx.send(f"🎯 **Đang khởi tạo dame tài khoản...**")
    await ctx.send(f"📋 Loại: `{type_name}`")
    await ctx.send(f"🔗 Link: `{link}`")
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "damefb", link, stop_event)
    dame_tasks[task_id] = stop_event
    threading.Thread(target=dame_task, args=(cookie, link, dame_type, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | Đang dame tài khoản | Loại: {type_name}")

# ============= LỆNH DAMEINFO =============
@bot.command()
async def dameinfo(ctx, link: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not link:
        await ctx.send("❌ Cú pháp: `dameinfo <link>`")
        return
    await ctx.send("🔍 **Đang lấy thông tin tài khoản...**")
    await ctx.send("📌 Vui lòng nhập cookie Facebook của bạn để lấy thông tin:")
    def check(m):
        return m.author == ctx.author and m.channel == ctx.channel
    try:
        cookie_msg = await bot.wait_for("message", check=check, timeout=60)
        cookie = cookie_msg.content.strip()
        manager = FacebookDameManager(cookie)
        uid = manager.get_uid_from_link(link)
        if not uid:
            await ctx.send("❌ Không lấy được UID từ link!")
            return
        user_info = manager.get_user_info(uid)
        if "error" in user_info:
            await ctx.send(f"❌ {user_info['error']}")
            return
        status = manager.check_uid_status(uid)
        status_text = "✅ Đang hoạt động" if status == "live" else ("❌ Đã bị khóa" if status == "die" else "⚠️ Không xác định")
        embed = discord.Embed(title="📋 THÔNG TIN TÀI KHOẢN", color=discord.Color.blue())
        embed.add_field(name="👤 Tên", value=user_info.get('name', 'N/A'), inline=True)
        embed.add_field(name="🆔 UID", value=user_info.get('id', 'N/A'), inline=True)
        embed.add_field(name="📊 Trạng thái", value=status_text, inline=True)
        embed.add_field(name="🔗 Link", value=user_info.get('url', link), inline=False)
        await ctx.send(embed=embed)
    except TimeoutError:
        await ctx.send("❌ Hết thời gian chờ!")
    except Exception as e:
        await ctx.send(f"❌ Lỗi: {e}")

# ============= LỆNH BOTCHAT =============
@bot.command()
async def botchat(ctx, cookie: str = None, admin_uid: str = None, prefix: str = None):
    """Khởi động bot chat Facebook Messenger"""
    global chat_bot_thread, chat_bot_running
    
    if ctx.author.id != ADMIN_ID:
        await ctx.send("❌ Chỉ admin gốc mới dùng được lệnh này!")
        return
    
    if not cookie:
        await ctx.send("❌ Cú pháp: `botchat <cookie> [admin_uid] [prefix]`\nVD: `botchat c_user=123;xs=456 61566421582707 /`")
        return
    
    if chat_bot_running:
        await ctx.send("⚠️ Bot chat đang chạy! Dùng `stopchat` để dừng.")
        return
    
    if not admin_uid:
        admin_uid = str(ADMIN_ID)
    
    if not prefix:
        prefix = "/"
    
    await ctx.send(f"🤖 Đang khởi động bot chat...\n📌 Cookie: `{cookie[:50]}...`\n👑 Admin: `{admin_uid}`\n⚙️ Prefix: `{prefix}`")
    
    chat_bot_running = True
    
    def run_bot_thread():
        import botchat
        try:
            # Gọi trực tiếp run_bot trong botchat
            botchat.run_bot(cookie, admin_uid, None, prefix)
        except Exception as e:
            print(f"Lỗi bot chat: {e}")
        finally:
            global chat_bot_running
            chat_bot_running = False
    
    chat_bot_thread = threading.Thread(target=run_bot_thread, daemon=True)
    chat_bot_thread.start()
    
    await ctx.send(f"✅ Bot chat đã khởi động! Dùng `stopchat` để dừng.")
@bot.command()
async def stopchat(ctx):
    global chat_bot_running
    if ctx.author.id != ADMIN_ID:
        await ctx.send("❌ Chỉ admin mới dùng được lệnh này!")
        return
    if not chat_bot_running:
        await ctx.send("⚠️ Bot chat chưa chạy!")
        return
    chat_bot_running = False
    await ctx.send(f"✅ **Đã dừng bot chat!**")

# ============= LỆNH TREONGL ==========
@bot.command()
async def treongl(ctx, targets: str = None, filename: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not targets or not filename or not delay:
        await ctx.send("❌ Cú pháp: `treongl <target1,target2,...> <file> <delay>`")
        await ctx.send("📌 VD: `treongl xuanthang noidung.txt 3`")
        return
    target_list = [t.strip() for t in targets.split(',') if t.strip()]
    if not target_list:
        await ctx.send("❌ Không có target nào hợp lệ!")
        return
    if delay <= 0:
        await ctx.send("❌ Delay phải lớn hơn 0!")
        return
    if not filename.endswith('.txt'):
        filename += '.txt'
    user_folder = os.path.join(UPLOAD_DIR, str(ctx.author.id))
    filepath = os.path.join(user_folder, filename)
    if not os.path.exists(filepath):
        filepath = filename
        if not os.path.exists(filepath):
            await ctx.send(f"❌ Không tìm thấy file `{filename}`! Dùng `setfile` để upload.")
            return
    messages = get_first_3_lines(filepath)
    if not messages:
        await ctx.send(f"❌ File `{filename}` rỗng hoặc không đọc được!")
        return
    await ctx.send(f"📱 **Đang treo NGL**")
    await ctx.send(f"🎯 Target: {', '.join(target_list[:5])}{'...' if len(target_list) > 5 else ''}")
    await ctx.send(f"📝 Nội dung: {len(messages)} dòng (từ {filename})")
    for i, msg in enumerate(messages, 1):
        await ctx.send(f"   {i}. {msg[:50]}...")
    await ctx.send(f"⏱️ Delay: {delay}s")
    await ctx.send("💬 Dùng `stop <task_id>` để dừng")
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "treongl", ','.join(target_list[:3]), stop_event)
    threading.Thread(target=treongl_task, args=(target_list, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | Đang treo {len(target_list)} target | Delay {delay}s")

# ========== LỆNH NHAYNGL ==========
@bot.command()
async def nhayngl(ctx, targets: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not targets or not delay:
        await ctx.send("❌ Cú pháp: `nhayngl <target1,target2,...> <delay>`")
        await ctx.send("📌 VD: `nhayngl xuanthang 3`")
        await ctx.send("💡 Nội dung lấy từ file `nhay.txt`")
        return
    target_list = [t.strip() for t in targets.split(',') if t.strip()]
    if not target_list:
        await ctx.send("❌ Không có target nào hợp lệ!")
        return
    if delay <= 0:
        await ctx.send("❌ Delay phải lớn hơn 0!")
        return
    user_folder = os.path.join(UPLOAD_DIR, str(ctx.author.id))
    filepath = os.path.join(user_folder, "nhay.txt")
    if not os.path.exists(filepath):
        filepath = "nhay.txt"
    if not os.path.exists(filepath):
        await ctx.send(f"❌ Không tìm thấy file `nhay.txt`! Dùng `setfile nhay.txt` để upload nội dung.")
        return
    with open(filepath, 'r', encoding='utf-8') as f:
        messages = [l.strip() for l in f if l.strip()]
    if not messages:
        await ctx.send("❌ File nhay.txt rỗng!")
        return
    await ctx.send(f"📱 **Đang spam NGL**")
    await ctx.send(f"🎯 Target: {', '.join(target_list[:5])}{'...' if len(target_list) > 5 else ''}")
    await ctx.send(f"📝 Số tin nhắn: {len(messages)}")
    await ctx.send(f"⏱️ Delay: {delay}s")
    await ctx.send("💬 Dùng `stop <task_id>` để dừng")
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "nhayngl", ','.join(target_list[:3]), stop_event)
    threading.Thread(target=nhayngl_task, args=(target_list, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | Đang spam {len(target_list)} target | Delay {delay}s")

# ============= LỆNH SMS =============
@bot.command()
async def sms(ctx, phone: str = None, count: int = 999999):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not phone:
        await ctx.send("❌ Cú pháp: `sms <số_điện_thoại> [số_lần]`")
        await ctx.send("📌 VD: `sms 0987654321 100`")
        return
    phone = phone.strip()
    if not phone.isdigit() or len(phone) < 9:
        await ctx.send("❌ Số điện thoại không hợp lệ!")
        return
    if count < 1:
        count = 1
    await ctx.send(f"📱 **Đang spam SMS đến {phone}**")
    await ctx.send(f"🔄 Số lần: {count} | ⏳ Chạy đến khi hoàn thành hoặc dừng")
    await ctx.send("💬 Dùng `stop <task_id>` để dừng giữa chừng")
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "sms", phone, stop_event)
    threading.Thread(target=sms_spam_task, args=(phone, count, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | Đang spam `{phone}` | {count} lần")

# ============= LỆNH TREOWECHAT =============
@bot.command()
async def treowechat(ctx, access_token: str = None, agent_id: str = None, user: str = None, filename: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [access_token, agent_id, user, filename, delay]:
        await ctx.send("❌ Cú pháp: `treowechat <access_token> <agent_id> <user> <file> <delay>`")
        await ctx.send("📌 VD: `treowechat abc123... 1000002 @all noidung.txt 5`")
        return
    if not filename.endswith('.txt'):
        filename += '.txt'
    user_folder = os.path.join(UPLOAD_DIR, str(ctx.author.id))
    filepath = os.path.join(user_folder, filename)
    if not os.path.exists(filepath):
        await ctx.send(f"❌ Không tìm thấy file `{filename}`! Dùng `setfile` để upload.")
        return
    with open(filepath, 'r', encoding='utf-8') as f:
        messages = [l.strip() for l in f if l.strip()]
    if not messages:
        await ctx.send("❌ File rỗng!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "treowechat", user, stop_event)
    threading.Thread(target=treowechat_task, args=(access_token, agent_id, user, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | treowechat | Target: `{user}` | Delay: {delay}s | File: `{filename}`")
    await ctx.send(f"📝 Chế độ: **GỘP {len(messages)} dòng vào 1 tin nhắn**")

# ============= LỆNH NHAYWECHAT =============
@bot.command()
async def nhaywechat(ctx, access_token: str = None, agent_id: str = None, user: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [access_token, agent_id, user, delay]:
        await ctx.send("❌ Cú pháp: `nhaywechat <access_token> <agent_id> <user> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "nhaywechat", user, stop_event)
    threading.Thread(target=nhaywechat_task, args=(access_token, agent_id, user, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | nhaywechat | Target: `{user}` | Delay: {delay}s")

@bot.command()
async def stopwechat(ctx, task_id: int = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if task_id is None:
        await ctx.send("❌ Cú pháp: `stopwechat <task_id>`")
        return
    if ctx.author.id in active_tasks:
        for task in active_tasks[ctx.author.id][:]:
            if task["id"] == task_id and task["type"] in ["treowechat", "nhaywechat"]:
                task["stop"].set()
                active_tasks[ctx.author.id].remove(task)
                await ctx.send(f"✅ Đã dừng task #{task_id}")
                return
    await ctx.send(f"❌ Không tìm thấy task #{task_id}")

# ============= LỆNH IDBOX =============
@bot.command()
async def idbox(ctx, cookie: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not cookie:
        await ctx.send("❌ Cú pháp: `idbox <cookie>`")
        await ctx.send("📌 VD: `idbox c_user=123456789;xs=123456;...`")
        return
    await ctx.send("🔍 **Đang lấy danh sách box...** (có thể mất vài giây)")
    result = get_thread_list(cookie)
    if isinstance(result, dict) and "error" in result:
        await ctx.send(f"❌ **Lỗi:** {result['error']}")
        return
    if not result:
        await ctx.send("❌ Không tìm thấy box nào!")
        return
    embed = discord.Embed(title="📋 DANH SÁCH BOX FACEBOOK", description=f"Tổng số: **{len(result)}** box", color=discord.Color.green())
    for i, thread in enumerate(result[:20], 1):
        name = thread["thread_name"][:40]
        embed.add_field(name=f"{i}. {name}", value=f"🆔 `{thread['thread_id']}`", inline=False)
    if len(result) > 20:
        embed.set_footer(text=f"Hiển thị 20/{len(result)} box. Dùng ID để spam.")
    await ctx.send(embed=embed)
    if len(result) > 20:
        file_content = "ID BOX | TÊN BOX\n" + "-" * 50 + "\n"
        for thread in result:
            file_content += f"{thread['thread_id']} | {thread['thread_name']}\n"
        with open(f"boxlist_{ctx.author.id}.txt", 'w', encoding='utf-8') as f:
            f.write(file_content)
        with open(f"boxlist_{ctx.author.id}.txt", 'rb') as f:
            await ctx.send(f"📁 **Danh sách đầy đủ {len(result)} box:**", file=discord.File(f, filename="danhsachbox.txt"))
        os.remove(f"boxlist_{ctx.author.id}.txt")

# ============= LỆNH NGONMESANH =============
@bot.command()
async def ngonmesanh(ctx, recipient_id: str = None, cookie: str = None, image_url: str = None, filename: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [recipient_id, cookie, image_url, filename, delay]:
        await ctx.send("❌ Cú pháp: `ngonmesanh <id_box> <cookie> <url_ảnh> <file> <delay>`")
        await ctx.send("📌 VD: `ngonmesanh 123456789 c_user=123;xs=456 https://i.imgur.com/abc.jpg noidung.txt 5`")
        return
    if not filename.endswith('.txt'):
        filename += '.txt'
    user_folder = os.path.join(UPLOAD_DIR, str(ctx.author.id))
    filepath = os.path.join(user_folder, filename)
    if not os.path.exists(filepath):
        await ctx.send(f"❌ Không tìm thấy file `{filename}`! Dùng `setfile` để upload.")
        return
    with open(filepath, 'r', encoding='utf-8') as f:
        messages = [l.strip() for l in f if l.strip()]
    if not messages:
        await ctx.send("❌ File rỗng!")
        return
    if not image_url.startswith(('http://', 'https://')):
        await ctx.send("❌ URL ảnh không hợp lệ! Phải bắt đầu bằng http:// hoặc https://")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "ngonmesanh", recipient_id, stop_event)
    threading.Thread(target=ngonmesanh_task, args=(cookie, recipient_id, image_url, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | ngonmesanh | Target: `{recipient_id}` | Delay: {delay}s | File: `{filename}`")
    await ctx.send(f"🖼️ Ảnh: `{image_url}`")
    await ctx.send(f"📝 Nội dung gộp: {len(messages)} dòng vào 1 tin nhắn")

# ============= LỆNH NUOI =============
@bot.command()
async def nuoi(ctx, cookie: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [cookie, delay]:
        await ctx.send("❌ Cú pháp: `nuoi <cookie> <delay>`")
        await ctx.send("📌 VD: `nuoi c_user=123456789;xs=123456;... 30`")
        return
    IMAGE_FOLDER = "anh"
    if not os.path.exists(IMAGE_FOLDER):
        await ctx.send(f"⚠️ Thư mục ảnh `{IMAGE_FOLDER}` không tồn tại! Vui lòng cấu hình lại.")
        await ctx.send("💡 Sửa biến IMAGE_FOLDER trong code thành đường dẫn thư mục ảnh của bạn")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "nuoi", cookie[:30], stop_event)
    threading.Thread(target=nuoi_task, args=(cookie, IMAGE_FOLDER, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | nuoi | Delay: {delay}s")
    await ctx.send(f"📁 Ảnh từ: `{IMAGE_FOLDER}`")

@bot.command()
async def stopnuoi(ctx):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    stopped = []
    if ctx.author.id in active_tasks:
        for task in active_tasks[ctx.author.id][:]:
            if task["type"] == "nuoi":
                task["stop"].set()
                active_tasks[ctx.author.id].remove(task)
                stopped.append(task["id"])
    if stopped:
        await ctx.send(f"✅ Đã dừng {len(stopped)} task nuôi: {stopped}")
    else:
        await ctx.send("❌ Không có task nuôi nào đang chạy!")

# ============= LỆNH TREOGMAIL =============
@bot.command()
async def treogmail(ctx, to_email: str = None, accounts: str = None, filename: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [to_email, accounts, filename, delay]:
        await ctx.send("❌ Cú pháp: `treogmail <email_người_nhận> <email|pass/email|pass> <file> <delay>`")
        await ctx.send("📌 VD: `treogmail victim@gmail.com user1|pass1/user2|pass2 content.txt 5`")
        return
    if not filename.endswith('.txt'):
        filename += '.txt'
    user_folder = os.path.join(UPLOAD_DIR, str(ctx.author.id))
    filepath = os.path.join(user_folder, filename)
    if not os.path.exists(filepath):
        await ctx.send(f"❌ Không tìm thấy file `{filename}`! Dùng `setfile` để upload.")
        return
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read().strip()
    if not content:
        await ctx.send("❌ File rỗng!")
        return
    account_list = parse_email_accounts(accounts)
    if not account_list:
        await ctx.send("❌ Không có tài khoản nào hợp lệ! Định dạng: email|pass/email|pass")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "treogmail", to_email, stop_event)
    threading.Thread(target=treogmail_task, args=(account_list, to_email, content, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | treogmail | Target: `{to_email}` | Delay: {delay}s | {len(account_list)} accounts | File: `{filename}`")

# ============= CÁC LỆNH INSTAGRAM =============
@bot.command()
async def nhayigbox(ctx, idbox: str = None, credential: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [idbox, credential, delay]:
        await ctx.send("❌ Cú pháp: `nhayigbox <idbox> <cookie_hoặc_user:pass> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`!")
        return
    login_method, login_data = parse_ig_credential(credential)
    targets = [id.strip() for id in idbox.split(',')]
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "nhayigbox", ','.join(targets), stop_event)
    threading.Thread(target=ig_nhay_task, args=(login_method, login_data, targets, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | nhayigbox | Target: `{targets}` | Delay: {delay}s")

@bot.command()
async def nhayigrieng(ctx, username: str = None, credential: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [username, credential, delay]:
        await ctx.send("❌ Cú pháp: `nhayigrieng <username_ig> <cookie_hoặc_user:pass> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`!")
        return
    login_method, login_data = parse_ig_credential(credential)
    targets = [u.strip() for u in username.split(',')]
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "nhayigrieng", ','.join(targets), stop_event)
    threading.Thread(target=ig_nhay_task, args=(login_method, login_data, targets, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | nhayigrieng | Target: `{targets}` | Delay: {delay}s")

@bot.command()
async def npollbox(ctx, idbox: str = None, credential: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [idbox, credential, delay]:
        await ctx.send("❌ Cú pháp: `npollbox <idbox> <cookie_hoặc_user:pass> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages or len(messages) < 3:
        await ctx.send("❌ File nhay.txt cần ít nhất 3 dòng!")
        return
    login_method, login_data = parse_ig_credential(credential)
    targets = [id.strip() for id in idbox.split(',')]
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "npollbox", ','.join(targets), stop_event)
    threading.Thread(target=ig_poll_task, args=(login_method, login_data, targets, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | npollbox | Target: `{targets}` | Delay: {delay}s")

@bot.command()
async def tpollbox(ctx, idbox: str = None, credential: str = None, filename: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [idbox, credential, filename, delay]:
        await ctx.send("❌ Cú pháp: `tpollbox <idbox> <cookie_hoặc_user:pass> <file> <delay>`")
        return
    if not filename.endswith('.txt'):
        filename += '.txt'
    user_folder = os.path.join(UPLOAD_DIR, str(ctx.author.id))
    filepath = os.path.join(user_folder, filename)
    if not os.path.exists(filepath):
        await ctx.send(f"❌ Không tìm thấy file `{filename}`! Dùng `setfile` để upload.")
        return
    login_method, login_data = parse_ig_credential(credential)
    targets = [id.strip() for id in idbox.split(',')]
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "tpollbox", ','.join(targets), stop_event)
    threading.Thread(target=ig_tpoll_task, args=(login_method, login_data, targets, filepath, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | tpollbox | Target: `{targets}` | Delay: {delay}s | File: `{filename}`")

# ============= CÁC LỆNH ZALO =============
@bot.command()
async def nhayrieng(ctx, imei: str = None, cookie: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [imei, cookie, delay]:
        await ctx.send("❌ Cú pháp: `nhayrieng <imei> <cookie> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`! Dùng `setfile nhay.txt` để upload.")
        return
    try:
        cookie_dict = json.loads(cookie) if cookie.startswith('{') else dict(x.split('=') for x in cookie.split(';') if '=' in x)
        api = ZaloAPI(imei, cookie_dict)
        friends = api.fetch_friends()
        if not friends:
            await ctx.send("❌ Không tìm thấy bạn bè nào!")
            return
        msg = "📋 **DANH SÁCH BẠN BÈ**\n"
        for i, f in enumerate(friends[:30], 1):
            msg += f"{i}. {f['name']} (`{f['id']}`)\n"
        if len(friends) > 30:
            msg += f"\n... và {len(friends)-30} bạn khác"
        await ctx.send(msg)
        await ctx.send("📌 **Nhập số thứ tự bạn muốn spam (cách nhau dấu phẩy, VD: 1,3,5)**\n⏰ Bạn có 60 giây để chọn:")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        try:
            choice_msg = await bot.wait_for("message", check=check, timeout=60)
            indices = [int(x.strip())-1 for x in choice_msg.content.split(',') if x.strip().isdigit()]
            selected = [friends[i] for i in indices if 0 <= i < len(friends)]
        except:
            await ctx.send("❌ Hết thời gian hoặc lựa chọn không hợp lệ!")
            return
        if not selected:
            await ctx.send("❌ Không có bạn nào được chọn!")
            return
        use_typing = False
        for friend in selected:
            stop_event = threading.Event()
            task_id = add_task(ctx.author.id, "nhayrieng", friend['id'], stop_event)
            threading.Thread(target=zalo_send_task, args=(imei, cookie_dict, friend['id'], ThreadType.USER, messages, delay, use_typing, stop_event, task_id, ctx.author.id), daemon=True).start()
        await ctx.send(f"✅ Đã bắt đầu spam riêng cho {len(selected)} bạn bè! Delay: {delay}s")
    except Exception as e:
        await ctx.send(f"❌ Lỗi: {e}")

@bot.command()
async def nhaybox(ctx, imei: str = None, cookie: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [imei, cookie, delay]:
        await ctx.send("❌ Cú pháp: `nhaybox <imei> <cookie> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`! Dùng `setfile nhay.txt` để upload.")
        return
    try:
        cookie_dict = json.loads(cookie) if cookie.startswith('{') else dict(x.split('=') for x in cookie.split(';') if '=' in x)
        api = ZaloAPI(imei, cookie_dict)
        groups = api.fetch_groups()
        if not groups:
            await ctx.send("❌ Không tìm thấy nhóm nào!")
            return
        msg = "📋 **DANH SÁCH NHÓM**\n"
        for i, g in enumerate(groups, 1):
            msg += f"{i}. {g['name']} (`{g['id']}`) - {g['members']} thành viên\n"
        await ctx.send(msg)
        await ctx.send("📌 **Nhập số thứ tự nhóm muốn spam (cách nhau dấu phẩy, VD: 1,3,5)**\n⏰ Bạn có 60 giây để chọn:")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        try:
            choice_msg = await bot.wait_for("message", check=check, timeout=60)
            indices = [int(x.strip())-1 for x in choice_msg.content.split(',') if x.strip().isdigit()]
            selected = [groups[i] for i in indices if 0 <= i < len(groups)]
        except:
            await ctx.send("❌ Hết thời gian hoặc lựa chọn không hợp lệ!")
            return
        if not selected:
            await ctx.send("❌ Không có nhóm nào được chọn!")
            return
        use_typing = False
        for group in selected:
            stop_event = threading.Event()
            task_id = add_task(ctx.author.id, "nhaybox", group['id'], stop_event)
            threading.Thread(target=zalo_send_task, args=(imei, cookie_dict, group['id'], ThreadType.GROUP, messages, delay, use_typing, stop_event, task_id, ctx.author.id), daemon=True).start()
        await ctx.send(f"✅ Đã bắt đầu spam cho {len(selected)} nhóm! Delay: {delay}s")
    except Exception as e:
        await ctx.send(f"❌ Lỗi: {e}")

@bot.command()
async def nhaytagbox(ctx, imei: str = None, cookie: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [imei, cookie, delay]:
        await ctx.send("❌ Cú pháp: `nhaytagbox <imei> <cookie> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`! Dùng `setfile nhay.txt` để upload.")
        return
    try:
        cookie_dict = json.loads(cookie) if cookie.startswith('{') else dict(x.split('=') for x in cookie.split(';') if '=' in x)
        api = ZaloAPI(imei, cookie_dict)
        groups = api.fetch_groups()
        if not groups:
            await ctx.send("❌ Không tìm thấy nhóm nào!")
            return
        msg = "📋 **DANH SÁCH NHÓM**\n"
        for i, g in enumerate(groups, 1):
            msg += f"{i}. {g['name']} (`{g['id']}`) - {g['members']} thành viên\n"
        await ctx.send(msg)
        await ctx.send("📌 **Nhập số thứ tự nhóm muốn spam (1 số duy nhất):**\n⏰ Bạn có 60 giây để chọn:")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        try:
            choice_msg = await bot.wait_for("message", check=check, timeout=60)
            idx = int(choice_msg.content.strip()) - 1
            if 0 <= idx < len(groups):
                selected_group = groups[idx]
            else:
                await ctx.send("❌ Lựa chọn không hợp lệ!")
                return
        except:
            await ctx.send("❌ Hết thời gian hoặc lựa chọn không hợp lệ!")
            return
        members = api.fetch_members(selected_group['id'])
        if not members:
            await ctx.send("❌ Không thể lấy danh sách thành viên!")
            return
        msg = f"📋 **THÀNH VIÊN NHÓM {selected_group['name']}**\n"
        for i, m in enumerate(members, 1):
            msg += f"{i}. {m['name']} (`{m['id']}`)\n"
        await ctx.send(msg)
        await ctx.send("📌 **Nhập số thứ tự thành viên muốn tag (cách nhau dấu phẩy, VD: 1,3,5)**\n⏰ Bạn có 60 giây để chọn:")
        try:
            choice_msg = await bot.wait_for("message", check=check, timeout=60)
            indices = [int(x.strip())-1 for x in choice_msg.content.split(',') if x.strip().isdigit()]
            selected_members = [members[i] for i in indices if 0 <= i < len(members)]
        except:
            await ctx.send("❌ Hết thời gian hoặc lựa chọn không hợp lệ!")
            return
        if not selected_members:
            await ctx.send("❌ Không có thành viên nào được chọn!")
            return
        mention_str = " ".join([f"<@{m['id']}>" for m in selected_members])
        tagged_messages = [f"{mention_str} {msg}" for msg in messages]
        stop_event = threading.Event()
        task_id = add_task(ctx.author.id, "nhaytagbox", selected_group['id'], stop_event)
        threading.Thread(target=zalo_send_task, args=(imei, cookie_dict, selected_group['id'], ThreadType.GROUP, tagged_messages, delay, True, stop_event, task_id, ctx.author.id), daemon=True).start()
        await ctx.send(f"✅ Đã bắt đầu spam tag cho nhóm `{selected_group['name']}` với {len(selected_members)} thành viên! Delay: {delay}s")
    except Exception as e:
        await ctx.send(f"❌ Lỗi: {e}")

@bot.command()
async def pollzalo(ctx, imei: str = None, cookie: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [imei, cookie, delay]:
        await ctx.send("❌ Cú pháp: `pollzalo <imei> <cookie> <delay>`")
        return
    questions, _, _ = read_file_lines(ctx, "nhay.txt")
    if not questions or len(questions) < 3:
        await ctx.send("❌ File nhay.txt cần ít nhất 3 dòng!")
        return
    try:
        cookie_dict = json.loads(cookie) if cookie.startswith('{') else dict(x.split('=') for x in cookie.split(';') if '=' in x)
        api = ZaloAPI(imei, cookie_dict)
        groups = api.fetch_groups()
        if not groups:
            await ctx.send("❌ Không tìm thấy nhóm nào!")
            return
        msg = "📋 **DANH SÁCH NHÓM**\n"
        for i, g in enumerate(groups, 1):
            msg += f"{i}. {g['name']} (`{g['id']}`)\n"
        await ctx.send(msg)
        await ctx.send("📌 **Nhập số thứ tự nhóm muốn spam poll:**")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        try:
            choice_msg = await bot.wait_for("message", check=check, timeout=60)
            indices = [int(x.strip())-1 for x in choice_msg.content.split(',') if x.strip().isdigit()]
            selected = [groups[i] for i in indices if 0 <= i < len(groups)]
        except:
            await ctx.send("❌ Hết thời gian!")
            return
        if not selected:
            await ctx.send("❌ Không có nhóm nào được chọn!")
            return
        for group in selected:
            stop_event = threading.Event()
            task_id = add_task(ctx.author.id, "pollzalo", group['id'], stop_event)
            threading.Thread(target=zalo_poll_task, args=(imei, cookie_dict, group['id'], ThreadType.GROUP, questions, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
        await ctx.send(f"✅ Đã bắt đầu spam poll cho {len(selected)} nhóm! Delay: {delay}s")
    except Exception as e:
        await ctx.send(f"❌ Lỗi: {e}")

@bot.command()
async def nameboxzl(ctx, imei: str = None, cookie: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [imei, cookie, delay]:
        await ctx.send("❌ Cú pháp: `nameboxzl <imei> <cookie> <delay>`")
        return
    names, _, _ = read_file_lines(ctx, "nhay.txt")
    if not names:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`!")
        return
    try:
        cookie_dict = json.loads(cookie) if cookie.startswith('{') else dict(x.split('=') for x in cookie.split(';') if '=' in x)
        api = ZaloAPI(imei, cookie_dict)
        groups = api.fetch_groups()
        if not groups:
            await ctx.send("❌ Không tìm thấy nhóm nào!")
            return
        msg = "📋 **DANH SÁCH NHÓM**\n"
        for i, g in enumerate(groups, 1):
            msg += f"{i}. {g['name']} (`{g['id']}`)\n"
        await ctx.send(msg)
        await ctx.send("📌 **Nhập số thứ tự nhóm muốn đổi tên:**")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        try:
            choice_msg = await bot.wait_for("message", check=check, timeout=60)
            indices = [int(x.strip())-1 for x in choice_msg.content.split(',') if x.strip().isdigit()]
            selected = [groups[i] for i in indices if 0 <= i < len(groups)]
        except:
            await ctx.send("❌ Hết thời gian!")
            return
        if not selected:
            await ctx.send("❌ Không có nhóm nào được chọn!")
            return
        for group in selected:
            stop_event = threading.Event()
            task_id = add_task(ctx.author.id, "nameboxzl", group['id'], stop_event)
            threading.Thread(target=zalo_namebox_task, args=(imei, cookie_dict, group['id'], names, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
        await ctx.send(f"✅ Đã bắt đầu đổi tên cho {len(selected)} nhóm! Delay: {delay}s")
    except Exception as e:
        await ctx.send(f"❌ Lỗi: {e}")

@bot.command()
async def joinzalo(ctx, imei: str = None, cookie: str = None, link: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [imei, cookie, link]:
        await ctx.send("❌ Cú pháp: `joinzalo <imei> <cookie> <link_nhom>`\nVD: `joinzalo 123456789 {...} https://zalo.me/g/abc...`")
        return
    try:
        cookie_dict = json.loads(cookie) if cookie.startswith('{') else dict(x.split('=') for x in cookie.split(';') if '=' in x)
        stop_event = threading.Event()
        task_id = add_task(ctx.author.id, "joinzalo", link, stop_event)
        threading.Thread(target=zalo_join_task, args=(imei, cookie_dict, link, stop_event, task_id, ctx.author.id), daemon=True).start()
        await ctx.send(f"✅ **Task #{task_id}** | joinzalo | Đang tham gia nhóm: `{link}`")
    except Exception as e:
        await ctx.send(f"❌ Lỗi: {e}")

@bot.command()
async def callzalo(ctx, imei: str = None, cookie: str = None, repeat_count: int = 5):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [imei, cookie]:
        await ctx.send("❌ Cú pháp: `callzalo <imei> <cookie> [số_lần_gọi]`\nMặc định số lần gọi là 5")
        return
    try:
        cookie_dict = json.loads(cookie) if cookie.startswith('{') else dict(x.split('=') for x in cookie.split(';') if '=' in x)
        api = ZaloAPI(imei, cookie_dict)
        friends = api.fetch_friends()
        if not friends:
            await ctx.send("❌ Không tìm thấy bạn bè nào!")
            return
        msg = "📋 **DANH SÁCH BẠN BÈ**\n"
        for i, f in enumerate(friends[:30], 1):
            msg += f"{i}. {f['name']} (`{f['id']}`)\n"
        await ctx.send(msg)
        await ctx.send("📌 **Nhập số thứ tự người cần spam call:**")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        try:
            choice_msg = await bot.wait_for("message", check=check, timeout=60)
            idx = int(choice_msg.content.strip()) - 1
            if 0 <= idx < len(friends):
                selected = friends[idx]
            else:
                await ctx.send("❌ Lựa chọn không hợp lệ!")
                return
        except:
            await ctx.send("❌ Hết thời gian!")
            return
        stop_event = threading.Event()
        task_id = add_task(ctx.author.id, "callzalo", selected['id'], stop_event)
        threading.Thread(target=zalo_call_task, args=(imei, cookie_dict, selected['id'], ThreadType.USER, repeat_count, stop_event, task_id, ctx.author.id), daemon=True).start()
        await ctx.send(f"✅ **Task #{task_id}** | callzalo | Đang gọi cho `{selected['name']}` | {repeat_count} lần")
    except Exception as e:
        await ctx.send(f"❌ Lỗi: {e}")

@bot.command()
async def stickerzalo(ctx, imei: str = None, cookie: str = None, sticker_count: int = 10, delay: float = 2):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [imei, cookie]:
        await ctx.send("❌ Cú pháp: `stickerzalo <imei> <cookie> [số_lượng] [delay]`\nMặc định: 10 sticker, delay 2s")
        return
    try:
        cookie_dict = json.loads(cookie) if cookie.startswith('{') else dict(x.split('=') for x in cookie.split(';') if '=' in x)
        api = ZaloAPI(imei, cookie_dict)
        groups = api.fetch_groups()
        if not groups:
            await ctx.send("❌ Không tìm thấy nhóm nào!")
            return
        msg = "📋 **DANH SÁCH NHÓM**\n"
        for i, g in enumerate(groups, 1):
            msg += f"{i}. {g['name']} (`{g['id']}`)\n"
        await ctx.send(msg)
        await ctx.send("📌 **Nhập số thứ tự nhóm muốn spam sticker:**")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        try:
            choice_msg = await bot.wait_for("message", check=check, timeout=60)
            indices = [int(x.strip())-1 for x in choice_msg.content.split(',') if x.strip().isdigit()]
            selected = [groups[i] for i in indices if 0 <= i < len(groups)]
        except:
            await ctx.send("❌ Hết thời gian!")
            return
        if not selected:
            await ctx.send("❌ Không có nhóm nào được chọn!")
            return
        for group in selected:
            stop_event = threading.Event()
            task_id = add_task(ctx.author.id, "stickerzalo", group['id'], stop_event)
            threading.Thread(target=zalo_sticker_task, args=(imei, cookie_dict, group['id'], ThreadType.GROUP, sticker_count, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
        await ctx.send(f"✅ Đã bắt đầu spam sticker cho {len(selected)} nhóm! Số lượng: {sticker_count}, Delay: {delay}s")
    except Exception as e:
        await ctx.send(f"❌ Lỗi: {e}")

# ============= LỆNH COIN BOT HOSTING ===============
@bot.command()
async def coin(ctx, auth_token: str = None, apikey: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not auth_token:
        await ctx.send("❌ Cú pháp: `coin <auth_token> [yescaptcha_apikey]`\nVD: `coin eyJhbGciOiJIUzI1NiIs...`\nVD có API: `coin eyJhbGciOiJIUzI1NiIs... your_apikey`")
        return
    bot_hosting = BotHosting(auth_token)
    name, coins = bot_hosting.get_info()
    if not name:
        await ctx.send("❌ Auth Token không hợp lệ! Vui lòng kiểm tra lại.")
        return
    if ctx.author.id in coin_tasks:
        await ctx.send(f"⚠️ Bạn đã có task coin đang chạy! Dùng `{PREFIX}stopcoin` để dừng lại.")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "coin", "bot-hosting.net", stop_event)
    coin_tasks[ctx.author.id] = {"stop": stop_event, "token": auth_token, "apikey": apikey, "task_id": task_id, "start": time.time()}
    threading.Thread(target=coin_task_loop, args=(auth_token, apikey, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | coin | Tài khoản: `{name}` | Xu hiện tại: `{coins}`\n🔄 Bot sẽ tự động nhận xu mỗi khi có thể!")

@bot.command()
async def tabcoin(ctx):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not coin_tasks:
        await ctx.send("📭 Không có task coin nào đang chạy!")
        return
    embed = discord.Embed(title="💰 DANH SÁCH TASK COIN", color=discord.Color.gold())
    for uid, task in coin_tasks.items():
        try:
            user = await bot.fetch_user(uid)
            username = user.name
        except:
            username = f"User_{uid}"
        runtime_coin = runtime(task.get("start", time.time()))
        embed.add_field(name=f"🔹 Task #{task['task_id']} - {username}", value=f"🎯 Target: `bot-hosting.net`\n⏰ Thời gian: {runtime_coin}\n🆔 User ID: `{uid}`", inline=False)
    await ctx.send(embed=embed)

@bot.command()
async def stopcoin(ctx, target: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if target is None:
        if ctx.author.id not in coin_tasks:
            await ctx.send("❌ Bạn không có task coin nào đang chạy!")
            return
        coin_tasks[ctx.author.id]["stop"].set()
        task_id = coin_tasks[ctx.author.id]["task_id"]
        del coin_tasks[ctx.author.id]
        if ctx.author.id in active_tasks:
            for task in active_tasks[ctx.author.id][:]:
                if task["id"] == task_id:
                    active_tasks[ctx.author.id].remove(task)
                    break
        await ctx.send(f"✅ Đã dừng task coin #{task_id} của bạn!")
        return
    if target.lower() == 'all':
        if ctx.author.id != ADMIN_ID:
            await ctx.send("❌ Chỉ admin gốc mới có thể dừng tất cả task coin!")
            return
        stopped = []
        for uid, task in list(coin_tasks.items()):
            task["stop"].set()
            stopped.append(f"#{task['task_id']} (User {uid})")
            if uid in active_tasks:
                for t in active_tasks[uid][:]:
                    if t["id"] == task["task_id"]:
                        active_tasks[uid].remove(t)
                        break
        coin_tasks.clear()
        await ctx.send(f"✅ Đã dừng {len(stopped)} task coin: {', '.join(stopped)}")
        return
    if target.isdigit():
        user_id = int(target)
        if user_id in coin_tasks:
            if ctx.author.id != ADMIN_ID and ctx.author.id != user_id:
                await ctx.send("❌ Bạn không có quyền dừng task coin của người khác!")
                return
            coin_tasks[user_id]["stop"].set()
            task_id = coin_tasks[user_id]["task_id"]
            del coin_tasks[user_id]
            if user_id in active_tasks:
                for task in active_tasks[user_id][:]:
                    if task["id"] == task_id:
                        active_tasks[user_id].remove(task)
                        break
            await ctx.send(f"✅ Đã dừng task coin #{task_id} của user `{user_id}`!")
            return
        for uid, task in list(coin_tasks.items()):
            if task["task_id"] == int(target):
                if ctx.author.id != ADMIN_ID and ctx.author.id != uid:
                    await ctx.send("❌ Bạn không có quyền dừng task coin này!")
                    return
                task["stop"].set()
                task_id = task["task_id"]
                del coin_tasks[uid]
                if uid in active_tasks:
                    for t in active_tasks[uid][:]:
                        if t["id"] == task_id:
                            active_tasks[uid].remove(t)
                            break
                await ctx.send(f"✅ Đã dừng task coin #{task_id}!")
                return
        await ctx.send(f"❌ Không tìm thấy task coin nào cho `{target}`!")
        return
    await ctx.send("❌ Cú pháp:\n`stopcoin` - Dừng task coin của bạn\n`stopcoin all` - Dừng tất cả (admin gốc)\n`stopcoin <user_id>` - Dừng task coin của user\n`stopcoin <task_id>` - Dừng task theo ID")

@bot.command()
async def coininfo(ctx, auth_token: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not auth_token:
        await ctx.send("❌ Cú pháp: `coininfo <auth_token>`")
        return
    bot_hosting = BotHosting(auth_token)
    name, coins = bot_hosting.get_info()
    if not name:
        await ctx.send("❌ Auth Token không hợp lệ!")
        return
    claimable, need_captcha, msg = bot_hosting.check_status()
    embed = discord.Embed(title="📊 THÔNG TIN BOT-HOSTING", color=discord.Color.green())
    embed.add_field(name="👤 Tên", value=name, inline=True)
    embed.add_field(name="🪙 Xu", value=f"{coins:,}", inline=True)
    embed.add_field(name="📌 Trạng thái", value="✅ Có thể claim" if claimable else f"⏳ {msg}", inline=False)
    embed.add_field(name="🔐 Captcha", value="🔴 Cần captcha" if need_captcha else "🟢 Không cần", inline=True)
    await ctx.send(embed=embed)

# ============= CÁC LỆNH CŨ GIỮ NGUYÊN =============
@bot.command()
async def addadmin(ctx, member: discord.Member = None):
    if ctx.author.id != ADMIN_ID:
        await ctx.send("❌ Chỉ admin gốc mới có quyền!")
        return
    if not member:
        await ctx.send("❌ Cú pháp: `addadmin @user`")
        return
    if member.id == ADMIN_ID:
        await ctx.send("❌ Đây là admin gốc!")
        return
    if member.id in ADMIN_IDS:
        await ctx.send(f"❌ {member.mention} đã là admin!")
        return
    ADMIN_IDS.add(member.id)
    save_admin_ids()
    await ctx.send(f"✅ Đã thêm {member.mention} vào danh sách admin!")

@bot.command()
async def deladmin(ctx, member: discord.Member = None):
    if ctx.author.id != ADMIN_ID:
        await ctx.send("❌ Chỉ admin gốc mới có quyền!")
        return
    if not member:
        await ctx.send("❌ Cú pháp: `deladmin @user`")
        return
    if member.id == ADMIN_ID:
        await ctx.send("❌ Không thể xóa admin gốc!")
        return
    if member.id not in ADMIN_IDS:
        await ctx.send(f"❌ {member.mention} không phải là admin!")
        return
    ADMIN_IDS.remove(member.id)
    save_admin_ids()
    await ctx.send(f"✅ Đã xóa {member.mention} khỏi danh sách admin!")

@bot.command()
async def listadmin(ctx):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    admin_list = []
    try:
        user = await bot.fetch_user(ADMIN_ID)
        admin_list.append(f"👑 **{user.name}** (Admin gốc)")
    except:
        admin_list.append(f"👑 **{ADMIN_ID}** (Admin gốc)")
    for admin_id in ADMIN_IDS:
        try:
            user = await bot.fetch_user(admin_id)
            admin_list.append(f"🔹 {user.name}")
        except:
            admin_list.append(f"🔹 {admin_id}")
    msg = "**📋 DANH SÁCH ADMIN:**\n" + "\n".join(admin_list)
    await ctx.send(msg)

# ============= LỆNH SETFILE =============
@bot.command()
async def setfile(ctx, filename: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not filename:
        await ctx.send("❌ Cú pháp: `setfile <tên_file>`\nVD: `setfile data.txt`")
        return
    if not filename.endswith('.txt'):
        filename += '.txt'
    await ctx.send(f"📤 Hãy upload file `{filename}` lên Discord:")
    def check(m):
        return m.author == ctx.author and m.channel == ctx.channel and m.attachments
    try:
        msg = await bot.wait_for("message", check=check, timeout=60)
        attachment = msg.attachments[0]
        if not attachment.filename.endswith('.txt'):
            await ctx.send("❌ Chỉ chấp nhận file .txt!")
            return
        content = await attachment.read()
        text_content = content.decode('utf-8')
        lines = [l.strip() for l in text_content.split('\n') if l.strip()]
        user_folder = os.path.join(UPLOAD_DIR, str(ctx.author.id))
        os.makedirs(user_folder, exist_ok=True)
        filepath = os.path.join(user_folder, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(text_content)
        if ctx.author.id not in user_files:
            user_files[ctx.author.id] = []
        if filename not in user_files[ctx.author.id]:
            user_files[ctx.author.id].append(filename)
        await ctx.send(f"✅ Đã lưu file `{filename}` với {len(lines)} dòng!")
    except TimeoutError:
        await ctx.send("❌ Hết thời gian chờ file!")

@bot.command()
async def listfile(ctx):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    user_folder = os.path.join(UPLOAD_DIR, str(ctx.author.id))
    if not os.path.exists(user_folder):
        await ctx.send("📁 Bạn chưa upload file nào! Dùng `setfile` để upload.")
        return
    files = [f for f in os.listdir(user_folder) if f.endswith('.txt')]
    if not files:
        await ctx.send("📁 Bạn chưa có file nào!")
        return
    embed = discord.Embed(title=f"📁 FILE CỦA {ctx.author.name}", color=0x3498db)
    for f in files:
        fpath = os.path.join(user_folder, f)
        with open(fpath, 'r', encoding='utf-8') as file:
            line_count = len([l for l in file if l.strip()])
        size = os.path.getsize(fpath)
        embed.add_field(name=f"📄 {f}", value=f"Dòng: {line_count} | Size: {size} bytes", inline=False)
    await ctx.send(embed=embed)

# ============= CÁC LỆNH MESSENGER CŨ =============
@bot.command()
async def ngonmes(ctx, idbox: str = None, cookie: str = None, filename: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [idbox, cookie, filename, delay]:
        await ctx.send("❌ Cú pháp: `ngonmes <idbox> <cookie> <file> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, filename)
    if not messages:
        await ctx.send(f"❌ Không tìm thấy file `{filename}`!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "ngonmes", idbox, stop_event)
    threading.Thread(target=ngonmes_task, args=(cookie, idbox, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | ngonmes | Target: `{idbox}` | Delay: {delay}s | File: `{filename}`")

@bot.command()
async def nhaymes(ctx, idbox: str = None, cookie: str = None, delay: float = None, typing_delay: float = 3):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [idbox, cookie, delay]:
        await ctx.send("❌ Cú pháp: `nhaymes <idbox> <cookie> <delay> [typing_delay]`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages:
        await ctx.send(f"❌ Không tìm thấy file `nhay.txt`! Dùng `setfile nhay.txt` để upload.")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "nhaymes", idbox, stop_event)
    threading.Thread(target=nhaymes_task, args=(cookie, idbox, messages, delay, typing_delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | nhaymes | Target: `{idbox}` | Delay: {delay}s")

@bot.command()
async def npollmes(ctx, idbox: str = None, cookie: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [idbox, cookie, delay]:
        await ctx.send("❌ Cú pháp: `npollmes <idbox> <cookie> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages or len(messages) < 3:
        await ctx.send("❌ File nhay.txt cần ít nhất 3 dòng!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "npollmes", idbox, stop_event)
    threading.Thread(target=npollmes_task, args=(cookie, idbox, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | npollmes | Target: `{idbox}` | Delay: {delay}s")

@bot.command()
async def tpollmes(ctx, idbox: str = None, cookie: str = None, filename: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [idbox, cookie, filename, delay]:
        await ctx.send("❌ Cú pháp: `tpollmes <idbox> <cookie> <file> <delay>`")
        return
    filepath, is_user = get_file_path(ctx, filename)
    if not filepath:
        await ctx.send(f"❌ Không tìm thấy file `{filename}`!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "tpollmes", idbox, stop_event)
    threading.Thread(target=tpollmes_task, args=(cookie, idbox, filepath, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | tpollmes | Target: `{idbox}` | Delay: {delay}s | File: `{filename}`")

@bot.command()
async def theme(ctx, idbox: str = None, cookie: str = None, delay: float = None, theme_name: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [idbox, cookie, delay]:
        await ctx.send("❌ Cú pháp: `theme <idbox> <cookie> <delay> [tên_theme]`")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, f"theme_{theme_name if theme_name else 'random'}", idbox, stop_event)
    threading.Thread(target=theme_task, args=(cookie, idbox, delay, theme_name, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | theme | Target: `{idbox}` | Delay: {delay}s")

@bot.command()
async def namebox(ctx, idbox: str = None, cookie: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [idbox, cookie, delay]:
        await ctx.send("❌ Cú pháp: `namebox <idbox> <cookie> <delay>`")
        return
    names, _, _ = read_file_lines(ctx, "nhay.txt")
    if not names:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "namebox", idbox, stop_event)
    threading.Thread(target=namebox_task, args=(cookie, idbox, names, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | namebox | Target: `{idbox}` | Delay: {delay}s")

# ============= CÁC LỆNH TELEGRAM =============
@bot.command()
async def nhaytele(ctx, token: str = None, chat_id: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [token, chat_id, delay]:
        await ctx.send("❌ Cú pháp: `nhaytele <token_bot> <chat_id> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "nhaytele", chat_id, stop_event)
    threading.Thread(target=nhaytele_task, args=(token, chat_id, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | nhaytele | Target: `{chat_id}` | Delay: {delay}s")

@bot.command()
async def polltele(ctx, token: str = None, chat_id: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [token, chat_id, delay]:
        await ctx.send("❌ Cú pháp: `polltele <token_bot> <chat_id> <delay>`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages or len(messages) < 3:
        await ctx.send("❌ File nhay.txt cần ít nhất 3 dòng!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "polltele", chat_id, stop_event)
    threading.Thread(target=polltele_task, args=(token, chat_id, messages, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | polltele | Target: `{chat_id}` | Delay: {delay}s")

@bot.command()
async def nhaytagtele(ctx, token: str = None, chat_id: str = None, delay: float = None, *user_ids: str):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [token, chat_id, delay] or not user_ids:
        await ctx.send("❌ Cú pháp: `nhaytagtele <token_bot> <chat_id> <delay> @user1 @user2 ...`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`!")
        return
    parsed_ids = [uid.replace('@', '').strip() for uid in user_ids if uid.replace('@', '').strip().isdigit()]
    if not parsed_ids:
        await ctx.send("❌ Vui lòng cung cấp ID user hợp lệ!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "nhaytagtele", chat_id, stop_event)
    threading.Thread(target=nhaytagtele_task, args=(token, chat_id, messages, parsed_ids, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | nhaytagtele")
 
# ============= CÁC LỆNH TELEGRAM (TIẾP) =============
@bot.command()
async def treotele(ctx, token: str = None, chat_id: str = None, filename: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [token, chat_id, filename, delay]:
        await ctx.send("❌ Cú pháp: `treotele <token_bot> <chat_id> <file> <delay>`")
        return
    filepath, _ = get_file_path(ctx, filename)
    if not filepath:
        await ctx.send(f"❌ Không tìm thấy file `{filename}`!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "treotele", chat_id, stop_event)
    threading.Thread(target=treotele_task, args=(token, chat_id, filepath, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | treotele | Target: `{chat_id}` | Delay: {delay}s")

# ============= CÁC LỆNH DISCORD =============
@bot.command()
async def treodis(ctx, token: str = None, channel_id: str = None, filename: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [token, channel_id, filename, delay]:
        await ctx.send("❌ Cú pháp: `treodis <token> <channel_id> <file> <delay>`")
        return
    filepath, _ = get_file_path(ctx, filename)
    if not filepath:
        await ctx.send(f"❌ Không tìm thấy file `{filename}`!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "treodis", channel_id, stop_event)
    threading.Thread(target=treodis_safe, args=(token, channel_id, filepath, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | treodis | Channel: `{channel_id}` | Delay: {delay}s | File: `{filename}` | ✨ Có typing indicator + UA random")

@bot.command()
async def nhaydis(ctx, token: str = None, channel_id: str = None, delay: float = None, *user_ids: str):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [token, channel_id, delay]:
        await ctx.send("❌ Cú pháp: `nhaydis <token> <channel_id> <delay> [@user...]`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages:
        await ctx.send("❌ Không tìm thấy file `nhay.txt`! Dùng `setfile nhay.txt` để upload.")
        return
    mention_ids = [uid.replace('@', '').strip() for uid in user_ids if uid.replace('@', '').strip().isdigit()]
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "nhaydis", channel_id, stop_event)
    threading.Thread(target=nhaydis_safe, args=(token, channel_id, messages, delay, mention_ids, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | nhaydis | Channel: `{channel_id}` | Delay: {delay}s | Tag {len(mention_ids)} users | ✨ Có typing indicator + UA random")

@bot.command()
async def polldis(ctx, token: str = None, channel_id: str = None, delay: float = None, *user_ids: str):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [token, channel_id, delay]:
        await ctx.send("❌ Cú pháp: `polldis <token> <channel_id> <delay> [@user...]`")
        return
    messages, _, _ = read_file_lines(ctx, "nhay.txt")
    if not messages or len(messages) < 3:
        await ctx.send("❌ File `nhay.txt` cần ít nhất 3 dòng!")
        return
    mention_ids = [uid.replace('@', '').strip() for uid in user_ids if uid.replace('@', '').strip().isdigit()]
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "polldis", channel_id, stop_event)
    threading.Thread(target=polldis_safe, args=(token, channel_id, messages, delay, mention_ids, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | polldis | Channel: `{channel_id}` | Delay: {delay}s | ✨ Có typing indicator + UA random")

@bot.command()
async def voicedis(ctx, token: str = None, channel_id: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [token, channel_id, delay]:
        await ctx.send("❌ Cú pháp: `voicedis <token> <channel_id> <delay>`")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "voicedis", channel_id, stop_event)
    threading.Thread(target=voicedis_task, args=(token, channel_id, delay, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | voicedis | Target: `{channel_id}` | Delay: {delay}s")

# ============= LỆNH QUẢN LÝ TASK =============
@bot.command()
async def tab(ctx):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    tasks = active_tasks.get(ctx.author.id, [])
    if not tasks:
        await ctx.send("📭 Không có task nào đang chạy!")
        return
    embed = discord.Embed(title="📊 DANH SÁCH TASK", description=f"Tổng: {len(tasks)} task", color=0x3498db)
    for task in tasks:
        embed.add_field(name=f"🔹 Task #{task['id']} - {task['type']}", value=f"🎯 Target: `{task['target']}`\n⏰ Thời gian: {runtime(task['start'])}", inline=False)
    await ctx.send(embed=embed)

@bot.command()
async def stop(ctx, target: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not target:
        await ctx.send("❌ Cú pháp: `stop all` | `stop <task_id>` | `stop <target>`")
        return
    tasks = active_tasks.get(ctx.author.id, [])
    stopped = []
    if target.lower() == 'all':
        for task in tasks:
            task["stop"].set()
            stopped.append(task["id"])
        active_tasks[ctx.author.id] = []
        await ctx.send(f"✅ Đã dừng {len(stopped)} task: {stopped}")
        return
    if target.isdigit():
        task_id = int(target)
        for task in tasks[:]:
            if task["id"] == task_id:
                task["stop"].set()
                tasks.remove(task)
                stopped.append(task_id)
                await ctx.send(f"✅ Đã dừng task #{task_id}")
                return
        await ctx.send(f"❌ Không tìm thấy task #{task_id}")
        return
    for task in tasks[:]:
        if task["target"] == target:
            task["stop"].set()
            tasks.remove(task)
            stopped.append(task["id"])
    if stopped:
        await ctx.send(f"✅ Đã dừng {len(stopped)} task cho target `{target}`: {stopped}")
    else:
        await ctx.send(f"❌ Không tìm thấy task nào cho target `{target}`")

# ============= LỆNH TREOTOP =============
@bot.command()
async def treotop(ctx, post_link: str = None, cookie: str = None, tag_uid: str = None, filename: str = None, delay: float = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if None in [post_link, cookie, filename, delay]:
        await ctx.send("❌ Cú pháp: `treotop <link_bài_viết> <cookie> <uid_người_tag> <file> <delay>`")
        await ctx.send("📌 VD: `treotop https://facebook.com/groups/123/permalink/456/ abcdef... 1000123456 content.txt 5`")
        await ctx.send("💡 Nếu không muốn tag, nhập uid_tag = 0")
        return
    if tag_uid == "0" or tag_uid == 0:
        tag_uid = None
    if not filename.endswith('.txt'):
        filename += '.txt'
    user_folder = os.path.join(UPLOAD_DIR, str(ctx.author.id))
    filepath = os.path.join(user_folder, filename)
    if not os.path.exists(filepath):
        await ctx.send(f"❌ Không tìm thấy file `{filename}`! Dùng `setfile` để upload.")
        return
    with open(filepath, 'r', encoding='utf-8') as f:
        messages = [l.strip() for l in f if l.strip()]
    if not messages:
        await ctx.send("❌ File rỗng!")
        return
    stop_event = threading.Event()
    task_id = add_task(ctx.author.id, "treotop", post_link[:50], stop_event)
    threading.Thread(target=treotop_task, args=(cookie, post_link, messages, delay, tag_uid, stop_event, task_id, ctx.author.id), daemon=True).start()
    await ctx.send(f"✅ **Task #{task_id}** | treotop | Bài viết: `{post_link[:50]}...` | Delay: {delay}s | File: `{filename}` | Tag: {'CÓ' if tag_uid else 'KHÔNG'}")

# ============= LỆNH THÔNG BÁO TẤT CẢ SERVER =============
@bot.command()
async def thongbao(ctx, *, content: str = None):
    if ctx.author.id != ADMIN_ID:
        await ctx.send("❌ Chỉ admin gốc mới có quyền sử dụng lệnh này!")
        return
    if not content:
        await ctx.send("❌ Cú pháp: `thongbao <nội dung>`")
        await ctx.send("📌 VD: `thongbao Bot sẽ bảo trì lúc 20h tối nay`")
        return
    guilds = bot.guilds
    if not guilds:
        await ctx.send("📭 Bot không tham gia server nào!")
        return
    embed = discord.Embed(title="📢 THÔNG BÁO TỪ ADMIN", description=content, color=discord.Color.blue())
    embed.set_footer(text=f"Người gửi: {ctx.author.name}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
    embed.timestamp = datetime.now()
    await ctx.send(f"📢 **Đang gửi thông báo đến {len(guilds)} server...**")
    success_count = 0
    fail_count = 0
    for guild in guilds:
        try:
            for channel in guild.text_channels:
                if channel.permissions_for(guild.me).send_messages:
                    await channel.send(embed=embed)
                    success_count += 1
                    print(f"✅ Đã gửi đến {guild.name}")
                    break
            else:
                fail_count += 1
                print(f"❌ Không tìm thấy kênh phù hợp ở {guild.name}")
        except Exception as e:
            fail_count += 1
            print(f"❌ Lỗi khi gửi đến {guild.name}: {e}")
    await ctx.send(f"✅ **Đã gửi thông báo thành công đến {success_count}/{len(guilds)} server**")
    if fail_count > 0:
        await ctx.send(f"⚠️ **Thất bại: {fail_count} server** (kiểm tra quyền bot)")

# ============= LỆNH XEM DANH SÁCH SERVER =============
@bot.command()
async def listserver(ctx):
    if ctx.author.id != ADMIN_ID:
        await ctx.send("❌ Chỉ admin gốc mới có quyền sử dụng lệnh này!")
        return
    guilds = bot.guilds
    if not guilds:
        await ctx.send("📭 Bot không tham gia server nào!")
        return
    embed = discord.Embed(title="📊 DANH SÁCH SERVER", description=f"Bot đang tham gia **{len(guilds)}** server", color=discord.Color.green())
    for guild in guilds:
        embed.add_field(name=f"🔹 {guild.name}", value=f"🆔 ID: `{guild.id}`\n👥 Thành viên: {guild.member_count}", inline=False)
    await ctx.send(embed=embed)
@bot.command(name="cccd")
async def cccd_template(ctx):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    template = {
        "socccd": "123456789012",
        "name": "HỌ VÀ TÊN",
        "birthday": "xx/xx/xxxx",
        "sex": "Nam",
        "quequan": "XÃ, HUYỆN, TỈNH",
        "thuongtru": "XÃ, HUYỆN, TỈNH",
        "xomlang": "Xóm 1",
        "ngaycap": "xx/xx/xxxx",
        "anhthe": "link_anh"
    }
    msg = f"📌 Vui lòng reply tin nhắn này và điền thông tin theo mẫu JSON:\n```json\n{json.dumps(template, indent=2, ensure_ascii=False)}\n```"
    sent = await ctx.send(msg)
    last_template[ctx.channel.id] = sent.id

@bot.command(name="cccd_gen")
async def cccd_generate(ctx, *, json_str: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not json_str:
        await ctx.send("⚠️ Vui lòng gửi JSON sau lệnh !cccd_gen")
        return
    try:
        data = json.loads(json_str)
    except:
        await ctx.send("❌ JSON không hợp lệ!")
        return
    
    await ctx.send("⏳ Đang fake CCCD, vui lòng đợi...")
    
    port = get_next_port()
    proc = subprocess.Popen(["php", "-S", f"127.0.0.1:{port}", "-t", PHP_DIR],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    time.sleep(2)
    api_url = f"http://127.0.0.1:{port}/cccd.php"
    try:
        resp = requests.get(api_url, params=data, timeout=60)
        result = resp.json()
        if result.get("status") != "success":
            await ctx.send("⚠️ API trả về thất bại!")
            return
        info = result.get("info", {})
        front_url = result.get("front")
        back_url = result.get("back")
        caption = (f"🆔 Số CCCD: {info.get('socccd','')}\n👤 Họ tên: {info.get('name','')}\n"
                   f"🎂 Ngày sinh: {info.get('birthday','')}\n🚻 Giới tính: {info.get('sex','')}\n"
                   f"🏠 Thường trú: {info.get('thuongtru','')}\n🏘️ Quê quán: {info.get('quequan','')}\n"
                   f"📅 Ngày cấp: {info.get('ngaycap','')}")
        
        # Import aiohttp nếu chưa có ở đầu file
        import aiohttp
        from io import BytesIO
        
        if front_url:
            async with aiohttp.ClientSession() as sess:
                async with sess.get(front_url) as r:
                    img = await r.read()
                    await ctx.send(file=discord.File(BytesIO(img), "front.png"), content=f"🪪 Mặt trước\n{caption}")
        if back_url:
            async with aiohttp.ClientSession() as sess:
                async with sess.get(back_url) as r:
                    img = await r.read()
                    await ctx.send(file=discord.File(BytesIO(img), "back.png"), content="🪪 Mặt sau")
    except Exception as e:
        await ctx.send(f"❌ Lỗi: {e}")
    finally:
        proc.send_signal(signal.SIGINT)
        proc.wait(timeout=2)
@bot.command(name="mb")
async def fake_mb(ctx, *, args: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not args:
        nen_list = "\n".join([f"{k}. {v}" for k, v in NEN_NAMES.items()])
        await ctx.send(f"📋 **Cấu trúc:** `!mb [số tiền] | [pin] | [giờ] | [mã nền]`\n📌 **VD:** `!mb 100000 | 80 | 13:30 | 1`\n🔋 Pin: 100,80,60,40,35,22,10\n🖼 **Danh sách nền:**\n```{nen_list}```")
        return
    
    parts = [p.strip() for p in args.split("|")]
    money = parts[0] if len(parts) > 0 else "0"
    pin = parts[1] if len(parts) > 1 else "100"
    time_val = parts[2] if len(parts) > 2 else datetime.datetime.now().strftime("%H:%M")
    bg_num = parts[3] if len(parts) > 3 else "1"
    
    if bg_num not in PHOI_LIST:
        await ctx.send("❌ Mã nền không hợp lệ! (1-21)")
        return
    
    await ctx.send("⏳ Đang tạo ảnh...")
    
    bg_data = await load_image(PHOI_LIST[bg_num])
    if not bg_data:
        await ctx.send("❌ Không thể tải ảnh nền! Vui lòng thử lại sau.")
        return
    
    try:
        img = Image.open(BytesIO(bg_data)).convert("RGBA")
    except Exception as e:
        await ctx.send(f"❌ Lỗi đọc ảnh: {e}")
        return
    
    draw = ImageDraw.Draw(img)
    coords = PHOI_CONFIG.get(bg_num, PHOI_CONFIG["1"])
    
    try:
        font_money = ImageFont.truetype(FONT_MONEY, 50)
        font_vnd = ImageFont.truetype(FONT_TIME, 30)
        font_time = ImageFont.truetype(FONT_TIME, 38)
    except:
        font_money = font_vnd = font_time = ImageFont.load_default()
    
    money_fmt = format_money(money)
    money_x, money_y = coords["money"]
    draw.text((money_x, money_y), money_fmt, font=font_money, fill=coords["money_color"])
    
    try:
        money_width = draw.textlength(money_fmt, font=font_money)
    except:
        money_width = len(money_fmt) * 20
    draw.text((money_x + money_width + 10, money_y + 20), "VND", font=font_vnd, fill=coords["money_color"])
    draw.text(coords["time"], time_val, font=font_time, fill=coords["time_color"])
    
    if pin in PIN_ICONS:
        pin_data = await load_image(PIN_ICONS[pin])
        if pin_data:
            try:
                pin_img = Image.open(BytesIO(pin_data)).resize((55, 30))
                img.paste(pin_img, coords["pin"], pin_img)
            except:
                pass
    
    bio = BytesIO()
    img.save(bio, "PNG")
    bio.seek(0)
    await ctx.send(file=discord.File(bio, "mb.png"), content=f"✅ Fake số dư MB thành công!\n💸 {money_fmt} VND | 🔋 {pin}% | ⏰ {time_val} | 🖼 {NEN_NAMES.get(bg_num, bg_num)}")
@bot.command(name="okx")
async def fake_okx(ctx, *, args: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not args:
        await ctx.send("📋 **Cấu trúc:** `!okx Số tiền | Đơn vị | Địa chỉ | Phí | Pin | Thời gian`\n📌 **VD:** `!okx 1.000.000 | USDT | 0x1234567890abcdef1234567890abcdef12345678 | 1 USDT | 80 | 16:02 09-04-2025`")
        return
    
    parts = [p.strip() for p in args.split("|")]
    amount = parts[0] if len(parts) > 0 else "0"
    currency = parts[1] if len(parts) > 1 else "USDT"
    address = parts[2] if len(parts) > 2 else ""
    fee = parts[3] if len(parts) > 3 else "0 USDT"
    pin = parts[4] if len(parts) > 4 else "100"
    time_str = parts[5] if len(parts) > 5 else datetime.datetime.now().strftime("%H:%M:%S %d-%m-%Y")
    
    await ctx.send("⏳ Đang tải ảnh...")
    img_data = await load_image(PHOI_OKX_URL)
    if not img_data:
        await ctx.send("❌ Không thể tải ảnh nền! Vui lòng thử lại sau.")
        return
    
    try:
        img = Image.open(BytesIO(img_data)).convert("RGBA")
    except Exception as e:
        await ctx.send(f"❌ Lỗi đọc ảnh: {e}")
        return
    
    draw = ImageDraw.Draw(img)
    
    try:
        font_b = ImageFont.truetype(FONT_BOLD, 35)
        font_r = ImageFont.truetype(FONT_REG, 20)
        font_c = ImageFont.truetype(FONT_BOLD, 28)
    except:
        font_b = font_r = font_c = ImageFont.load_default()
    
    # Thời gian góc trên
    draw.text((24, 24), time_str[:5], font=font_c, fill="white")
    
    # Icon pin góc phải
    if pin in PIN_ICONS_OKX:
        pin_data = await load_image(PIN_ICONS_OKX[pin])
        if pin_data:
            try:
                icon = Image.open(BytesIO(pin_data)).resize((48, 48))
                img.paste(icon, (img.width - 72, 24), icon)
            except:
                pass
    
    # Số tiền
    text_amount = f"-{amount} {currency}"
    try:
        bbox = draw.textbbox((0, 0), text_amount, font=font_b)
        x = (img.width - (bbox[2] - bbox[0])) // 2
    except:
        x = img.width // 2 - len(text_amount) * 10
    draw.text((x, int(img.height * 0.15)), text_amount, font=font_b, fill="white")
    
    # Địa chỉ (xuống dòng mỗi 24 ký tự)
    y = 600
    for i in range(0, len(address), 24):
        line = address[i:i+24]
        try:
            bbox = draw.textbbox((0, 0), line, font=font_r)
            draw.text((img.width - 60 - (bbox[2] - bbox[0]), y), line, font=font_r, fill="white")
        except:
            draw.text((img.width - 60 - len(line) * 10, y), line, font=font_r, fill="white")
        y += 30
    
    # Phí
    try:
        bbox = draw.textbbox((0, 0), fee, font=font_r)
        draw.text((img.width - 60 - (bbox[2] - bbox[0]), 750), fee, font=font_r, fill="white")
    except:
        draw.text((img.width - 60 - len(fee) * 10, 750), fee, font=font_r, fill="white")
    
    # Thời gian
    try:
        bbox = draw.textbbox((0, 0), time_str, font=font_r)
        draw.text((img.width - 60 - (bbox[2] - bbox[0]), 800), time_str, font=font_r, fill="white")
    except:
        draw.text((img.width - 60 - len(time_str) * 10, 800), time_str, font=font_r, fill="white")
    
    # Ref ID
    ref = generate_ref()
    try:
        bbox = draw.textbbox((0, 0), ref, font=font_r)
        draw.text((img.width - 60 - (bbox[2] - bbox[0]), 846), ref, font=font_r, fill="white")
    except:
        draw.text((img.width - 60 - len(ref) * 10, 846), ref, font=font_r, fill="white")
    
    bio = BytesIO()
    img.save(bio, "PNG")
    bio.seek(0)
    await ctx.send(file=discord.File(bio, "okx.png"), content="✅ Fake bill OKX thành công!")    
@bot.command(name="mbbank")
async def fake_mbbank(ctx, *, args: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not args:
        await ctx.send("📋 **Cấu trúc:** `!mbbank [Số tiền] | [Tên] | [STK] | [Mã NH] | [Nội dung] | [Pin] | [Giờ] | [Giao diện]`\n📌 **VD:** `!mbbank 100000 | NGUYEN VAN A | 99999999 | MB | Chuyen khoan | 80 | 18:30 | 1`\n🔋 Pin: 100,80,60,40,35,22,10\n🎨 Giao diện: 1,2,3\n🏦 Mã NH: MB, VCB, TCB, BIDV, TPBANK, OCB, AGB, SHB, VPBANK, ACB, VTB")
        return
    
    parts = [p.strip() for p in args.split("|")]
    if len(parts) < 4:
        await ctx.send("❌ Thiếu thông tin! Cần: `Số tiền | Tên | STK | Mã NH`")
        return
    
    so_tien = parts[0]
    ten = parts[1].upper()
    stk = parts[2]
    ngan_hang = parts[3].upper()
    noi_dung = parts[4] if len(parts) > 4 else "Chuyen khoan"
    pin = parts[5] if len(parts) > 5 else "100"
    thoi_gian = parts[6] if len(parts) > 6 else datetime.datetime.now().strftime("%H:%M - %d/%m/%Y")
    giao_dien = parts[7] if len(parts) > 7 else "1"
    
    if ngan_hang not in BANK_INFO:
        await ctx.send(f"❌ Mã ngân hàng `{ngan_hang}` không hợp lệ! Các mã: {', '.join(BANK_INFO.keys())}")
        return
    
    await ctx.send("⏳ Đang tạo ảnh...")
    
    phoi = PHOIS.get(giao_dien, PHOIS["1"])
    
    bg_data = await load_image(phoi["url"])
    if not bg_data:
        await ctx.send("❌ Không thể tải ảnh nền! Vui lòng thử lại sau.")
        return
    
    try:
        bg = Image.open(BytesIO(bg_data)).convert("RGBA")
    except Exception as e:
        await ctx.send(f"❌ Lỗi đọc ảnh: {e}")
        return
    
    draw = ImageDraw.Draw(bg)
    w, h = bg.size
    
    try:
        font_large = ImageFont.truetype("handlers/fonts/SF-Pro-Rounded-Bold.otf", 55)
        font_medium = ImageFont.truetype("handlers/fonts/SF-Pro-Rounded-Bold.otf", 40)
        font_small = ImageFont.truetype("handlers/fonts/SF-Pro-Rounded-Regular.otf", 35)
        font_small_nh = ImageFont.truetype("handlers/fonts/SF-Pro-Rounded-Regular.otf", 35)
        font_status = ImageFont.truetype("handlers/fonts/SF-Pro-Rounded-Bold.otf", 35)
    except:
        font_large = font_medium = font_small = font_small_nh = font_status = ImageFont.load_default()
    
    # Thời gian góc trên
    time_short = thoi_gian.split("-")[0].strip()
    draw.text((60, 30), time_short, font=font_status, fill="black")
    
    # Số tiền
    so_tien_fmt = format_money(so_tien)
    try:
        bbox = draw.textbbox((0, 0), so_tien_fmt, font=font_large)
        x = (w - (bbox[2] - bbox[0])) // 2
    except:
        x = (w - len(so_tien_fmt) * 25) // 2
    draw.text((x, 460), so_tien_fmt, font=font_large, fill=phoi["money_color"])
    
    # Thời gian đầy đủ
    try:
        bbox = draw.textbbox((0, 0), thoi_gian, font=font_small)
        x = (w - (bbox[2] - bbox[0])) // 2
    except:
        x = (w - len(thoi_gian) * 15) // 2
    draw.text((x, 550), thoi_gian, font=font_small, fill="#808080")
    
    # Tên người nhận
    try:
        bbox = draw.textbbox((0, 0), ten, font=font_medium)
        x = (w - (bbox[2] - bbox[0])) // 2
    except:
        x = (w - len(ten) * 18) // 2
    draw.text((x, 715), ten, font=font_medium, fill="#333333")
    
    # Logo + tên ngân hàng
    bank = BANK_INFO.get(ngan_hang, {})
    if bank.get("logo"):
        logo_data = await load_image(bank["logo"])
        if logo_data:
            try:
                logo = Image.open(BytesIO(logo_data)).resize((50, 50))
                try:
                    bbox = draw.textbbox((0, 0), bank.get("name", ngan_hang), font=font_small_nh)
                    text_w = bbox[2] - bbox[0]
                except:
                    text_w = len(bank.get("name", ngan_hang)) * 15
                total_w = logo.width + 15 + text_w
                start_x = (w - total_w) // 2
                bg.paste(logo, (start_x, 785), logo)
                draw.text((start_x + logo.width + 15, 785), bank.get("name", ngan_hang), font=font_small_nh, fill="#333333")
            except:
                pass
    
    # Số tài khoản
    try:
        bbox = draw.textbbox((0, 0), stk, font=font_small)
        x = (w - (bbox[2] - bbox[0])) // 2
    except:
        x = (w - len(stk) * 15) // 2
    draw.text((x, 845), stk, font=font_small, fill="#333333")
    
    # Nội dung
    try:
        bbox = draw.textbbox((0, 0), noi_dung, font=font_small)
        x = (w - (bbox[2] - bbox[0])) // 2
    except:
        x = (w - len(noi_dung) * 15) // 2
    draw.text((x, 895), noi_dung, font=font_small, fill="#333333")
    
    # Icon pin
    if pin in PIN_ICONS:
        pin_data = await load_image(PIN_ICONS[pin])
        if pin_data:
            try:
                pin_img = Image.open(BytesIO(pin_data)).resize((68, 30))
                bg.paste(pin_img, (w - 120, 30), pin_img)
            except:
                pass
    
    bio = BytesIO()
    bg.save(bio, "PNG")
    bio.seek(0)
    await ctx.send(file=discord.File(bio, "mbbank.png"), content=f"✅ Fake giao dịch thành công!\n🏦 {ngan_hang}\n💳 {so_tien} VND\n👤 {ten}\n🔢 `{stk}`")    

@bot.command(name="sun")
async def fake_sunwin(ctx, *, args: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not args or "|" not in args:
        await ctx.send("📋 **Cấu trúc:** `!sun Tên | Số tiền`\n📌 **VD:** `!sun garena123 | 5000000`\n💡 Tên tối đa 13 ký tự (sẽ tự cắt ngắn)")
        return
    
    parts = [p.strip() for p in args.split("|")]
    name = parts[0]
    if len(name) > 13:
        name = name[:13] + "..."
    amount = format_amount(parts[1])
    
    await ctx.send("⏳ Đang tạo ảnh Sunwin...")
    
    img_data = await load_image(TEMPLATE_SUNWIN_URL)
    if not img_data:
        await ctx.send("❌ Không thể tải ảnh nền! Vui lòng thử lại sau.")
        return
    
    try:
        img = Image.open(BytesIO(img_data)).convert("RGBA")
    except Exception as e:
        await ctx.send(f"❌ Lỗi đọc ảnh: {e}")
        return
    
    draw = ImageDraw.Draw(img)
    
    try:
        font_n = ImageFont.truetype(FONT_NAME_SUNWIN, 30)
        font_a = ImageFont.truetype(FONT_AMOUNT_SUNWIN, 45)
    except:
        font_n = font_a = ImageFont.load_default()
    
    # Vẽ tên (dòng đầu)
    try:
        bbox = draw.textbbox((0, 0), name, font=font_n)
        x = (img.width - (bbox[2] - bbox[0])) // 2
    except:
        x = (img.width - len(name) * 15) // 2
    draw.text((x, 65), name, font=font_n, fill="white")
    
    # Vẽ số tiền (dòng thứ hai - vị trí khác)
    # Lưu ý: tọa độ Y có thể cần chỉnh theo template thực tế
    try:
        bbox = draw.textbbox((0, 0), amount, font=font_a)
        x = (img.width - (bbox[2] - bbox[0])) // 2
    except:
        x = (img.width - len(amount) * 22) // 2
    draw.text((x, 130), amount, font=font_a, fill="white")
    
    bio = BytesIO()
    img.save(bio, "PNG")
    bio.seek(0)
    await ctx.send(file=discord.File(bio, "sunwin.png"), content=f"✅ Fake số dư Sunwin thành công!\n🧸 Tên: {name}\n💸 Số dư: {amount} VND")
@bot.command(name="vcb")
async def fake_vcb(ctx, *, args: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not args:
        await ctx.send("📋 **Cấu trúc:** `!vcb [Số tiền] | [Tên] | [STK] | [Mã NH] | [Nội dung] | [Mã GD] | [Pin] | [Thời gian]`\n📌 **VD:** `!vcb 1000000 | NGUYEN VAN A | 1055961132 | VCB | GUI TIEN | 10724168215 | 40`\n🏦 Mã NH: MB, VCB, TCB, BIDV, TPBANK, OCB, AGB, SHB, VPBANK, ACB, VTB\n🔋 Pin: 100,80,60,40,35,22,10")
        return
    
    parts = [p.strip() for p in args.split("|")]
    if len(parts) < 4:
        await ctx.send("❌ Thiếu thông tin! Cần: `Số tiền | Tên | STK | Mã NH`")
        return
    
    so_tien = parts[0]
    ten = parts[1].upper()
    stk = parts[2]
    ngan_hang = parts[3].upper()
    noi_dung = parts[4] if len(parts) > 4 else "CHUYEN TIEN"
    magd = parts[5] if len(parts) > 5 else str(random.randint(10000000000, 99999999999))
    pin = parts[6] if len(parts) > 6 else "100"
    thoi_gian = parts[7] if len(parts) > 7 else datetime.datetime.now().strftime("%H:%M %d/%m/%Y")
    
    if ngan_hang not in BANK_INFO:
        await ctx.send(f"❌ Mã ngân hàng `{ngan_hang}` không hợp lệ! Các mã: {', '.join(BANK_INFO.keys())}")
        return
    
    await ctx.send("⏳ Đang tạo ảnh Vietcombank...")
    
    bg_data = await load_image(PHOI_VCB_URL)
    if not bg_data:
        await ctx.send("❌ Không thể tải ảnh nền! Vui lòng thử lại sau.")
        return
    
    try:
        bg = Image.open(BytesIO(bg_data)).convert("RGBA")
    except Exception as e:
        await ctx.send(f"❌ Lỗi đọc ảnh: {e}")
        return
    
    draw = ImageDraw.Draw(bg)
    w, h = bg.size
    
    try:
        font_big = ImageFont.truetype(FONT_BOLD, 50)
        font_mid = ImageFont.truetype(FONT_BOLD, 23)
        font_small = ImageFont.truetype(FONT_REG, 50)
        font_gio = ImageFont.truetype(FONT_REG, 18)
        font_vnd = ImageFont.truetype(FONT_REG, 20)
    except:
        font_big = font_mid = font_small = font_gio = font_vnd = ImageFont.load_default()
    
    # Pin icon
    if pin in PIN_ICONS:
        pin_data = await load_image(PIN_ICONS[pin])
        if pin_data:
            try:
                pin_img = Image.open(BytesIO(pin_data)).resize((35, 35))
                bg.paste(pin_img, (w - 60, 25), pin_img)
            except:
                pass
    
    # Số tiền
    so_tien_fmt = format_money(so_tien)
    try:
        bbox = draw.textbbox((0, 0), so_tien_fmt, font=font_small)
        x = (w - (bbox[2] - bbox[0])) // 2
    except:
        x = (w - len(so_tien_fmt) * 25) // 2
    draw.text((x, 302), so_tien_fmt, font=font_small, fill="#0D472F")
    draw.text((x + (bbox[2] - bbox[0]) + 10, 312), "VND", font=font_vnd, fill="#555555")
    
    # Thời gian
    try:
        bbox = draw.textbbox((0, 0), thoi_gian, font=font_gio)
        x = (w - (bbox[2] - bbox[0])) // 2
    except:
        x = (w - len(thoi_gian) * 9) // 2
    draw.text((x, 370), thoi_gian, font=font_gio, fill="#555555")
    
    right_x = w - 50
    
    # Người nhận
    try:
        bbox = draw.textbbox((0, 0), ten, font=font_mid)
        draw.text((right_x - (bbox[2] - bbox[0]), 470), ten, font=font_mid, fill="black")
    except:
        draw.text((right_x - len(ten) * 12, 470), ten, font=font_mid, fill="black")
    
    # Số tài khoản
    try:
        bbox = draw.textbbox((0, 0), stk, font=font_mid)
        draw.text((right_x - (bbox[2] - bbox[0]), 550), stk, font=font_mid, fill="black")
    except:
        draw.text((right_x - len(stk) * 12, 550), stk, font=font_mid, fill="black")
    
    # Ngân hàng
    bank = BANK_INFO.get(ngan_hang, {})
    bank_name = bank.get("name", ngan_hang)
    try:
        bbox = draw.textbbox((0, 0), bank_name, font=font_mid)
        draw.text((right_x - (bbox[2] - bbox[0]), 625), bank_name, font=font_mid, fill="black")
    except:
        draw.text((right_x - len(bank_name) * 12, 625), bank_name, font=font_mid, fill="black")
    
    # Logo ngân hàng
    if bank.get("logo"):
        logo_data = await load_image(bank["logo"])
        if logo_data:
            try:
                logo = Image.open(BytesIO(logo_data)).resize((50, 50))
                bg.paste(logo, (265, 615), logo)
            except:
                pass
    
    # Nội dung
    try:
        bbox = draw.textbbox((0, 0), noi_dung, font=font_mid)
        draw.text((right_x - (bbox[2] - bbox[0]), 750), noi_dung, font=font_mid, fill="black")
    except:
        draw.text((right_x - len(noi_dung) * 12, 750), noi_dung, font=font_mid, fill="black")
    
    # Phí
    draw.text((right_x - 100, 840), "Miễn phí", font=font_mid, fill="black")
    
    # Hình thức
    hinhthuc = "Chuyển tiền nhanh Napas 247" if ngan_hang != "VCB" else "Chuyển tiền trong Vietcombank"
    try:
        bbox = draw.textbbox((0, 0), hinhthuc, font=font_mid)
        draw.text((right_x - (bbox[2] - bbox[0]), 930), hinhthuc, font=font_mid, fill="black")
    except:
        draw.text((right_x - len(hinhthuc) * 12, 930), hinhthuc, font=font_mid, fill="black")
    
    # Mã giao dịch
    try:
        bbox = draw.textbbox((0, 0), magd, font=font_mid)
        draw.text((right_x - (bbox[2] - bbox[0]), 1020), magd, font=font_mid, fill="black")
    except:
        draw.text((right_x - len(magd) * 12, 1020), magd, font=font_mid, fill="black")
    
    bio = BytesIO()
    bg.save(bio, "PNG")
    bio.seek(0)
    await ctx.send(file=discord.File(bio, "vcb.png"), content=f"✅ Fake bill Vietcombank thành công!\n👤 {ten}\n💳 {so_tien} VND")
@bot.command(name="ve")
async def fake_ticket(ctx, *, args: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not args or "|" not in args:
        await ctx.send("📋 **Cấu trúc:** `!ve Tên | Booking | Từ | Đến | Mã Từ | Mã Đến | Chuyến bay | Ngày | Giờ đi | Giờ đến | Khởi hành | Ghế | Ga | Cửa | Nhóm | Pin | Giờ trên hình`\n📌 **VD:** `!ve NGUYEN VAN A | ABC123 | Da Nang | Ha Noi | DAD | HAN | VN123 | 25/12/2025 | 08:30 | 10:00 | Sân bay Đà Nẵng | 12A | A1 | C2 | Y | 80 | 15:30`\n🔋 Pin: 100,80,60,40,35,22,10")
        return
    
    parts = [p.strip() for p in args.split("|")]
    
    # Lấy thông tin cần thiết
    ten = parts[0].upper() if len(parts) > 0 else "NGUYEN VAN A"
    from_code = parts[4].upper() if len(parts) > 4 else "DAD"
    to_code = parts[5].upper() if len(parts) > 5 else "HAN"
    pin = parts[15] if len(parts) > 15 else "100"
    thoi_gian_dt = parts[16] if len(parts) > 16 else datetime.datetime.now().strftime("%H:%M")
    
    await ctx.send("⏳ Đang tạo vé máy bay...")
    
    img_data = await load_image(TEMPLATE_TICKET_URL)
    if not img_data:
        await ctx.send("❌ Không thể tải ảnh nền! Vui lòng thử lại sau.")
        return
    
    try:
        img = Image.open(BytesIO(img_data)).convert("RGBA")
    except Exception as e:
        await ctx.send(f"❌ Lỗi đọc ảnh: {e}")
        return
    
    draw = ImageDraw.Draw(img)
    
    # Icon pin
    if pin in PIN_ICONS:
        pin_data = await load_image(PIN_ICONS[pin])
        if pin_data:
            try:
                icon = Image.open(BytesIO(pin_data)).resize((55, 30))
                img.paste(icon, (790, 50), icon)
            except:
                pass
    
    # Thời gian hiển thị trên hình
    try:
        font_h = ImageFont.truetype("handlers/fonts/SF-Pro-Rounded-Bold.otf", 38)
    except:
        font_h = ImageFont.load_default()
    draw.text((90, 50), thoi_gian_dt, font=font_h, fill="white")
    
    # Mã sân bay đi
    try:
        font_time = ImageFont.truetype("handlers/fonts/SF-Pro-Rounded-Regular.otf", 90)
    except:
        font_time = ImageFont.load_default()
    
    draw.text((30, 380), from_code, font=font_time, fill="black")
    
    # Mã sân bay đến (căn phải)
    try:
        bbox = draw.textbbox((0, 0), to_code, font=font_time)
        text_width = bbox[2] - bbox[0]
    except:
        text_width = len(to_code) * 45
    draw.text((900 - text_width, 380), to_code, font=font_time, fill="black")
    
    # Tạo QR code
    qr_content = f"{ten} {from_code}{to_code}"
    qr_img = qrcode.make(qr_content).convert("RGBA")
    qr_img = qr_img.resize((400, 400))
    img.paste(qr_img, ((img.width - 400) // 2, 1050), qr_img)
    
    bio = BytesIO()
    img.save(bio, "PNG")
    bio.seek(0)
    await ctx.send(file=discord.File(bio, "ticket.png"), content=f"🎫 **Vé máy bay cho {ten}**\n✈️ {from_code} → {to_code}\n🕐 {thoi_gian_dt}")    
@bot.command(name="vebay")
async def fake_vietnam_airline(ctx, *, args: str = None):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    if not args or "|" not in args:
        await ctx.send("📋 **Cấu trúc:** `!vebay Tên | Code | Flight | Từ (Mã) | Đến (Mã) | Ngày`\n📌 **VD:** `!vebay XUAN TIEP TRINH | QTXLL | 0224 | SGN | HAN | 29/10/2025`\n✈️ Mã sân bay: SGN (TPHCM), HAN (Hà Nội), DAD (Đà Nẵng), CXR (Nha Trang), PQC (Phú Quốc)...")
        return
    
    parts = [p.strip() for p in args.split("|")]
    name = parts[0].upper() if len(parts) > 0 else "XUAN TIEP TRINH"
    # code = parts[1] if len(parts) > 1 else "QTXLL"  # không dùng trong ảnh hiện tại
    flight = parts[2] if len(parts) > 2 else "0224"
    from_kh = parts[3].upper() if len(parts) > 3 else "SGN"
    to_kh = parts[4].upper() if len(parts) > 4 else "HAN"
    # ngay = parts[5] if len(parts) > 5 else datetime.datetime.now().strftime("%d/%m/%Y")  # chưa dùng
    
    await ctx.send("⏳ Đang tạo vé Vietnam Airlines...")
    
    img_data = await load_image(PHOI_VA_URL)
    if not img_data:
        await ctx.send("❌ Không thể tải ảnh nền! Vui lòng thử lại sau.")
        return
    
    try:
        img = Image.open(BytesIO(img_data)).convert("RGBA")
    except Exception as e:
        await ctx.send(f"❌ Lỗi đọc ảnh: {e}")
        return
    
    draw = ImageDraw.Draw(img)
    
    try:
        font_bold = ImageFont.truetype("handlers/fonts/SVN-Arial 3 bold.ttf", 50)
        font_kh = ImageFont.truetype("handlers/fonts/SVN-Arial Regular.ttf", 50)
    except:
        font_bold = font_kh = ImageFont.load_default()
    
    # Tên hành khách
    draw.text((89, 281), name, font=font_bold, fill="black")
    
    # Số hiệu chuyến bay
    draw.text((115, 609), f"VN {flight}", font=font_bold, fill="black")
    
    # Sân bay đi
    draw.text((685, 545), from_kh, font=font_kh, fill="black")
    
    # Sân bay đến
    draw.text((1105, 545), to_kh, font=font_kh, fill="black")
    
    bio = BytesIO()
    img.save(bio, "PNG")
    bio.seek(0)
    await ctx.send(file=discord.File(bio, "vietnam_airlines.png"), content=f"🎫 **Vé Vietnam Airlines**\n👤 {name}\n✈️ Chuyến: VN{flight}\n🛫 {from_kh} → {to_kh}")
# ============= CẬP NHẬT LỆNH MENU =============
@bot.command()
async def menu(ctx):
    if not is_admin(ctx.author.id):
        await ctx.send("❌ Bạn không có quyền!")
        return
    embed = discord.Embed(title="『 **MENU BOT** 』", description=f"""
**👑 Admin**
`{PREFIX}addadmin @user` - Thêm admin
`{PREFIX}deladmin @user` - Xóa admin  
`{PREFIX}listadmin` - DS admin

**📁 File**
`{PREFIX}setfile <tên>` - Upload file (riêng từng user)
`{PREFIX}listfile` - DS file của bạn

**💰 Coin Bot-Hosting**
`{PREFIX}coin <auth> [apikey]` - Chạy lụm coin 24/24
`{PREFIX}stopcoin` - Dừng lụm coin
`{PREFIX}coininfo <auth>` - Xem thông tin

**📨 FACEBOOK**
`{PREFIX}treotop <link_bài_viết> <cookie> <uid_tag> <file> <delay>` - Treo Top
`{PREFIX}nuoi <cookie> <delay>` - Nuôi Acc

**📨 MESSENGER**
`{PREFIX}ngonmes <id> <cookie> <file> <delay>` - Treo ngôn
`{PREFIX}ngonmesanh <id> <cookie> <url> <file> <delay>` - Treo ngôn ảnh
`{PREFIX}nhaymes <id> <cookie> <delay> [typing]` - Gửi tin (có typing)
`{PREFIX}npollmes <id> <cookie> <delay>` - NhâyPoll
`{PREFIX}tpollmes <id> <cookie> <file> <delay>` - TreoPoll
`{PREFIX}theme <id> <cookie> <delay> [tên]` - Set theme
`{PREFIX}namebox <id> <cookie> <delay>` - Đổi tên box

**📨 TELEGRAM**
`{PREFIX}nhaytele <token> <chat_id> <delay>` - Gửi tin từ nhay.txt
`{PREFIX}treotele <token> <chat_id> <file> <delay>` - Treo Poll
`{PREFIX}polltele <token> <chat_id> <delay>` - Gửi poll từ nhay.txt
`{PREFIX}nhaytagtele <token> <chat_id> <delay> @user...` - Gửi tin + tag

**📨 DISCORD**
`{PREFIX}treodis <token> <channel> <file> <delay>` - Gửi tin từ file
`{PREFIX}nhaydis <token> <channel> <delay> [@user...]` - Gửi tin + tag
`{PREFIX}polldis <token> <channel> <delay> [@user...]` - Gửi poll
`{PREFIX}voicedis <token> <channel> <delay>` - Gửi voice

**📨 ZALO**
`{PREFIX}nhayrieng <imei> <cookie> <delay>` - Spam tin nhắn riêng
`{PREFIX}nhaybox <imei> <cookie> <delay>` - Spam tin nhắn nhóm
`{PREFIX}nhaytagbox <imei> <cookie> <delay>` - Spam tag thành viên
`{PREFIX}pollzalo <imei> <cookie> <delay>` - Spam poll
`{PREFIX}nameboxzl <imei> <cookie> <delay>` - Đổi tên nhóm
`{PREFIX}joinzalo <imei> <cookie> <link>` - Tham gia nhóm
`{PREFIX}callzalo <imei> <cookie> [số_lần]` - Spam call
`{PREFIX}stickerzalo <imei> <cookie> [số_lượng] [delay]` - Spam sticker

**📨 INSTAGRAM**
`{PREFIX}nhayigbox <id> <cookie/user:pass> <delay>` - Spam có typing vào box
`{PREFIX}nhayigrieng <user> <cookie/user:pass> <delay>` - Spam có typing riêng
`{PREFIX}npollbox <id> <cookie/user:pass> <delay>` - Spam poll từ nhay.txt
`{PREFIX}tpollbox <id> <cookie/user:pass> <file> <delay>` - Spam poll từ file 3 dòng

**📨 GMAIL**
`{PREFIX}treogmail <email_nhận> <email|pass/...> <file> <delay>` - Spam email Gmail

**📨 WECHAT**
`{PREFIX}treowechat <access_token> <agent_id> <user> <file> <delay>`
`{PREFIX}nhaywechat <access_token> <agent_id> <user> <delay>`

**📨 SMS **
`{PREFIX}sms <sdt> [số lần]`

**📨 NGL LINK **
`{PREFIX}nhayngl <target1,target2,..> <delay>` - Nhây Ngllink
`{PREFIX}treongl <target1,target2,..> <file> <delay>` - Treo Ngllink

**📨 TIỆN ÍCH**
`{PREFIX}idbox <cookie>` - Lấy id box
`{PREFIX}botchat <cookie> [admin_uid] [prefix]` - Bot Chat Mes
`{PREFIX}damefb <cookie> <link>` - Dame Facebook
`{PREFIX}dameinfo <link>` - Check 
`{PREFIX}dametiktok <cookie> <username>`
`{PREFIX}thongbao <nội dung>` - Gửi thông báo all server
`{PREFIX}listserver` - DS server bot đang ở
`{PREFIX}cccd` - Fake cccd
`{PREFIX}cccd_gen` - Fake cccd
`{PREFIX}mb` - Fake Stk MBBANK
`{PREFIX}mbbank` - Fake BANK
`{PREFIX}okx` - Fake Okx
`{PREFIX}sun` - Fake Sunwin
`{PREFIX}vcb` - Fake Vcb
`{PREFIX}ve` - Fake Vé 
`{PREFIX}vebay` - Fake Vé Máy Bay
`{PREFIX}afk` - Farm lemon coin
**⚙️ Task**
`{PREFIX}tab` - Xem task
`{PREFIX}stop all/id/target` - Dừng task
""", color=discord.Color.blue())
    embed.set_footer(text=f"Prefix: {PREFIX} | Bot by Chử Hữu Học 💬")
    try:
        with open('menu.jpg', 'rb') as f:
            file = discord.File(f, filename='menu.jpg')
            await ctx.send(embed=embed, file=file)
    except:
        await ctx.send(embed=embed)

# ============= CHẠY BOT =============
if __name__ == "__main__":
    try:
        bot.run(BOT_TOKEN)
    except Exception as e:
        print(f"Lỗi chạy bot: {e}")


