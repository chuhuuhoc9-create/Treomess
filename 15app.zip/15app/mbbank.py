"""
mbbank.py — Fake bill MB Bank cho Facebook Messenger bot
Cú pháp: /mbbank SốTiền | Tên | STK | MãNH | NộiDung | Pin | Giờ | GiaoDiện
"""

import requests
import threading
from datetime import datetime
from io import BytesIO

from PIL import Image, ImageDraw, ImageFont

PHOIS = {
    "1": {"url": "https://i.imgur.com/1MRU5dt.png", "money_color": "#1F1DA4"},
    "2": {"url": "https://i.imgur.com/2oTl8a1.png", "money_color": "#A3412E"},
    "3": {"url": "https://i.imgur.com/e3n8f8J.png", "money_color": "#D5517E"},
}

BANK_INFO = {
    "MB":     {"logo": "https://i.imgur.com/dJXJiMz.png", "name": "MBBank (MB)"},
    "VCB":    {"logo": "https://i.imgur.com/elWpyWR.png", "name": "Vietcombank (VCB)"},
    "TCB":    {"logo": "https://i.imgur.com/Pjn8MYL.png", "name": "Techcombank (TCB)"},
    "BIDV":   {"logo": "https://i.imgur.com/30zY8oB.png", "name": "BIDV"},
    "TPBANK": {"logo": "https://i.imgur.com/Hz4Q2wm.png", "name": "TP Bank (TPB)"},
    "OCB":    {"logo": "https://i.imgur.com/JBgN9yl.png", "name": "OCB"},
    "AGB":    {"logo": "https://i.imgur.com/h8E7kuk.png", "name": "Agribank (AGB)"},
    "SHB":    {"logo": "https://i.imgur.com/6J3HHG7.png", "name": "SHB"},
    "VPBANK": {"logo": "https://i.imgur.com/HrgjHZ6.png", "name": "VP Bank (VPB)"},
    "ACB":    {"logo": "https://i.imgur.com/VyhnvZZ.png", "name": "ACB"},
    "VTB":    {"logo": "https://i.imgur.com/GwdNaXo.png", "name": "Vietinbank (CTG)"},
}

PIN_ICONS = {
    "100": "https://i.imgur.com/8sZpcNS.png",
    "80":  "https://i.imgur.com/1sOMWFG.png",
    "60":  "https://i.imgur.com/yNRzY1J.png",
    "40":  "https://i.imgur.com/35UiCk0.png",
    "35":  "https://i.imgur.com/RBjkxE2.png",
    "22":  "https://i.imgur.com/iCy35zv.png",
    "10":  "https://i.imgur.com/utEDaj5.png",
}

FONT_BOLD    = "handlers/fonts/SF-Pro-Rounded-Bold.otf"
FONT_REGULAR = "handlers/fonts/SF-Pro-Rounded-Regular.otf"


def _load_url(url: str) -> Image.Image:
    r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=15)
    r.raise_for_status()
    return Image.open(BytesIO(r.content)).convert("RGBA")


def _draw_center(draw, text, font, y, color, img_w):
    bbox = draw.textbbox((0, 0), text, font=font)
    x = (img_w - (bbox[2] - bbox[0])) // 2
    draw.text((x, y), text, font=font, fill=color)


def _fmt_money(amount: str) -> str:
    try:
        n = int(str(amount).replace(".", "").replace(",", "").strip())
        return f"{n:,} VND"
    except Exception:
        return f"{amount} VND"


def _render_bill(so_tien, ten, ngan_hang, stk, noi_dung, pin, thoi_gian, giao_dien="1") -> bytes:
    code      = ngan_hang.upper()
    bank_name = BANK_INFO.get(code, {}).get("name", code)
    logo_url  = BANK_INFO.get(code, {}).get("logo")
    phoi      = PHOIS.get(str(giao_dien), PHOIS["1"])

    bg          = _load_url(phoi["url"])
    money_color = phoi.get("money_color", "#1b4a81")
    draw        = ImageDraw.Draw(bg)
    w, _        = bg.size

    f_large  = ImageFont.truetype(FONT_BOLD,    55)
    f_medium = ImageFont.truetype(FONT_BOLD,    40)
    f_time   = ImageFont.truetype(FONT_REGULAR, 30)
    f_small  = ImageFont.truetype(FONT_REGULAR, 35)
    f_status = ImageFont.truetype(FONT_BOLD,    35)

    try:
        thoi_gian_dt = thoi_gian.split("-")[0].strip()
    except Exception:
        thoi_gian_dt = thoi_gian

    draw.text((60, 30), thoi_gian_dt, font=f_status, fill="black")
    _draw_center(draw, _fmt_money(so_tien), f_large,  460, money_color, w)
    _draw_center(draw, thoi_gian,           f_time,   550, "#808080",   w)
    _draw_center(draw, ten,                 f_medium, 715, "#333333",   w)

    if logo_url:
        try:
            logo = _load_url(logo_url).resize((50, 50))
            bbox = draw.textbbox((0, 0), bank_name, font=f_small)
            tw   = bbox[2] - bbox[0]
            sx   = (w - logo.width - 15 - tw) // 2
            bg.paste(logo, (sx, 785), logo)
            draw.text((sx + logo.width + 15, 785), bank_name, font=f_small, fill="#333333")
        except Exception:
            pass

    _draw_center(draw, stk,      f_small, 845, "#333333", w)
    _draw_center(draw, noi_dung, f_small, 895, "#333333", w)

    if pin in PIN_ICONS:
        try:
            pin_img = _load_url(PIN_ICONS[pin]).resize((68, 30))
            bg.paste(pin_img, (w - 120, 30), pin_img)
        except Exception:
            pass

    buf = BytesIO()
    bg.save(buf, format="PNG")
    return buf.getvalue()


def cmd_mbbank(client, thread_id: str, full_args: str):
    """Dispatcher cho /mbbank."""
    if not full_args:
        guide = (
            "📋 Hướng dẫn fake bill MB Bank\n\n"
            "Cú pháp:\n"
            "/mbbank SốTiền | Tên | STK | MãNH | NộiDung | Pin | Giờ | GiaoDiện\n\n"
            "Ví dụ:\n"
            "/mbbank 100000 | NGUYEN VAN A | 99999999 | MB | Chuyen khoan | 80 | 18:30 | 1\n\n"
            "🔋 Pin: 100  80  60  40  35  22  10\n"
            "🏦 Mã NH: MB  VCB  TCB  BIDV  TPBANK  OCB  AGB  SHB  VPBANK  ACB  VTB\n"
            "🎨 Giao diện: 1  2  3"
        )
        client.send_message(text=guide, thread_id=thread_id)
        return
    threading.Thread(
        target=_worker, args=(client, thread_id, full_args), daemon=True
    ).start()


def _worker(client, thread_id: str, full_args: str):
    try:
        params = [p.strip() for p in full_args.split("|")]

        if len(params) < 4:
            client.send_message(
                text="⚠️ Cần ít nhất: SốTiền | Tên | STK | MãNH",
                thread_id=thread_id,
            )
            return

        so_tien   = params[0]
        ten       = params[1].upper()
        stk       = params[2]
        ngan_hang = params[3].upper()
        noi_dung  = params[4] if len(params) > 4 else "Chuyen khoan"
        pin       = params[5] if len(params) > 5 else "100"
        thoi_gian = params[6] if len(params) > 6 else datetime.now().strftime("%H:%M - %d/%m/%Y")
        giao_dien = params[7] if len(params) > 7 else "1"

        img_bytes = _render_bill(so_tien, ten, ngan_hang, stk, noi_dung, pin, thoi_gian, giao_dien)

        caption = (
            f"✅ Fake bill thành công\n"
            f"{'─'*28}\n"
            f"🏦 Ngân hàng: {ngan_hang}\n"
            f"💳 Số tiền: {so_tien} VND\n"
            f"👤 Người nhận: {ten}\n"
            f"🔢 STK: {stk}\n"
            f"📌 Nội dung: {noi_dung}\n"
            f"🔋 Pin: {pin}%\n"
            f"⏰ Thời gian: {thoi_gian}\n"
            f"🎨 Giao diện: {giao_dien}"
        )

        client.send_image(image_data=img_bytes, thread_id=thread_id, caption=caption)

    except Exception as e:
        client.send_message(text=f"❌ Lỗi /mbbank: {e}", thread_id=thread_id)
