import os
import time
import pyfiglet
import threading
import re
import json
import random
import requests
import datetime as dt_module
from datetime import datetime
from io import BytesIO
from mbbank import cmd_mbbank
from downtt import cmd_downtt

from fb import (
    FacebookMQTTAllInOne,
    parse_cookie_string,
    gen_threading_id,
    formAll,
    mainRequests,
    Headers,
    kick_user,
    toggle_link_sharing,
    set_thread_name,
    send_reaction,
    join_group_via_link,
    THEMES,
)

# ===== CẤU HÌNH =====
ADMIN_FILE = "admins.json"
MUTE_FILE = "mutelist.txt"
OWNER_UID = None
PREFIX = "/"
ACTIVE_ATTACKS = {}

# Lưu trạng thái chờ wartag: {thread_id: {"delay": float, "sender_id": str}}
WARTAG_PENDING = {}

# Trạng thái bật/tắt bot theo từng box: {thread_id: True/False}
BOT_ENABLED = {}

WELCOME_MSG = None
GOODBYE_MSG = None
BATICON_ACTIVE = False

# Danh sách box đang hoạt động (tự động thêm khi nhận /menu)
active_boxes = set()

# Tính năng tự động reaction
AUTO_REACT_ENABLED = False
AUTO_REACT_EMOJI = "❤️"

OPENROUTER_API_KEY = "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"
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"

# Trạng thái trả lời tự nhiên: {thread_id: bool}
NATURAL_REPLY_BOXES = {}

# Lịch sử hội thoại cho từng box: {thread_id: [{"role": ..., "content": ...}]}
CHAT_HISTORY = {}
MAX_HISTORY = 20  # Số tin nhắn giữ lại tối đa mỗi box

SYSTEM_PERSONA = (
    "Mày là một người bình thường đang nhắn tin trong nhóm Facebook. "
    "Mày nói chuyện hoàn toàn tự nhiên như người Việt Nam hay nhắn tin: viết thường, "
    "dùng từ lóng, teen code khi phù hợp, câu ngắn gọn, đôi khi dùng emoji nhưng không lạm dụng. "
    "Không bao giờ để lộ mày là AI hay bot. Không dùng dấu chấm cuối câu kiểu văn viết. "
    "Trả lời đúng ngữ cảnh, bắt chuyện tự nhiên như bạn bè nhắn tin. "
    "Nếu ai hỏi mày là ai thì nói là thành viên trong nhóm, không nhận là bot. "
    "Chỉ trả lời bằng nội dung tin nhắn, không giải thích gì thêm."
)

# ===== HÀM GỌI OPENROUTER =====
def call_openrouter(prompt: str) -> str:
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
    }
    data = {
        "model": "google/gemini-2.0-flash-lite-001",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.7,
    }
    try:
        resp = requests.post(OPENROUTER_URL, headers=headers, json=data, timeout=15)
        if resp.status_code == 200:
            result = resp.json()
            return result["choices"][0]["message"]["content"].strip()
        else:
            return f"❌ Lỗi OpenRouter {resp.status_code}"
    except Exception as e:
        return f"❌ Lỗi kết nối: {e}"

def call_openrouter_natural(thread_id: str, user_msg: str, sender_name: str = None) -> str:
    """Gọi API với lịch sử hội thoại và system persona người thật."""
    global CHAT_HISTORY

    if thread_id not in CHAT_HISTORY:
        CHAT_HISTORY[thread_id] = []

    # Thêm tên người gửi vào nội dung nếu biết
    content = f"{sender_name}: {user_msg}" if sender_name else user_msg
    CHAT_HISTORY[thread_id].append({"role": "user", "content": content})

    # Giới hạn lịch sử
    if len(CHAT_HISTORY[thread_id]) > MAX_HISTORY:
        CHAT_HISTORY[thread_id] = CHAT_HISTORY[thread_id][-MAX_HISTORY:]

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
    }
    data = {
        "model": "google/gemini-2.0-flash-lite-001",
        "messages": [{"role": "system", "content": SYSTEM_PERSONA}] + CHAT_HISTORY[thread_id],
        "temperature": 0.9,
        "max_tokens": 300,
    }
    try:
        resp = requests.post(OPENROUTER_URL, headers=headers, json=data, timeout=15)
        if resp.status_code == 200:
            result = resp.json()
            reply = result["choices"][0]["message"]["content"].strip()
            # Lưu lại reply của bot vào lịch sử
            CHAT_HISTORY[thread_id].append({"role": "assistant", "content": reply})
            return reply
        else:
            return None
    except Exception as e:
        print(f"[NaturalReply] Lỗi: {e}")
        return None

# ===== QUẢN LÝ ADMIN =====
def load_admins():
    if not os.path.exists(ADMIN_FILE):
        return {}
    with open(ADMIN_FILE, 'r', encoding='utf-8') as f:
        try: return json.load(f)
        except: return {}

def save_admins(admins):
    with open(ADMIN_FILE, 'w', encoding='utf-8') as f:
        json.dump(admins, f, ensure_ascii=False, indent=2)

def is_admin(uid):
    if uid == OWNER_UID:
        return True
    admins = load_admins()
    if uid in admins:
        expiry = admins[uid]
        if expiry == -1 or time.time() < expiry:
            return True
        else:
            del admins[uid]
            save_admins(admins)
    return False

def add_admin(uid, duration_str):
    admins = load_admins()
    now = time.time()
    if duration_str.lower() == "permanent":
        admins[uid] = -1
    else:
        match = re.match(r"(\d+)([dhms])", duration_str)
        if not match:
            return False, "Sai định dạng thời gian (ví dụ: 30d, 2h, 90m)"
        num = int(match.group(1))
        unit = match.group(2)
        mult = {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
        admins[uid] = now + num * mult[unit]
    save_admins(admins)
    return True, None

def remove_admin(uid):
    admins = load_admins()
    if uid in admins:
        del admins[uid]
        save_admins(admins)
        return True
    return False

# ===== QUẢN LÝ MUTE =====
def load_muted():
    if not os.path.exists(MUTE_FILE):
        return set()
    with open(MUTE_FILE, 'r', encoding='utf-8') as f:
        return {line.strip() for line in f if line.strip()}

def save_muted(muted):
    with open(MUTE_FILE, 'w', encoding='utf-8') as f:
        for uid in muted:
            f.write(uid + '\n')

def is_muted(uid):
    return uid in load_muted()

# ===== ĐỌC FILE NỘI DUNG =====
def read_lines(filename, default=None):
    if not os.path.exists(filename):
        with open(filename, 'w', encoding='utf-8') as f:
            if default:
                f.write('\n'.join(default))
        return default or []
    with open(filename, 'r', encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip()]

# ===== TIỆN ÍCH TẤN CÔNG =====
def spam_worker(client, thread_id, lines, delay, stop_event, replace_map=None, mention_uid=None):
    while not stop_event.is_set():
        for line in lines:
            if stop_event.is_set():
                break
            msg = line
            if replace_map:
                for k, v in replace_map.items():
                    msg = msg.replace(k, v)
            mention = None
            if mention_uid:
                mention = {"id": mention_uid, "tag": "@" + str(mention_uid)}
            try:
                client.send_message(text=msg, thread_id=thread_id, mention=mention)
            except Exception as e:
                print(f"Spam error: {e}")
            time.sleep(delay)

def wartag_worker(client, thread_id, lines, delay, stop_event, mention_uid):
    """
    War có tag thật: nhúng @tag vào ĐẦU mỗi message,
    truyền offset=0 và length=len(tag_str) để FB nhận diện mention chính xác.
    """
    tag_str = f"@{mention_uid} "   # khoảng trắng sau tag để tách với nội dung
    tag_len = len(tag_str)

    while not stop_event.is_set():
        for line in lines:
            if stop_event.is_set():
                break
            # Ghép tag vào đầu dòng nội dung
            msg = tag_str + line
            mention = {
                "id": mention_uid,
                "offset": 0,
                "length": tag_len - 1,  # không tính khoảng trắng cuối
            }
            try:
                client.send_message(text=msg, thread_id=thread_id, mention=mention)
            except Exception as e:
                print(f"Wartag error: {e}")
            time.sleep(delay)

def stop_attack(thread_id=None):
    if thread_id:
        if thread_id in ACTIVE_ATTACKS:
            ACTIVE_ATTACKS[thread_id].set()
            return True
        return False
    else:
        for evt in ACTIVE_ATTACKS.values():
            evt.set()
        ACTIVE_ATTACKS.clear()
        return True

def sms_spam(phone, count):
    print(f"[SMS] Mô phỏng spam {count} tin đến {phone}")
    for i in range(count):
        time.sleep(1)
    return f"Đã gửi {count} tin mô phỏng đến {phone}"

# ===== HÀM TIỆN ÍCH =====
def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    clear()
    ascii_banner = pyfiglet.figlet_format("Zerfer", font="slant")
    print(ascii_banner)
    print("")

reoten_active = False
reoten_info = {}
bot_start_time = datetime.now()

def load_reoten_content():
    return read_lines("reoten.txt", ["{user_name} hello", "{user_name} ơi", "chào {user_name}"])

def send_mention_messages(client, thread_id, user_name, lines, delay, uid):
    global reoten_active
    while reoten_active and reoten_info.get('uid') == uid:
        for line in lines:
            if not reoten_active:
                break
            message = line.replace("{user_name}", user_name)
            try:
                client.send_message(text=message, thread_id=thread_id)
            except:
                pass
            time.sleep(delay)
    reoten_active = False

def get_uptime():
    now = datetime.now()
    uptime = now - bot_start_time
    days = uptime.days
    hours = uptime.seconds // 3600
    minutes = (uptime.seconds % 3600) // 60
    seconds = uptime.seconds % 60
    if days > 0:
        return f"{days} ngày {hours} giờ {minutes} phút {seconds} giây"
    elif hours > 0:
        return f"{hours} giờ {minutes} phút {seconds} giây"
    elif minutes > 0:
        return f"{minutes} phút {seconds} giây"
    else:
        return f"{seconds} giây"

def get_menu():
    menu = """
> Menu Tấn Khang w Xuân Thắng 🐾
> Prefix: /
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔥 BẢNG ĐIỀU KHIỂN

👑 Quản Lý Admin:
• /addadmin <ID> <30d> : Thêm quyền
• /xoaadmin <ID> : Xóa quyền Admin

🆔 Lấy ID:
• /id : Lấy ID bản thân
• /idroom : Lấy ID phòng chat hiện tại
• /idadmin : Lấy ID của admin chính
• /uidbox <link> : Lấy UID từ link box

⚡ Tấn Công & Spam:
• /war <delay> [@uid] : War trong box
• /warbox <delay> <id/link> : War box khác
• /wartag <delay> : War có tag (sau đó REPLY tin nhắn người muốn tag)
• /n2 <delay> <idbox> <tên> : Spam biến tên
• /spamboxfull <id/link> [delay] : Spam file spam.txt
• /stop [idbox] : Dừng tấn công

🔊 Réo Tên:
• /reoten <tên> <delay> : Réo tên liên tục
• /stopreoten : Dừng réo tên

🏢 Quản lý Box:
• /scan : Thông tin phòng
• /listtv : Danh sách thành viên
• /setname <tên mới> : Đổi tên nhóm
• /kick @uid : Kick thành viên
• /mute @uid : Mute thành viên
• /unmute @uid : Bỏ mute
• /adduser <uid> : Thêm thành viên
• /setadmin <uid> : Đặt admin
• /removeadmin <uid> : Gỡ admin
• /camguilink : Bật duyệt thành viên
• /join <link> : Tham gia box qua link

🎨 Tuỳ Chỉnh Box:
• /theme [tên|random] : Đổi theme box
• /listtheme : Xem danh sách theme
• /seticon <url/path> : Đổi ảnh nhóm
• /setemoji <emoji> : Đổi emoji nhóm
• /nick <uid> <nick> : Đổi nickname
• /baticon <delay> : Tự động đổi icon
• /stopbaticon : Dừng đổi icon

📢 Chia Sẻ:
• /sharelink <url> [text] : Chia sẻ link
• /poll <câu hỏi> | <lựa chọn1> | ... : Tạo poll
• /typing <on|off> : Bật/tắt typing

🤖 AI & Tự Động:
• /ai <câu hỏi> : Hỏi AI
• /traloitunhien <on|off> : Bot reply như người khi bị @mention
• /setwelcome <tin nhắn> : Mẫu chào mừng ({name})
• /setgoodbye <tin nhắn> : Mẫu tạm biệt
• /autoreact <on|off|emoji> : Tự động reaction

🗣️ Tiện Ích:
• /sun Tên|SốTiền : Fake số dư Sunwin
• /mbbank SốTiền|Tên|STK|MãNH|... : Fake bill MB Bank
• /downtt <url> : Tải video/ảnh TikTok
• /voice <nội dung> : Chuyển text thành giọng nói
• /thoitiet <tên thành phố> : Xem thời tiết

⚙️ Điều Khiển Bot:
• /bot on : Bật bot trong box này
• /bot off : Tắt bot trong box này
• /bot : Xem trạng thái

ℹ️ Thông Tin:
• /uptime : Thời gian bot chạy
• /menu : Hiện menu này

>> version 7.0 <<"""
    return menu

# ===== SỰ KIỆN THÀNH VIÊN =====
def on_member_event(client, event):
    global WELCOME_MSG, GOODBYE_MSG
    thread_id = event.get('thread_id')
    user_id = event.get('user_id')
    etype = event.get('type')

    if thread_id not in active_boxes:
        return

    try:
        user_info = client.get_user_info(user_id)
        user_name = user_info.get('name', 'bạn') if user_info.get('success') else 'thành viên mới'
    except:
        user_name = 'thành viên'

    if etype == 'join' and WELCOME_MSG:
        prompt = (f"Hãy viết một lời chào mừng thân thiện, vui vẻ bằng tiếng Việt cho thành viên mới tên là {user_name} "
                  f"vừa tham gia nhóm. Chỉ trả về lời chào, không thêm bất kỳ chú thích nào.")
        ai_msg = call_openrouter(prompt)
        final_msg = WELCOME_MSG.replace("{name}", user_name) if ai_msg.startswith("❌") else ai_msg
        client.send_message(text=final_msg, thread_id=thread_id)
    elif etype == 'leave' and GOODBYE_MSG:
        prompt = (f"Hãy viết một lời tạm biệt nhẹ nhàng, tình cảm bằng tiếng Việt cho thành viên tên là {user_name} "
                  f"vừa rời nhóm. Chỉ trả về lời tạm biệt, không chú thích.")
        ai_msg = call_openrouter(prompt)
        final_msg = GOODBYE_MSG.replace("{name}", user_name) if ai_msg.startswith("❌") else ai_msg
        client.send_message(text=final_msg, thread_id=thread_id)

# ===== WORKER ĐỔI ICON LIÊN TỤC (baticon) =====
def baticon_worker(client, thread_id, delay):
    global BATICON_ACTIVE
    emoji_list = [
        "😀", "❤️", "🔥", "🎉", "💯", "👍", "😂", "😍", "🤩", "🥳",
        "💪", "🤗", "👋", "🌸", "⭐", "☀️", "🌈", "🎈", "💎", "🍀"
    ]
    while BATICON_ACTIVE:
        try:
            em = random.choice(emoji_list)
            client.set_emoji(em, thread_id)
            print(f"BATICON changed to {em}")
        except Exception as e:
            print(f"Baticon error: {e}")
        time.sleep(delay)

# ===== HÀM REPLY TỰ NHIÊN ASYNC =====
def _natural_reply_async(client, thread_id, text, sender_name):
    reply = call_openrouter_natural(thread_id, text, sender_name)
    if reply:
        try:
            client.send_message(text=reply, thread_id=thread_id)
        except Exception as e:
            print(f"[NaturalReply] Gửi lỗi: {e}")

# =======================================================================
# ===== CÁC LỆNH CHUYỂN ĐỔI TỪ TELEGRAM → MESSENGER =====
# =======================================================================

# ── Tiện ích dùng chung ──────────────────────────────────────────────
def _load_img_url(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    resp = requests.get(url, headers=headers)
    resp.raise_for_status()
    from PIL import Image
    img = Image.open(BytesIO(resp.content))
    return img.convert("RGBA")

def _img_to_bytes(img, fmt="PNG"):
    buf = BytesIO()
    buf.name = f"out.{fmt.lower()}"
    img.save(buf, fmt)
    buf.seek(0)
    return buf

PIN_ICONS_MAP = {
    "100": "https://i.imgur.com/8sZpcNS.png",
    "80":  "https://i.imgur.com/1sOMWFG.png",
    "60":  "https://i.imgur.com/yNRzY1J.png",
    "40":  "https://i.imgur.com/35UiCk0.png",
    "35":  "https://i.imgur.com/RBjkxE2.png",
    "22":  "https://i.imgur.com/iCy35zv.png",
    "10":  "https://i.imgur.com/utEDaj5.png",
}

# ── /voice ────────────────────────────────────────────────────────────
def cmd_voice(client, thread_id, full_args):
    if not full_args:
        client.send_message(text="💢 Cú pháp: /voice <nội dung>\nHỗ trợ tiền tố ngôn ngữ: en vi ko ja zh fr de es it", thread_id=thread_id)
        return
    lang_map = {'en':'en','es':'es','fr':'fr','de':'de','it':'it','ko':'ko','ja':'ja','zh':'zh'}
    lang = 'vi'; text = full_args
    for prefix, code in lang_map.items():
        if text.lower().startswith(f"{prefix} "):
            lang = code; text = text[3:].strip(); break
    fname = f"voice_{thread_id}.mp3"
    try:
        from gtts import gTTS
        tts = gTTS(text=text, lang=lang)
        tts.save(fname)
        # Thử các method gửi audio khác nhau tùy fb.py hỗ trợ
        with open(fname, 'rb') as f:
            audio_bytes = f.read()
        sent = False
        # Ưu tiên send_file nếu có
        for method_name in ("send_file", "send_audio", "sendFile", "sendAudio"):
            if hasattr(client, method_name):
                try:
                    fn = getattr(client, method_name)
                    if method_name in ("send_file", "sendFile"):
                        fn(file_data=audio_bytes, filename="voice.mp3", thread_id=thread_id)
                    else:
                        fn(audio_data=audio_bytes, thread_id=thread_id, caption="🗣️ File âm thanh")
                    sent = True
                    break
                except Exception:
                    continue
        # Fallback: upload lên tmpfiles.org rồi gửi link
        if not sent:
            try:
                up = requests.post(
                    "https://tmpfiles.org/api/v1/upload",
                    files={"file": ("voice.mp3", audio_bytes, "audio/mpeg")},
                    timeout=20
                )
                raw_url = up.json()["data"]["url"]
                dl_url = raw_url.replace("tmpfiles.org/", "tmpfiles.org/dl/")
                client.send_message(
                    text=f"🗣️ File giọng nói ({lang}):\n{dl_url}\n⚠️ Link hết hạn sau 60 phút",
                    thread_id=thread_id
                )
                sent = True
            except Exception as ue:
                client.send_message(text=f"❌ Không thể gửi audio: {ue}", thread_id=thread_id)
    except Exception as e:
        client.send_message(text=f"❌ Lỗi /voice: {e}", thread_id=thread_id)
    finally:
        if os.path.exists(fname):
            os.remove(fname)

# ── /sun ─────────────────────────────────────────────────────────────
def cmd_sun(client, thread_id, full_args):
    from PIL import Image, ImageDraw, ImageFont
    TEMPLATE = "https://i.imgur.com/DCPRwwE.jpeg"
    FONT_PATH = "handlers/fonts/SVN-Arial Regular.ttf"
    FONT_NAME = "handlers/fonts/SF-Pro-Rounded-Bold.otf"
    GT = (199,190,179); GB = (236,208,132)

    if not full_args or "|" not in full_args:
        client.send_message(
            text="📋 Hướng dẫn /sun\nCú pháp: /sun Tên | SốTiền\nVí dụ: /sun garena123 | 5000000",
            thread_id=thread_id)
        return

    parts = [p.strip() for p in full_args.split("|", 1)]
    name_text = parts[0]
    amount_raw = parts[1] if len(parts) > 1 else "0"

    def _fmt(n):
        try: return f"{int(n.replace(',','').replace('.','')): ,}".strip()
        except: return n
    def _shorten(s, mx=13):
        return s[:mx]+"..." if len(s)>mx else s
    def _adj_font(txt, base):
        try: n=int(txt.replace(",","").replace(" ",""))
        except: return base
        if n>99000000000: return int(base*0.6)
        if n>1000000000: return int(base*0.8)
        return base
    def _mask(text, font):
        dummy=Image.new("L",(1,1)); dr=ImageDraw.Draw(dummy)
        bbox=dr.textbbox((0,0),text,font=font)
        w,h=bbox[2]-bbox[0],bbox[3]-bbox[1]
        mask=Image.new("L",(w,h),0); dr2=ImageDraw.Draw(mask)
        dr2.text((-bbox[0],-bbox[1]),text,fill=255,font=font)
        return mask
    def _grad(size,tc,bc):
        w,h=size; base=Image.new("RGBA",(w,h))
        for y in range(h):
            t=y/max(1,h-1)
            r=int(tc[0]*(1-t)+bc[0]*t); g=int(tc[1]*(1-t)+bc[1]*t); b=int(tc[2]*(1-t)+bc[2]*t)
            for x in range(w): base.putpixel((x,y),(r,g,b,255))
        return base
    def _draw_grad(base_img, text, font, cx=None, cy=None):
        mask=_mask(text,font); grad=_grad(mask.size,GT,GB)
        ti=Image.new("RGBA",mask.size,(0,0,0,0)); ti.paste(grad,(0,0),mask)
        if cx and cy:
            tx=int(cx-ti.width/2); ty=int(cy-ti.height/2)
        else:
            tx=int(base_img.width//2-ti.width/2); ty=int(cy-ti.height/2)
        base_img.paste(ti,(tx,ty),ti)

    try:
        name_text  = _shorten(name_text)
        amount_text = _fmt(amount_raw)
        amt_sz = _adj_font(amount_text, 45)
        base = _load_img_url(TEMPLATE)
        fn = ImageFont.truetype(FONT_NAME, 30)
        fa = ImageFont.truetype(FONT_PATH, amt_sz)
        _draw_grad(base, name_text, fn, cx=485, cy=65)
        _draw_grad(base, amount_text, fa, cy=65)
        base = base.convert("RGB")
        buf = _img_to_bytes(base, "JPEG")
        client.send_image(image_data=buf.read(), thread_id=thread_id,
                          caption=f"✅ FAKE SỐ DƯ SUNWIN\n🧸 Người chơi: {name_text}\n💸 Số dư: {amount_text}")
    except Exception as e:
        client.send_message(text=f"❌ Lỗi /sun: {e}", thread_id=thread_id)

# ── /thoitiet ─────────────────────────────────────────────────────────
_WEATHER_API_KEY = ""  # Không cần key, dùng wttr.in miễn phí

# Ánh xạ tên thành phố tiếng Việt → tên tiếng Anh cho wttr.in
_CITY_VI_MAP = {
    "hà nội": "Hanoi", "ha noi": "Hanoi", "hn": "Hanoi",
    "hồ chí minh": "Ho Chi Minh City", "ho chi minh": "Ho Chi Minh City",
    "sài gòn": "Ho Chi Minh City", "sai gon": "Ho Chi Minh City", "hcm": "Ho Chi Minh City",
    "đà nẵng": "Da Nang", "da nang": "Da Nang", "đn": "Da Nang",
    "hải phòng": "Hai Phong", "hai phong": "Hai Phong",
    "cần thơ": "Can Tho", "can tho": "Can Tho",
    "nha trang": "Nha Trang",
    "huế": "Hue", "hue": "Hue",
    "đà lạt": "Da Lat", "da lat": "Da Lat",
    "vũng tàu": "Vung Tau", "vung tau": "Vung Tau",
    "quy nhơn": "Quy Nhon", "quy nhon": "Quy Nhon",
    "buôn ma thuột": "Buon Ma Thuot", "buon ma thuot": "Buon Ma Thuot",
    "thái nguyên": "Thai Nguyen", "thai nguyen": "Thai Nguyen",
    "vinh": "Vinh",
    "bình dương": "Binh Duong", "binh duong": "Binh Duong",
    "đồng nai": "Dong Nai", "dong nai": "Dong Nai",
    "long an": "Long An",
    "tiền giang": "Tien Giang",
    "bến tre": "Ben Tre",
    "an giang": "An Giang",
    "kiên giang": "Kien Giang",
}

def cmd_thoitiet(client, thread_id, full_args, api_key=""):
    city_raw = full_args.strip() if full_args.strip() else "Ha Noi"
    # Ánh xạ tên tiếng Việt
    city = _CITY_VI_MAP.get(city_raw.lower(), city_raw)

    def _review_temp(f):
        try: f=float(f)
        except: return ""
        if f>=40: return "🥵 Rất nóng!"
        if f>=33: return "🌞 Nóng oi"
        if f>=28: return "🌤️ Hơi nóng"
        if f>=20: return "😊 Dễ chịu"
        if f>=15: return "😌 Mát mẻ"
        if f>=10: return "🥶 Lạnh"
        return "❄️ Rét"
    def _review_humid(h):
        try: h=float(h)
        except: return ""
        if h>=80: return "💦 Ẩm nặng"
        if h>=60: return "🌫️ Khá cao"
        if h>=40: return "👍 Lý tưởng"
        return "🔥 Khô"
    def _review_wind(ws):
        try: ws=float(ws)
        except: return ""
        if ws>=20: return "🌪️ Cực mạnh!"
        if ws>=10: return "💨 Gió lớn"
        if ws>=4: return "🌬️ Vừa"
        return "🍃 Nhẹ"

    def _worker():
        try:
            client.send_message(text="⏳ Đang lấy thời tiết...", thread_id=thread_id)
            import urllib.parse as _up
            # Thử nhiều biến thể tên thành phố
            cities_to_try = [city]
            if city != city_raw:
                cities_to_try.append(city_raw)

            data = None
            for c in cities_to_try:
                try:
                    url = f"https://wttr.in/{_up.quote_plus(c)}?format=j1"
                    r = requests.get(url, timeout=12, headers={"User-Agent": "curl/7.68.0"})
                    if r.status_code == 200:
                        j = r.json()
                        if j.get("current_condition") and j["current_condition"][0].get("temp_C"):
                            data = j
                            break
                except Exception:
                    continue

            if not data:
                client.send_message(
                    text=f"❌ Không tìm thấy thành phố '{city_raw}'.\nThử nhập tên tiếng Anh, ví dụ: Hanoi, Da Nang, Ho Chi Minh City",
                    thread_id=thread_id)
                return

            current = data["current_condition"][0]
            area    = data["nearest_area"][0]

            city_name = area["areaName"][0]["value"]
            country   = area["country"][0]["value"]
            temp      = current["temp_C"]
            feels     = current["FeelsLikeC"]
            humidity  = current["humidity"]
            weather   = current["lang_vi"][0]["value"] if current.get("lang_vi") else current["weatherDesc"][0]["value"]
            wind_kmh  = current["windspeedKmph"]
            wind_ms   = round(float(wind_kmh) / 3.6, 1)
            wind_dir  = current["winddir16Point"]
            clouds    = current["cloudcover"]
            pressure  = current["pressure"]
            visibility= current["visibility"]
            uv        = current.get("uvIndex","?")

            today = data["weather"][0]
            max_t = today["maxtempC"]
            min_t = today["mintempC"]
            sunrise  = today["astronomy"][0]["sunrise"]
            sunset   = today["astronomy"][0]["sunset"]

            map_url = f"https://www.google.com/maps/search/{_up.quote_plus(city_name)}"

            msg = (
                f"🌤️ THỜI TIẾT TẠI {city_name.upper()}, {country.upper()}\n"
                f"{'━'*30}\n"
                f"🌡️ Nhiệt độ: {temp}°C (cảm giác {feels}°C) {_review_temp(feels)}\n"
                f"📊 Cao nhất: {max_t}°C | Thấp nhất: {min_t}°C\n"
                f"💧 Độ ẩm: {humidity}% {_review_humid(humidity)}\n"
                f"🌫️ Tình trạng: {weather}\n"
                f"🌬️ Gió: {wind_ms} m/s hướng {wind_dir} {_review_wind(wind_ms)}\n"
                f"☁️ Mây: {clouds}%\n"
                f"⏲️ Áp suất: {pressure} hPa\n"
                f"👁️ Tầm nhìn: {visibility} km\n"
                f"☀️ UV Index: {uv}\n"
                f"🌅 Mặt trời mọc: {sunrise}\n"
                f"🌇 Mặt trời lặn: {sunset}\n"
                f"🗺️ Bản đồ: {map_url}"
            )
            client.send_message(text=msg, thread_id=thread_id)
        except Exception as e:
            client.send_message(text=f"❌ Lỗi /thoitiet: {e}\nThử nhập tên thành phố bằng tiếng Anh", thread_id=thread_id)

    threading.Thread(target=_worker, daemon=True).start()

# ── /ve (Vé máy bay VNA app) ──────────────────────────────────────────
def cmd_ve(client, thread_id, full_args):
    from PIL import Image, ImageDraw, ImageFont
    import qrcode as _qr
    TEMPLATE = "https://i.imgur.com/Avtwk83.png"
    FONT_BOLD = "handlers/fonts/SF-Pro-Rounded-Bold.otf"
    FONT_REG  = "handlers/fonts/SF-Pro-Rounded-Regular.otf"

    if not full_args:
        client.send_message(
            text="📋 Hướng dẫn /ve\nCú pháp: /ve Tên|Booking|Từ|Đến|MãTừ|MãĐến|ChuyếnBay|Ngày|GiờMặt|GiờĐến|KhởiHành|Ghế|Hạng|Ga|Cửa|Nhóm|Pin|TGian\nVí dụ: /ve NGUYEN THANH TRUC|E5I6WUN|DA NANG|HA NOI|DAD|HAN|VN7709|31/01/2026|15:30|18:00|16:30|13B",
            thread_id=thread_id)
        return

    params = [p.strip() for p in full_args.split("|")]
    if len(params) < 6:
        client.send_message(text="⚠️ Cần ít nhất: Tên|Booking|Từ|Đến|MãTừ|MãĐến", thread_id=thread_id)
        return

    now = datetime.now()
    data = {
        "ten":          params[0].upper(),
        "booking_code": params[1].upper() if len(params)>1 else "",
        "tu":           params[2].upper() if len(params)>2 else "",
        "den":          params[3].upper() if len(params)>3 else "",
        "from":         params[4].upper() if len(params)>4 else "DAD",
        "to":           params[5].upper() if len(params)>5 else "SGN",
        "chuyen_bay":   params[6].upper() if len(params)>6 else f"VN{random.randint(1000,9999)}",
        "ngay_bay":     params[7] if len(params)>7 else now.strftime("%d/%m/%Y"),
        "gio_co_mat":   params[8] if len(params)>8 else "00:00",
        "den_noi":      params[9] if len(params)>9 else "00:00",
        "khoi_hanh":    params[10] if len(params)>10 else "00:00",
        "ghe":          params[11] if len(params)>11 else "12A",
        "hang":         params[12] if len(params)>12 else "PHỔ THÔNG",
        "ga":           params[13] if len(params)>13 else "1",
        "cua":          params[14] if len(params)>14 else "5",
        "nhom":         params[15] if len(params)>15 else "3",
        "pin":          params[16] if len(params)>16 else "100",
        "thoi_gian_dt": params[17] if len(params)>17 else now.strftime("%H:%M"),
    }

    try:
        template = _load_img_url(TEMPLATE)
        pin_url = PIN_ICONS_MAP.get(data["pin"], PIN_ICONS_MAP["100"])
        sb = _load_img_url(pin_url).resize((55,30), Image.LANCZOS)
        template.paste(sb, (790,50), sb)
        draw = ImageDraw.Draw(template)
        fb = ImageFont.truetype(FONT_BOLD, 32)
        fr = ImageFont.truetype(FONT_REG, 26)
        fh = ImageFont.truetype(FONT_BOLD, 38)
        ft = ImageFont.truetype(FONT_REG, 90)

        draw.text((30,380), data["from"], font=ft, fill="black")
        bbox = ft.getbbox(data["to"]); w1=bbox[2]-bbox[0]
        draw.text((900-w1,380), data["to"], font=ft, fill="black")
        draw.text((30,550), data["chuyen_bay"], font=fb, fill="black")
        draw.text((470,550), data["ngay_bay"], font=fb, fill="black")
        draw.text((30,645), data["ten"], font=fb, fill="black")
        draw.text((470,730), data["ghe"], font=fb, fill="black")
        draw.text((30,820), data["ga"], font=fb, fill="black")
        draw.text((30,1040), data["nhom"], font=fb, fill="black")
        draw.text((30,950), data["cua"], font=fb, fill="black")
        draw.text((470,850), data["gio_co_mat"], font=fb, fill="black")
        draw.text((470,950), data["khoi_hanh"], font=fb, fill="black")
        draw.text((90,50), data["thoi_gian_dt"], font=fh, fill="white")
        draw.text((470,1040), data["den_noi"], font=fb, fill="black")
        draw.text((30,730), data["hang"], font=fb, fill="black")
        draw.text((30,350), data["tu"], font=fr, fill="#555555")
        bbox2=fr.getbbox(data["den"]); w2=bbox2[2]-bbox2[0]
        draw.text((900-w2,350), data["den"], font=fr, fill="#555555")

        # QR
        qr_content = f"{data['ten']} {data['booking_code']} DADSGNVN 7709 363Y1E95XRE9 348>5180 M4330BVN 2A738230594465782 VN N"
        qr_img = _qr.make(qr_content).convert("RGBA")
        nd = []
        for item in qr_img.getdata():
            nd.append((255,255,255,0) if item[0]>200 and item[1]>200 and item[2]>200 else item)
        qr_img.putdata(nd)
        qr_img = qr_img.resize((400,400))
        tw,_ = template.size; qw,_ = qr_img.size
        template.paste(qr_img, ((tw-qw)//2, 1050), qr_img)

        buf = _img_to_bytes(template)
        client.send_image(image_data=buf.read(), thread_id=thread_id,
                          caption=f"🎫 Vé máy bay điện tử\n👤 {data['ten']}\n🆔 Booking: {data['booking_code']}\n✈️ {data['chuyen_bay']}\n📍 {data['tu']} ({data['from']}) → {data['den']} ({data['to']})\n📅 {data['ngay_bay']} | Ghế: {data['ghe']}")
    except Exception as e:
        client.send_message(text=f"❌ Lỗi /ve: {e}", thread_id=thread_id)

# =======================================================================
# ===== HÀM CHÍNH =====
def main():
    global OWNER_UID, reoten_active, reoten_info, bot_start_time, ACTIVE_ATTACKS
    global WELCOME_MSG, GOODBYE_MSG, BATICON_ACTIVE, BOT_ENABLED, active_boxes
    global AUTO_REACT_ENABLED, AUTO_REACT_EMOJI, NATURAL_REPLY_BOXES, CHAT_HISTORY

    banner()
    print("Nhập Cookie Bot:")
    cookie = input("> ").strip()
    if not cookie:
        print("Cookie không được để trống")
        return

    print("\nNhập UID Admin (chủ bot):")
    admin_uid = input("> ").strip()
    if not admin_uid:
        print("UID Admin không được để trống")
        return
    OWNER_UID = admin_uid

    print("\n💡 Bot sẽ tự hoạt động ở bất kỳ box nào khi ai đó gõ /menu")
    print("   Bạn có thể giới hạn box nào bot hoạt động bằng cách nhập ID bên dưới.")
    print("   Để trống = Bot hoạt động toàn bộ box (mở):")
    box_input = input("> ").strip()
    if box_input:
        for x in box_input.split(','):
            x = x.strip()
            if x:
                active_boxes.add(x)
        print(f"✅ Giới hạn hoạt động trong {len(active_boxes)} box")
    else:
        print("✅ Bot sẽ hoạt động ở tất cả các box (chế độ mở)")

    try:
        client = FacebookMQTTAllInOne(cookie)
        bot_uid = client.user_id
        client.connect()

        if hasattr(client, 'set_member_event_callback'):
            def member_cb(event):
                on_member_event(client, event)
            client.set_member_event_callback(member_cb)
            print("✅ Đã kích hoạt tính năng chào/tạm biệt thành viên")
        else:
            print("⚠️ fb.py chưa hỗ trợ sự kiện thành viên.")

        print(f"\n✅ Bot đã chạy thành công! UID: {bot_uid}")
        print("🤖 Gõ /menu trong bất kỳ box nào để kích hoạt bot ở box đó\n")

        def on_message(message_event):
            global reoten_active, reoten_info, ACTIVE_ATTACKS, BATICON_ACTIVE, BOT_ENABLED, WELCOME_MSG, GOODBYE_MSG
            global AUTO_REACT_ENABLED, AUTO_REACT_EMOJI, active_boxes, NATURAL_REPLY_BOXES, CHAT_HISTORY

            thread_id = message_event.get("thread_id")
            sender_id = message_event.get("sender_id")
            message_id = message_event.get("message_id")
            body = message_event.get("body", "").strip()

            if not thread_id or not sender_id:
                return
            if sender_id == bot_uid:
                return
            if not body:
                return

            # ── Xác định box đang hoạt động ──────────────────────────────────
            # Nếu có giới hạn box → chỉ xử lý trong đó
            # Nếu không giới hạn → /menu sẽ kích hoạt box này
            if active_boxes and thread_id not in active_boxes:
                return

            cmd = body.split()[0].lower()
            full_args = body[len(cmd):].strip()
            args = full_args.split() if full_args else []

            # ── Kiểm tra bot on/off ──────────────────────────────────────────
            # Khi bot OFF chỉ admin mới dùng /bot on để bật lại
            if not BOT_ENABLED.get(thread_id, True):
                if cmd == "/bot" and full_args.lower() == "on" and is_admin(sender_id):
                    BOT_ENABLED[thread_id] = True
                    client.send_message(text="✅ Bot đã được BẬT.", thread_id=thread_id)
                return

            # ── Phát hiện @mention bot → trả lời tự nhiên nếu đang bật ──────
            if NATURAL_REPLY_BOXES.get(thread_id):
                mentions = message_event.get("mentions", []) or []
                bot_was_mentioned = any(
                    str(m.get("id", "")) == str(bot_uid) for m in mentions
                )
                # Fallback 1: @bot_uid trong body
                if not bot_was_mentioned and (f"@{bot_uid}" in body):
                    bot_was_mentioned = True
                # Fallback 2: @TênBot trong body (FB gửi @TênHiểnThị)
                if not bot_was_mentioned:
                    try:
                        bot_info = client.get_user_info(bot_uid)
                        bot_name = bot_info.get("name", "") if bot_info and bot_info.get("success") else ""
                        if bot_name and f"@{bot_name}" in body:
                            bot_was_mentioned = True
                    except:
                        pass
                # Fallback 3: không phải lệnh / → coi như nhắn chuyện bình thường
                if not bot_was_mentioned and not body.startswith("/"):
                    bot_was_mentioned = True

                if bot_was_mentioned:
                    try:
                        info = client.get_user_info(sender_id)
                        sender_name = info.get("name") if info and info.get("success") else None
                    except:
                        sender_name = None
                    clean_body = re.sub(r'@\S+', '', body).strip()
                    if not clean_body:
                        clean_body = "alo"
                    threading.Thread(
                        target=_natural_reply_async,
                        args=(client, thread_id, clean_body, sender_name),
                        daemon=True
                    ).start()
                    return

            # /menu kích hoạt box tự động
            if cmd == "/menu":
                active_boxes.add(thread_id)  # tự đăng ký box này
                client.send_message(text=get_menu(), thread_id=thread_id)
                return

            # Chỉ xử lý lệnh trong box đã được kích hoạt
            if thread_id not in active_boxes:
                return

            # Tính năng tự động reaction cho admin
            if AUTO_REACT_ENABLED and is_admin(sender_id) and message_id:
                try:
                    send_reaction(client, AUTO_REACT_EMOJI, thread_id, message_id)
                except Exception as e:
                    print(f"Auto-react error: {e}")

            # Kiểm tra mute
            if is_muted(sender_id) and not is_admin(sender_id):
                return

            # ── /bot on | /bot off ───────────────────────────────────────────
            if cmd == "/bot":
                if not is_admin(sender_id):
                    client.send_message(text="⛔ Chỉ admin mới dùng được lệnh này.", thread_id=thread_id)
                    return
                sub = full_args.lower().strip()
                if sub == "on":
                    BOT_ENABLED[thread_id] = True
                    client.send_message(text="✅ Bot đã được BẬT trong box này.", thread_id=thread_id)
                elif sub == "off":
                    BOT_ENABLED[thread_id] = False
                    client.send_message(text="🔴 Bot đã TẮT. Dùng /bot on để bật lại.", thread_id=thread_id)
                else:
                    status = "BẬT ✅" if BOT_ENABLED.get(thread_id, True) else "TẮT 🔴"
                    client.send_message(
                        text=f"ℹ️ Trạng thái bot: {status}\nDùng /bot on hoặc /bot off",
                        thread_id=thread_id,
                    )
                return

            # ────────────────────────────────────────────────────────────────
            # LỆNH KHÔNG CẦN QUYỀN ADMIN
            # ────────────────────────────────────────────────────────────────

            if cmd == "/id":
                client.send_message(text=f"🆔 ID của bạn: {sender_id}", thread_id=thread_id)
                return

            if cmd == "/idroom":
                client.send_message(text=f"📍 ID phòng: {thread_id}", thread_id=thread_id)
                return

            if cmd == "/idadmin":
                client.send_message(text=f"👑 Admin chính: {OWNER_UID}", thread_id=thread_id)
                return

            if cmd == "/uidbox":
                if not args:
                    client.send_message(text="❗ Nhập link box", thread_id=thread_id)
                else:
                    m = re.search(r'facebook\.com/groups/(\d+)', args[0]) or re.search(r'facebook\.com/messages/t/(\d+)', args[0])
                    if m:
                        client.send_message(text=f"UID box: {m.group(1)}", thread_id=thread_id)
                    else:
                        client.send_message(text="❌ Không tìm thấy ID trong link", thread_id=thread_id)
                return

            if cmd == "/uptime":
                client.send_message(text=f"⏰ Bot đã hoạt động được: {get_uptime()}", thread_id=thread_id)
                return

            if cmd == "/ai":
                if not full_args:
                    client.send_message(text="❗ Dùng: /ai <câu hỏi>", thread_id=thread_id)
                else:
                    client.send_message(text="⏳ Đang hỏi AI...", thread_id=thread_id)
                    answer = call_openrouter(full_args)
                    client.send_message(text=f"🤖 {answer}", thread_id=thread_id)
                return

            if cmd == "/traloitunhien":
                if not args:
                    status = "🟢 Đang BẬT" if NATURAL_REPLY_BOXES.get(thread_id) else "🔴 Đang TẮT"
                    client.send_message(
                        text=f"❗ Dùng: /traloitunhien <on|off>\nTrạng thái hiện tại: {status}",
                        thread_id=thread_id
                    )
                    return
                state = args[0].lower()
                if state == "on":
                    NATURAL_REPLY_BOXES[thread_id] = True
                    if thread_id not in CHAT_HISTORY:
                        CHAT_HISTORY[thread_id] = []
                    client.send_message(
                        text="✅ Đã bật chế độ trả lời tự nhiên\n💬 Bot sẽ reply như người thật khi bị @mention",
                        thread_id=thread_id
                    )
                elif state == "off":
                    NATURAL_REPLY_BOXES[thread_id] = False
                    CHAT_HISTORY.pop(thread_id, None)
                    client.send_message(text="❌ Đã tắt chế độ trả lời tự nhiên", thread_id=thread_id)
                else:
                    client.send_message(text="❗ Dùng: /traloitunhien <on|off>", thread_id=thread_id)
                return

            if cmd == "/scan":
                info = client.get_thread_info(thread_id)
                if isinstance(info, dict) and "nameThread" in info:
                    msg = (
                        f"📊 Thông tin nhóm:\n"
                        f"- Tên: {info.get('nameThread', 'N/A')}\n"
                        f"- ID: {info.get('IDThread', 'N/A')}\n"
                        f"- Thành viên: {info.get('memberCount', 'N/A')}\n"
                        f"- Admin: {info.get('adminThreadCount', 'N/A')}\n"
                        f"- Duyệt thành viên: {info.get('approvalMode', 'N/A')}\n"
                        f"- Link tham gia: {info.get('joinableMode', 'N/A')}"
                    )
                    client.send_message(text=msg, thread_id=thread_id)
                else:
                    client.send_message(text="❌ Không thể quét thông tin nhóm", thread_id=thread_id)
                return

            if cmd == "/listtv":
                result = client.get_thread_members(thread_id)
                if result.get("success"):
                    members = result.get("members", [])
                    total = len(members)
                    msg = f"📋 DANH SÁCH THÀNH VIÊN ({total} người)\n{'═'*30}\n"
                    for i, m in enumerate(members, 1):
                        gender_str = "Nam 👨" if m.get('gender') == "MALE" else ("Nữ 👩" if m.get('gender') == "FEMALE" else "Không rõ")
                        msg += f"{i}. {m.get('name', 'Không tên')}\n   UID: {m.get('userID', '')}\n   Giới tính: {gender_str}\n\n"
                        if len(msg) > 1900:
                            client.send_message(text=msg, thread_id=thread_id)
                            msg = ""
                            time.sleep(1)
                    if msg.strip():
                        client.send_message(text=msg, thread_id=thread_id)
                else:
                    client.send_message(text=f"❌ Lỗi: {result.get('error', 'Không thể lấy danh sách')}", thread_id=thread_id)
                return

            if cmd == "/listtheme":
                theme_list = "🎨 Danh sách theme:\n"
                for i, t in enumerate(THEMES, 1):
                    theme_list += f"{i:2d}. {t['name']}\n"
                    if len(theme_list) > 1900:
                        client.send_message(text=theme_list, thread_id=thread_id)
                        theme_list = ""
                        time.sleep(0.5)
                if theme_list.strip():
                    client.send_message(text=theme_list, thread_id=thread_id)
                return

            # ────────────────────────────────────────────────────────────────
            # LỆNH YÊU CẦU QUYỀN ADMIN
            # ────────────────────────────────────────────────────────────────
            if not is_admin(sender_id):
                client.send_message(text="⛔ Bạn không có quyền sử dụng lệnh này", thread_id=thread_id)
                return

            # ── Quản lý admin ────────────────────────────────────────────────
            if cmd == "/addadmin":
                if len(args) < 2:
                    client.send_message(text="❗ Dùng: /addadmin <ID> <30d>", thread_id=thread_id)
                    return
                uid, dur = args[0], args[1]
                ok, err = add_admin(uid, dur)
                client.send_message(text=f"✅ Đã thêm admin {uid} ({dur})" if ok else f"❌ {err}", thread_id=thread_id)
                return

            if cmd == "/xoaadmin":
                if not args:
                    client.send_message(text="❗ Dùng: /xoaadmin <ID>", thread_id=thread_id)
                else:
                    ok = remove_admin(args[0])
                    client.send_message(text=f"✅ Đã xoá admin {args[0]}" if ok else "❌ Không tìm thấy admin", thread_id=thread_id)
                return

            # ── Mute/Unmute ──────────────────────────────────────────────────
            if cmd == "/mute":
                if not args:
                    client.send_message(text="❗ Dùng /mute @uid", thread_id=thread_id)
                else:
                    uid = args[0].lstrip('@')
                    muted = load_muted()
                    if uid in muted:
                        client.send_message(text="⚠️ Người này đã bị mute", thread_id=thread_id)
                    else:
                        muted.add(uid)
                        save_muted(muted)
                        client.send_message(text=f"🔇 Đã mute {uid}", thread_id=thread_id)
                return

            if cmd == "/unmute":
                if not args:
                    client.send_message(text="❗ Dùng /unmute @uid", thread_id=thread_id)
                else:
                    uid = args[0].lstrip('@')
                    muted = load_muted()
                    if uid in muted:
                        muted.remove(uid)
                        save_muted(muted)
                        client.send_message(text=f"🔊 Đã bỏ mute {uid}", thread_id=thread_id)
                    else:
                        client.send_message(text="⚠️ Người này không có trong danh sách mute", thread_id=thread_id)
                return

            # ── Kick ─────────────────────────────────────────────────────────
            if cmd == "/kick":
                if not args:
                    client.send_message(text="❗ Dùng /kick @uid", thread_id=thread_id)
                else:
                    uid = args[0].lstrip('@')
                    try:
                        resp = kick_user(client, uid, thread_id)
                        if resp.status_code == 200:
                            client.send_message(text=f"👢 Đã kick {uid}", thread_id=thread_id)
                        else:
                            client.send_message(text=f"❌ Lỗi kick HTTP {resp.status_code}", thread_id=thread_id)
                    except Exception as e:
                        client.send_message(text=f"❌ Lỗi: {e}", thread_id=thread_id)
                return

            # ── Thêm thành viên ──────────────────────────────────────────────
            if cmd == "/adduser":
                if not args:
                    client.send_message(text="❗ Dùng: /adduser <uid> [uid2] ...", thread_id=thread_id)
                else:
                    uids = [a.lstrip('@') for a in args]
                    result = client.add_user_to_group(uids, thread_id)
                    if result.get("success"):
                        client.send_message(text=f"✅ Đã thêm {len(uids)} thành viên vào nhóm", thread_id=thread_id)
                    else:
                        client.send_message(text=f"❌ Lỗi: {result.get('error', 'unknown')}", thread_id=thread_id)
                return

            # ── Đặt / gỡ admin nhóm ─────────────────────────────────────────
            if cmd == "/setadmin":
                if not args:
                    client.send_message(text="❗ Dùng: /setadmin <uid>", thread_id=thread_id)
                else:
                    uid = args[0].lstrip('@')
                    result = client.set_admin(uid, thread_id, is_admin=True)
                    client.send_message(
                        text=f"👑 Đã đặt admin cho {uid}" if result.get("success") else f"❌ Lỗi: {result.get('error')}",
                        thread_id=thread_id
                    )
                return

            if cmd == "/removeadmin":
                if not args:
                    client.send_message(text="❗ Dùng: /removeadmin <uid>", thread_id=thread_id)
                else:
                    uid = args[0].lstrip('@')
                    result = client.set_admin(uid, thread_id, is_admin=False)
                    client.send_message(
                        text=f"✅ Đã gỡ quyền admin của {uid}" if result.get("success") else f"❌ Lỗi: {result.get('error')}",
                        thread_id=thread_id
                    )
                return

            # ── Đổi tên nhóm ────────────────────────────────────────────────
            if cmd == "/setname":
                if not full_args:
                    client.send_message(text="❗ Dùng: /setname <tên mới>", thread_id=thread_id)
                else:
                    try:
                        resp = client.rename_group(full_args, thread_id)
                        if resp.get("success"):
                            client.send_message(text=f"✅ Đã đổi tên nhóm thành: {full_args}", thread_id=thread_id)
                        else:
                            client.send_message(text=f"❌ Lỗi: {resp.get('error', 'unknown')}", thread_id=thread_id)
                    except Exception as e:
                        client.send_message(text=f"❌ Lỗi: {e}", thread_id=thread_id)
                return

            # ── Đổi theme ────────────────────────────────────────────────────
            if cmd == "/theme":
                try:
                    if not full_args or full_args.lower() == "random":
                        theme_id = client.set_theme(thread_id)
                        theme_name = next((t["name"] for t in THEMES if t["id"] == theme_id), theme_id)
                        client.send_message(text=f"🎨 Đã đặt theme ngẫu nhiên: {theme_name}", thread_id=thread_id)
                    else:
                        theme_id = client.set_theme(thread_id, theme_name=full_args)
                        client.send_message(text=f"🎨 Đã đặt theme: {full_args}", thread_id=thread_id)
                except ValueError as e:
                    client.send_message(text=f"❌ {e}\nDùng /listtheme để xem danh sách", thread_id=thread_id)
                except Exception as e:
                    client.send_message(text=f"❌ Lỗi: {e}", thread_id=thread_id)
                return

            # ── Đổi ảnh nhóm ────────────────────────────────────────────────
            if cmd == "/seticon":
                if not full_args:
                    client.send_message(text="❗ Dùng: /seticon <url hoặc đường dẫn ảnh>", thread_id=thread_id)
                else:
                    client.send_message(text="⏳ Đang upload ảnh...", thread_id=thread_id)
                    result = client.set_group_image(full_args, thread_id)
                    if result.get("success"):
                        client.send_message(text="🖼️ Đã đổi ảnh nhóm thành công!", thread_id=thread_id)
                    else:
                        client.send_message(text=f"❌ Lỗi: {result.get('error')}", thread_id=thread_id)
                return

            # ── Đổi emoji nhóm ──────────────────────────────────────────────
            if cmd == "/setemoji":
                if not full_args:
                    client.send_message(text="❗ Dùng: /setemoji <emoji>", thread_id=thread_id)
                else:
                    result = client.set_emoji(full_args.strip(), thread_id)
                    if result.get("success"):
                        client.send_message(text=f"😀 Đã đặt emoji nhóm: {full_args.strip()}", thread_id=thread_id)
                    else:
                        client.send_message(text=f"❌ Lỗi: {result.get('error')}", thread_id=thread_id)
                return

            # ── Đổi nickname ─────────────────────────────────────────────────
            if cmd == "/nick":
                if len(args) < 2:
                    client.send_message(text="❗ Dùng: /nick <uid> <biệt danh mới>", thread_id=thread_id)
                else:
                    uid = args[0].lstrip('@')
                    nick = " ".join(args[1:])
                    result = client.change_nickname(nick, uid, thread_id)
                    if result.get("success"):
                        client.send_message(text=f"📝 Đã đổi biệt danh của {uid} thành: {nick}", thread_id=thread_id)
                    else:
                        client.send_message(text=f"❌ Lỗi: {result.get('error')}", thread_id=thread_id)
                return

            # ── Bật/tắt duyệt thành viên ────────────────────────────────────
            if cmd == "/camguilink":
                try:
                    resp = toggle_link_sharing(client, thread_id, disable=True)
                    if resp.status_code == 200:
                        client.send_message(text="🔒 Đã bật chế độ duyệt thành viên cho nhóm", thread_id=thread_id)
                    else:
                        client.send_message(text=f"❌ Lỗi HTTP {resp.status_code}", thread_id=thread_id)
                except Exception as e:
                    client.send_message(text=f"❌ Lỗi: {e}", thread_id=thread_id)
                return

            # ── Poll ─────────────────────────────────────────────────────────
            if cmd == "/poll":
                # Cú pháp: /poll câu hỏi | lựa chọn1 | lựa chọn2 | ...
                if "|" not in full_args:
                    client.send_message(text="❗ Dùng: /poll <câu hỏi> | <lựa chọn1> | <lựa chọn2> | ...", thread_id=thread_id)
                else:
                    parts = [p.strip() for p in full_args.split("|")]
                    question = parts[0]
                    options = [p for p in parts[1:] if p]
                    if len(options) < 2:
                        client.send_message(text="❗ Cần ít nhất 2 lựa chọn", thread_id=thread_id)
                    else:
                        result = client.send_poll(thread_id, question, options)
                        if not result:
                            client.send_message(text="❌ Không thể tạo poll", thread_id=thread_id)
                return

            # ── Share link ───────────────────────────────────────────────────
            if cmd == "/sharelink":
                if not args:
                    client.send_message(text="❗ Dùng: /sharelink <url> [text kèm theo]", thread_id=thread_id)
                else:
                    url = args[0]
                    text = " ".join(args[1:]) if len(args) > 1 else ""
                    result = client.share_link(url, thread_id, text)
                    if not result:
                        client.send_message(text="❌ Không thể chia sẻ link", thread_id=thread_id)
                return

            # ── Typing indicator ─────────────────────────────────────────────
            if cmd == "/typing":
                if not args:
                    client.send_message(text="❗ Dùng: /typing <on|off>", thread_id=thread_id)
                else:
                    state = args[0].lower()
                    if state == "on":
                        threading.Thread(
                            target=client.send_typing_burst,
                            args=(thread_id, 20, 2.0),
                            daemon=True
                        ).start()
                        client.send_message(text="⌨️ Đã bật typing indicator", thread_id=thread_id)
                    else:
                        client.send_typing_indicator(thread_id, False)
                        client.send_message(text="✅ Đã tắt typing", thread_id=thread_id)
                return

            # ── Stop tấn công ────────────────────────────────────────────────
            if cmd == "/stop":
                target = args[0] if args else None
                if target:
                    if target in ACTIVE_ATTACKS:
                        ACTIVE_ATTACKS[target].set()
                        client.send_message(text=f"🛑 Đã dừng tấn công vào box {target}", thread_id=thread_id)
                    else:
                        client.send_message(text="❌ Không có tấn công nào trong box này", thread_id=thread_id)
                else:
                    stop_attack()
                    reoten_active = False
                    client.send_message(text="🛑 Đã dừng toàn bộ tấn công", thread_id=thread_id)
                return

            # ── Réo tên ──────────────────────────────────────────────────────
            if cmd == "/stopreoten":
                if reoten_active:
                    reoten_active = False
                    client.send_message(text="✅ Đã dừng spam réo tên!", thread_id=thread_id)
                else:
                    client.send_message(text="❌ Không có tiến trình réo tên nào!", thread_id=thread_id)
                return

            if cmd == "/reoten":
                if reoten_active:
                    client.send_message(text="⚠️ Đang có tiến trình réo tên! Dùng /stopreoten trước.", thread_id=thread_id)
                    return
                if len(args) < 2:
                    client.send_message(text="❗ Dùng: /reoten <tên> <delay>", thread_id=thread_id)
                    return
                try:
                    user_name = args[0]
                    delay = max(0.5, float(args[1]))
                    lines = load_reoten_content()
                    reoten_active = True
                    reoten_info = {'uid': sender_id}
                    client.send_message(text=f"✅ Spam réo tên {user_name} delay {delay}s", thread_id=thread_id)
                    threading.Thread(
                        target=send_mention_messages,
                        args=(client, thread_id, user_name, lines, delay, sender_id),
                        daemon=True
                    ).start()
                except:
                    client.send_message(text="❗ Lỗi cú pháp", thread_id=thread_id)
                return

            # ── N2 ───────────────────────────────────────────────────────────
            if cmd == "/n2":
                if len(args) < 3:
                    client.send_message(text="❗ Dùng: /n2 <delay> <idbox> <tên>", thread_id=thread_id)
                else:
                    try:
                        delay = float(args[0])
                        target_box = args[1]
                        name = args[2]
                        lines = read_lines("n2.txt", [f"{name} ơi", f"alo {name}", f"{name} đâu rồi"])
                        stop_evt = threading.Event()
                        ACTIVE_ATTACKS[target_box] = stop_evt
                        threading.Thread(target=spam_worker, args=(client, target_box, lines, delay, stop_evt, {"{ten}": name}), daemon=True).start()
                        client.send_message(text=f"🔥 Bắt đầu n2 tới {target_box} delay {delay}s", thread_id=thread_id)
                    except:
                        client.send_message(text="❗ Sai cú pháp", thread_id=thread_id)
                return

            # ── Spam boxfull ─────────────────────────────────────────────────
            if cmd == "/spamboxfull":
                if not args:
                    client.send_message(text="❗ Dùng: /spamboxfull <id/link> [delay]", thread_id=thread_id)
                else:
                    target = args[0]
                    delay = float(args[1]) if len(args) > 1 else 1.0
                    lines = read_lines("spam.txt", ["spam1", "spam2"])
                    stop_evt = threading.Event()
                    ACTIVE_ATTACKS[target] = stop_evt
                    threading.Thread(target=spam_worker, args=(client, target, lines, delay, stop_evt), daemon=True).start()
                    client.send_message(text=f"📤 Spam boxfull vào {target}", thread_id=thread_id)
                return

            # ── Warbox ───────────────────────────────────────────────────────
            if cmd == "/warbox":
                if len(args) < 2:
                    client.send_message(text="❗ Dùng: /warbox <delay> <id/link>", thread_id=thread_id)
                else:
                    delay = float(args[0])
                    target = args[1]
                    lines = read_lines("nhay.txt", ["war1", "war2"])
                    stop_evt = threading.Event()
                    ACTIVE_ATTACKS[target] = stop_evt
                    threading.Thread(target=spam_worker, args=(client, target, lines, delay, stop_evt), daemon=True).start()
                    client.send_message(text=f"⚔️ War vào {target}", thread_id=thread_id)
                return

            # ── War trong box hiện tại ───────────────────────────────────────
            if cmd == "/war":
                if len(args) < 1:
                    client.send_message(text="❗ Dùng: /war <delay> [@uid]", thread_id=thread_id)
                else:
                    delay = float(args[0])
                    mention_uid = args[1].lstrip('@') if len(args) > 1 else None
                    lines = read_lines("nhay.txt", ["war1", "war2"])
                    stop_evt = threading.Event()
                    ACTIVE_ATTACKS[thread_id] = stop_evt
                    threading.Thread(target=spam_worker, args=(client, thread_id, lines, delay, stop_evt, None, mention_uid), daemon=True).start()
                    client.send_message(text=f"⚔️ War trong box, delay {delay}s", thread_id=thread_id)
                return

            # ── Wartag ───────────────────────────────────────────────────────
            if cmd == "/wartag":
                # Bước 1: /wartag <delay> → bot hỏi reply vào tin nhắn người muốn tag
                # Bước 2: user reply tin nhắn bất kỳ của người đó → bot lấy reply_to_sender_id
                if not args:
                    client.send_message(
                        text="❗ Dùng: /wartag <delay>\nVí dụ: /wartag 1\nSau đó REPLY vào tin nhắn của người muốn tag để bắt đầu",
                        thread_id=thread_id
                    )
                else:
                    try:
                        delay = max(0.5, float(args[0]))
                        WARTAG_PENDING[thread_id] = {"delay": delay, "sender_id": sender_id}
                        client.send_message(
                            text=f"⏳ Đã ghi nhận delay {delay}s\n👉 Bây giờ hãy REPLY vào bất kỳ tin nhắn nào của người bạn muốn tag để bắt đầu wartag",
                            thread_id=thread_id
                        )
                    except ValueError:
                        client.send_message(text="❗ Delay phải là số. Dùng: /wartag <delay>", thread_id=thread_id)
                return

            # ── Xử lý reply để kích hoạt wartag đang pending ─────────────────
            reply_to_sender = message_event.get("reply_to_sender_id")
            if reply_to_sender and thread_id in WARTAG_PENDING:
                pending = WARTAG_PENDING.pop(thread_id)
                # Chỉ người đã gõ /wartag mới được kích hoạt
                if sender_id == pending["sender_id"]:
                    delay = pending["delay"]
                    mention_uid = reply_to_sender
                    if mention_uid == bot_uid:
                        client.send_message(text="❌ Không thể tag chính bot", thread_id=thread_id)
                        return
                    lines = read_lines("nhay.txt", ["alo", "ơi", "đâu rồi", "rep đi"])
                    stop_evt = threading.Event()
                    ACTIVE_ATTACKS[thread_id] = stop_evt
                    threading.Thread(
                        target=wartag_worker,
                        args=(client, thread_id, lines, delay, stop_evt, mention_uid),
                        daemon=True
                    ).start()
                    client.send_message(
                        text=f"🏷️ Bắt đầu wartag (UID: {mention_uid}), delay {delay}s\nDùng /stop để dừng",
                        thread_id=thread_id
                    )
                    return

            # ── Spam SMS ─────────────────────────────────────────────────────
            if cmd == "/spamsms":
                if len(args) < 2:
                    client.send_message(text="❗ Dùng: /spamsms <sđt> <số_lần>", thread_id=thread_id)
                else:
                    msg = sms_spam(args[0], int(args[1]))
                    client.send_message(text=msg, thread_id=thread_id)
                return

            # ── Join box ─────────────────────────────────────────────────────
            if cmd == "/join":
                if not args:
                    client.send_message(text="❗ Dùng: /join <link>", thread_id=thread_id)
                else:
                    ok, msg = join_group_via_link(args[0], client)
                    client.send_message(text=msg, thread_id=thread_id)
                return

            # ── Baticon ──────────────────────────────────────────────────────
            if cmd == "/baticon":
                if BATICON_ACTIVE:
                    client.send_message(text="⚠️ Baticon đang chạy. Dùng /stopbaticon để dừng.", thread_id=thread_id)
                    return
                if not args:
                    client.send_message(text="❗ Dùng: /baticon <delay_giây>", thread_id=thread_id)
                    return
                try:
                    delay = max(5.0, float(args[0]))
                    BATICON_ACTIVE = True
                    threading.Thread(target=baticon_worker, args=(client, thread_id, delay), daemon=True).start()
                    client.send_message(text=f"🎨 Baticon đã bắt đầu, đổi icon mỗi {delay}s", thread_id=thread_id)
                except:
                    client.send_message(text="❗ Sai delay", thread_id=thread_id)
                return

            if cmd == "/stopbaticon":
                if BATICON_ACTIVE:
                    BATICON_ACTIVE = False
                    client.send_message(text="🛑 Đã dừng baticon", thread_id=thread_id)
                else:
                    client.send_message(text="❌ Baticon chưa chạy", thread_id=thread_id)
                return

            # ── Setwelcome / Setgoodbye ──────────────────────────────────────
            if cmd == "/setwelcome":
                if not full_args:
                    client.send_message(text="❗ Dùng: /setwelcome <tin nhắn> (dùng {name} để chèn tên)", thread_id=thread_id)
                else:
                    WELCOME_MSG = full_args
                    client.send_message(text="✅ Đã lưu tin nhắn chào mừng", thread_id=thread_id)
                return

            if cmd == "/setgoodbye":
                if not full_args:
                    client.send_message(text="❗ Dùng: /setgoodbye <tin nhắn> (dùng {name} để chèn tên)", thread_id=thread_id)
                else:
                    GOODBYE_MSG = full_args
                    client.send_message(text="✅ Đã lưu tin nhắn tạm biệt", thread_id=thread_id)
                return

            # ── Autoreact ────────────────────────────────────────────────────
            if cmd == "/autoreact":
                if not args:
                    client.send_message(text="❗ Dùng: /autoreact <on|off|emoji>", thread_id=thread_id)
                    return
                state = args[0].lower()
                if state == "on":
                    AUTO_REACT_ENABLED = True
                    client.send_message(text=f"✅ Tự động reaction [{AUTO_REACT_EMOJI}] cho tin nhắn admin", thread_id=thread_id)
                elif state == "off":
                    AUTO_REACT_ENABLED = False
                    client.send_message(text="❌ Đã tắt tự động reaction", thread_id=thread_id)
                else:
                    AUTO_REACT_EMOJI = args[0]
                    AUTO_REACT_ENABLED = True
                    client.send_message(text=f"✅ Đặt reaction tự động là {args[0]} và bật", thread_id=thread_id)
                return

            # ── Lệnh không xác định ──────────────────────────────────────────

            # ── Tiện ích ─────────────────────────────────────────────────────
            if cmd == "/sun":
                threading.Thread(target=cmd_sun, args=(client, thread_id, full_args), daemon=True).start()
                return

            if cmd == "/voice":
                threading.Thread(target=cmd_voice, args=(client, thread_id, full_args), daemon=True).start()
                return

            if cmd == "/thoitiet":
                threading.Thread(target=cmd_thoitiet, args=(client, thread_id, full_args, _WEATHER_API_KEY), daemon=True).start()
                return

            # ── Fake bill MB Bank ─────────────────────────────────────────────
            if cmd == "/mbbank":
                cmd_mbbank(client, thread_id, full_args)
                return

            # ── Tải TikTok ───────────────────────────────────────────────────
            if cmd == "/downtt":
                cmd_downtt(client, thread_id, full_args)
                return

            # ── Lệnh không xác định ──────────────────────────────────────────
            client.send_message(text=f"❌ Lệnh không xác định: {cmd}\nDùng /menu để xem danh sách lệnh", thread_id=thread_id)

        client.set_message_callback(on_message)

        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print("\n\nĐã dừng bot")
        try:
            client.disconnect()
        except:
            pass
    except Exception as e:
        print(f"Lỗi: {e}")
        import traceback
        traceback.print_exc()

# ===== THÊM VÀO FILE BOTCHAT.PY (TRƯỚC HÀM MAIN) =====
# ===== THÊM HÀM CREATE_MESSAGE_HANDLER VÀO BOTCHAT.PY =====
def create_message_handler(client, bot_uid):
    """Tạo hàm xử lý tin nhắn với client và bot_uid đã được bind sẵn"""
    
    def on_message(message_event):
        global reoten_active, reoten_info, ACTIVE_ATTACKS, BATICON_ACTIVE
        global BOT_ENABLED, WELCOME_MSG, GOODBYE_MSG, AUTO_REACT_ENABLED, AUTO_REACT_EMOJI
        global NATURAL_REPLY_BOXES, CHAT_HISTORY, active_boxes, WARTAG_PENDING

        thread_id = message_event.get("thread_id")
        sender_id = message_event.get("sender_id")
        message_id = message_event.get("message_id")
        body = message_event.get("body", "").strip()
        reply_to_sender = message_event.get("reply_to_sender_id")

        if not thread_id or not sender_id or sender_id == bot_uid:
            return
        if not body:
            return

        # Giới hạn box hoạt động
        if active_boxes and thread_id not in active_boxes:
            return

        cmd = body.split()[0].lower() if body else ""
        full_args = body[len(cmd):].strip() if cmd else ""
        args = full_args.split() if full_args else []

        # Bật/tắt bot trong box
        if not BOT_ENABLED.get(thread_id, True):
            if cmd == f"{PREFIX}bot" and full_args.lower() == "on" and is_admin(sender_id):
                BOT_ENABLED[thread_id] = True
                client.send_message(text="✅ Bot đã được BẬT.", thread_id=thread_id)
            return

        # Trả lời tự nhiên khi bị mention
        if NATURAL_REPLY_BOXES.get(thread_id):
            mentions = message_event.get("mentions", []) or []
            bot_was_mentioned = any(str(m.get("id", "")) == str(bot_uid) for m in mentions)
            if not bot_was_mentioned and f"@{bot_uid}" in body:
                bot_was_mentioned = True
            if not bot_was_mentioned and not body.startswith(PREFIX):
                bot_was_mentioned = True
            if bot_was_mentioned:
                try:
                    info = client.get_user_info(sender_id)
                    sender_name = info.get("name") if info and info.get("success") else None
                except:
                    sender_name = None
                clean_body = re.sub(r'@\S+', '', body).strip()
                if not clean_body:
                    clean_body = "alo"
                reply = call_openrouter_natural(thread_id, clean_body, sender_name)
                if reply:
                    client.send_message(text=reply, thread_id=thread_id)
                return

        # Kích hoạt box bằng menu
        if cmd == f"{PREFIX}menu":
            active_boxes.add(thread_id)
            client.send_message(text=get_menu(), thread_id=thread_id)
            return

        if thread_id not in active_boxes:
            return

        # Auto reaction
        if AUTO_REACT_ENABLED and is_admin(sender_id) and message_id:
            try:
                send_reaction(client, AUTO_REACT_EMOJI, thread_id, message_id)
            except:
                pass

        if is_muted(sender_id) and not is_admin(sender_id):
            return

        # ========== LỆNH KHÔNG CẦN QUYỀN ==========
        if cmd == f"{PREFIX}id":
            client.send_message(text=f"🆔 ID của bạn: {sender_id}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}idroom":
            client.send_message(text=f"📍 ID phòng: {thread_id}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}idadmin":
            client.send_message(text=f"👑 Admin chính: {OWNER_UID}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}uidbox":
            if not args:
                client.send_message(text="❗ Nhập link box", thread_id=thread_id)
            else:
                m = re.search(r'facebook\.com/groups/(\d+)', args[0]) or re.search(r'facebook\.com/messages/t/(\d+)', args[0])
                client.send_message(text=f"UID box: {m.group(1)}" if m else "❌ Không tìm thấy ID", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}uptime":
            client.send_message(text=f"⏰ Bot đã chạy: {get_uptime()}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}ai":
            client.send_message(text="⏳ Đang hỏi AI...", thread_id=thread_id)
            answer = call_openrouter(full_args)
            client.send_message(text=f"🤖 {answer}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}scan":
            info = client.get_thread_info(thread_id)
            if isinstance(info, dict) and "nameThread" in info:
                msg = f"📊 Thông tin nhóm:\n- Tên: {info.get('nameThread')}\n- ID: {info.get('IDThread')}\n- Thành viên: {info.get('memberCount')}"
                client.send_message(text=msg, thread_id=thread_id)
            else:
                client.send_message(text="❌ Không thể quét thông tin", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}listtv":
            result = client.get_thread_members(thread_id)
            if result.get("success"):
                members = result.get("members", [])
                msg = f"📋 DANH SÁCH THÀNH VIÊN ({len(members)} người)\n"
                for i, m in enumerate(members[:30], 1):
                    gender = "👨" if m.get('gender') == "MALE" else ("👩" if m.get('gender') == "FEMALE" else "❓")
                    msg += f"{i}. {m.get('name', '?')} {gender} | `{m.get('userID')}`\n"
                client.send_message(text=msg if len(msg) < 2000 else msg[:1900] + "\n...", thread_id=thread_id)
            else:
                client.send_message(text=f"❌ Lỗi: {result.get('error')}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}listtheme":
            theme_list = "🎨 Danh sách theme:\n"
            for i, t in enumerate(THEMES[:30], 1):
                theme_list += f"{i}. {t['name']}\n"
            client.send_message(text=theme_list, thread_id=thread_id)
            return
        if cmd == f"{PREFIX}thoitiet":
            if not full_args:
                client.send_message(text="❗ Dùng: /thoitiet <tên thành phố>", thread_id=thread_id)
                return
            try:
                import urllib.parse
                city = urllib.parse.quote(full_args.strip())
                url = f"https://wttr.in/{city}?format=j1"
                r = requests.get(url, timeout=10)
                if r.status_code == 200:
                    data = r.json()
                    current = data["current_condition"][0]
                    temp = current["temp_C"]
                    feels = current["FeelsLikeC"]
                    humidity = current["humidity"]
                    weather = current["weatherDesc"][0]["value"]
                    msg = f"🌤️ THỜI TIẾT {full_args.upper()}\n🌡️ Nhiệt độ: {temp}°C (cảm giác {feels}°C)\n💧 Độ ẩm: {humidity}%\n🌫️ {weather}"
                    client.send_message(text=msg, thread_id=thread_id)
                else:
                    client.send_message(text="❌ Không lấy được thời tiết", thread_id=thread_id)
            except Exception as e:
                client.send_message(text=f"❌ Lỗi: {e}", thread_id=thread_id)
            return

        # ========== LỆNH CẦN QUYỀN ADMIN ==========
        if not is_admin(sender_id):
            client.send_message(text="⛔ Bạn không có quyền!", thread_id=thread_id)
            return

        if cmd == f"{PREFIX}addadmin":
            if len(args) < 2:
                client.send_message(text="❗ Dùng: /addadmin <ID> <30d>", thread_id=thread_id)
            else:
                ok, err = add_admin(args[0], args[1])
                client.send_message(text=f"✅ Đã thêm admin {args[0]}" if ok else f"❌ {err}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}xoaadmin":
            if not args:
                client.send_message(text="❗ Dùng: /xoaadmin <ID>", thread_id=thread_id)
            else:
                ok = remove_admin(args[0])
                client.send_message(text=f"✅ Đã xóa admin {args[0]}" if ok else "❌ Không tìm thấy", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}mute":
            if not args:
                client.send_message(text="❗ Dùng: /mute @uid", thread_id=thread_id)
            else:
                uid = args[0].lstrip('@')
                muted = load_muted()
                if uid in muted:
                    client.send_message(text="⚠️ Đã bị mute rồi", thread_id=thread_id)
                else:
                    muted.add(uid)
                    save_muted(muted)
                    client.send_message(text=f"🔇 Đã mute {uid}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}unmute":
            if not args:
                client.send_message(text="❗ Dùng: /unmute @uid", thread_id=thread_id)
            else:
                uid = args[0].lstrip('@')
                muted = load_muted()
                if uid in muted:
                    muted.remove(uid)
                    save_muted(muted)
                    client.send_message(text=f"🔊 Đã bỏ mute {uid}", thread_id=thread_id)
                else:
                    client.send_message(text="⚠️ Không có trong danh sách mute", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}kick":
            if not args:
                client.send_message(text="❗ Dùng: /kick @uid", thread_id=thread_id)
            else:
                uid = args[0].lstrip('@')
                try:
                    kick_user(client, uid, thread_id)
                    client.send_message(text=f"👢 Đã kick {uid}", thread_id=thread_id)
                except Exception as e:
                    client.send_message(text=f"❌ Lỗi: {e}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}setname":
            if not full_args:
                client.send_message(text="❗ Dùng: /setname <tên mới>", thread_id=thread_id)
            else:
                try:
                    client.rename_group(full_args, thread_id)
                    client.send_message(text=f"✅ Đã đổi tên thành: {full_args}", thread_id=thread_id)
                except Exception as e:
                    client.send_message(text=f"❌ Lỗi: {e}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}theme":
            try:
                if not full_args or full_args.lower() == "random":
                    theme_id = client.set_theme(thread_id)
                    client.send_message(text=f"🎨 Đã đặt theme ngẫu nhiên", thread_id=thread_id)
                else:
                    client.set_theme(thread_id, theme_name=full_args)
                    client.send_message(text=f"🎨 Đã set theme: {full_args}", thread_id=thread_id)
            except Exception as e:
                client.send_message(text=f"❌ {e}", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}join":
            if not args:
                client.send_message(text="❗ Dùng: /join <link>", thread_id=thread_id)
            else:
                ok, msg = join_group_via_link(args[0], client)
                client.send_message(text=msg, thread_id=thread_id)
            return
        if cmd == f"{PREFIX}poll":
            if "|" not in full_args:
                client.send_message(text="❗ Dùng: /poll <câu hỏi> | <opt1> | <opt2>", thread_id=thread_id)
            else:
                parts = [p.strip() for p in full_args.split("|")]
                question = parts[0]
                options = [p for p in parts[1:] if p]
                if len(options) >= 2:
                    client.send_poll(thread_id, question, options[:2])
                else:
                    client.send_message(text="❗ Cần ít nhất 2 lựa chọn", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}stop":
            target = args[0] if args else None
            if target and target in ACTIVE_ATTACKS:
                ACTIVE_ATTACKS[target].set()
                client.send_message(text=f"🛑 Đã dừng tấn công vào {target}", thread_id=thread_id)
            else:
                stop_attack()
                client.send_message(text="🛑 Đã dừng toàn bộ tấn công", thread_id=thread_id)
            return
        if cmd == f"{PREFIX}bot":
            if not args:
                status = "BẬT ✅" if BOT_ENABLED.get(thread_id, True) else "TẮT 🔴"
                client.send_message(text=f"ℹ️ Trạng thái bot: {status}\nDùng {PREFIX}bot on/off", thread_id=thread_id)
            elif args[0].lower() == "off":
                BOT_ENABLED[thread_id] = False
                client.send_message(text="🔴 Bot đã TẮT trong box này", thread_id=thread_id)
            elif args[0].lower() == "on":
                BOT_ENABLED[thread_id] = True
                client.send_message(text="✅ Bot đã BẬT", thread_id=thread_id)
            return

        # Xử lý reply để kích hoạt wartag pending
        if reply_to_sender and thread_id in WARTAG_PENDING:
            pending = WARTAG_PENDING.pop(thread_id)
            if sender_id == pending["sender_id"]:
                mention_uid = reply_to_sender
                if mention_uid == bot_uid:
                    client.send_message(text="❌ Không thể tag bot", thread_id=thread_id)
                    return
                lines = read_lines("nhay.txt", ["alo", "ơi", "đâu rồi"])
                stop_evt = threading.Event()
                ACTIVE_ATTACKS[thread_id] = stop_evt
                threading.Thread(target=wartag_worker, args=(client, thread_id, lines, pending["delay"], stop_evt, mention_uid), daemon=True).start()
                client.send_message(text=f"🏷️ Bắt đầu wartag UID: {mention_uid}, delay {pending['delay']}s", thread_id=thread_id)
                return

        if cmd and cmd.startswith(PREFIX):
            client.send_message(text=f"❌ Lệnh không xác định: {cmd}\nDùng {PREFIX}menu để xem danh sách", thread_id=thread_id)

    return on_message
# ===== THÊM VÀO CUỐI FILE BOTCHAT.PY =====
def run_bot(cookie, admin_uid, group_ids=None, prefix="/"):
    """Chạy bot chat Facebook Messenger"""
    global OWNER_UID, PREFIX, active_boxes, bot_start_time
    
    OWNER_UID = admin_uid
    PREFIX = prefix
    bot_start_time = datetime.now()
    
    if group_ids:
        active_boxes = set(group_ids)
        print(f"✅ Giới hạn hoạt động trong {len(active_boxes)} box")
    else:
        print("✅ Bot sẽ hoạt động ở tất cả các box")
    
    print(f"✅ Prefix: {PREFIX}")
    
    try:
        client = FacebookMQTTAllInOne(cookie)
        bot_uid = client.user_id
        client.connect()
        
        if hasattr(client, 'set_member_event_callback'):
            def member_cb(event):
                on_member_event(client, event)
            client.set_member_event_callback(member_cb)
        
        # Gán hàm xử lý tin nhắn
        client.set_message_callback(create_message_handler(client, bot_uid))
        
        print(f"\n✅ Bot đã chạy thành công!")
        print(f"👑 Admin: {OWNER_UID}")
        print(f"🤖 Bot UID: {bot_uid}")
        print(f"📌 Prefix: {PREFIX}")
        print(f"💡 Gõ {PREFIX}menu trong bất kỳ box nào để bắt đầu\n")
        
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n\nĐã dừng bot")
        try:
            client.disconnect()
        except:
            pass
    except Exception as e:
        print(f"Lỗi: {e}")
        import traceback
        traceback.print_exc()
# ===== HÀM MAIN ĐỂ TƯƠNG THÍCH VỚI BV9.PY =====
def main():
    """Hàm main để tương thích với bv9.py - chạy bot chat với input từ console"""
    banner()
    
    print("=" * 50)
    print("🤖 BOT CHAT FACEBOOK MESSENGER 🤖")
    print("=" * 50)
    
    cookie = input("📌 Nhập Cookie Facebook: ").strip()
    if not cookie:
        print("Cookie không được để trống!")
        return
    
    admin_uid = input("👑 Nhập UID Admin chính: ").strip()
    if not admin_uid:
        print("UID Admin không được để trống!")
        return
    
    prefix = input("⚙️ Nhập Prefix (mặc định /): ").strip()
    if not prefix:
        prefix = "/"
    
    box_input = input("📦 Nhập ID box để giới hạn (cách nhau dấu phẩy, để trống = tất cả): ").strip()
    group_ids = [x.strip() for x in box_input.split(',') if x.strip()] if box_input else None
    
    print("\n" + "=" * 50)
    print("🚀 ĐANG KHỞI ĐỘNG BOT...")
    print("=" * 50)
    
    # Chạy bot với đầy đủ tham số
    run_bot(cookie, admin_uid, group_ids, prefix)
if __name__ == "__main__":
    main()