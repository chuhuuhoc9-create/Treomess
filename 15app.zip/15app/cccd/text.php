<?php
ini_set('display_errors', 0);
error_reporting(0);

// --- Nhận dữ liệu GET ---
$socccd    = trim($_GET['socccd'] ?? '');
$name      = trim($_GET['name'] ?? '');
$birthday  = trim($_GET['birthday'] ?? '');
$sex       = trim($_GET['sex'] ?? '');
$quequan   = trim($_GET['quequan'] ?? '');
$thuongtru = trim($_GET['thuongtru'] ?? '');
$xomlang   = trim($_GET['xomlang'] ?? '');
$ngaycap   = trim($_GET['ngaycap'] ?? '');
$anhtheUrl = trim($_GET['anhthe'] ?? '');

if (!$socccd || !$name) {
    header('Content-Type: application/json');
    echo json_encode(['status'=>'error','msg'=>'Missing required fields']);
    exit;
}

// --- Đường dẫn tài nguyên ---
$baseDir      = __DIR__;
$fontBoldPath = $baseDir . '/SVN-Arial 3 bold.ttf';
$fontRegPath  = $baseDir . '/SVN-Arial Regular.ttf';
$bgBasePath   = $baseDir . '/fsdf.png';
$overlayPath  = $baseDir . '/mattruoc.png';
$backBasePath = $baseDir . '/matsau.png';
$fontMRZ      = $baseDir . '/font.ttf';

// Kiểm tra file cần thiết
foreach([$bgBasePath,$overlayPath,$backBasePath,$fontBoldPath,$fontRegPath,$fontMRZ] as $f){
    if(!is_file($f)){
        header('Content-Type: application/json');
        echo json_encode(['status'=>'error','msg'=>"Missing file: $f"]);
        exit;
    }
}

// --- Hàm vẽ chữ có hiệu ứng ---
function imagettftextSpWithEffects($image, $size, $angle, $x, $y, $text, $font,
    $textColor, $shadowColor, $shadowOffsetX = 0, $shadowOffsetY = 0, $outerGlowSize = 1, $spacing = 0){
    $w = imagesx($image); $h = imagesy($image);
    $temp = imagecreatetruecolor($w,$h);
    imagesavealpha($temp,true);
    $transparent = imagecolorallocatealpha($temp,0,0,0,127);
    imagefill($temp,0,0,$transparent);
    $txt  = imagecolorallocatealpha($temp,$textColor[0],$textColor[1],$textColor[2],$textColor[3]);
    $shad = imagecolorallocatealpha($temp,$shadowColor[0],$shadowColor[1],$shadowColor[2],$shadowColor[3]);
    if((int)$spacing===0){
        for($i=0;$i<$outerGlowSize;$i++){
            imagettftext($temp,$size,$angle,$x+$shadowOffsetX,$y+$shadowOffsetY,$shad,$font,$text);
        }
        imagettftext($temp,$size,$angle,$x,$y,$txt,$font,$text);
    } else {
        $temp_x = $x;
        $len = mb_strlen($text,'UTF-8');
        for($i=0;$i<$len;$i++){
            for($j=0;$j<$outerGlowSize;$j++){
                imagettftext($temp,$size,$angle,$temp_x+$shadowOffsetX,$y+$shadowOffsetY,$shad,$font,mb_substr($text,$i,1,'UTF-8'));
            }
            $bbox = imagettftext($temp,$size,$angle,$temp_x,$y,$txt,$font,mb_substr($text,$i,1,'UTF-8'));
            $temp_x += $spacing + ($bbox[2]-$bbox[0]);
        }
    }
    imagecopy($image,$temp,0,0,0,0,$w,$h);
    imagedestroy($temp);
}

// --- Mảng key chatbot ---
$keychatbot = [
    "709833da-2189-4a43-bf13-45ec0d46a5fc",
    "4ae5bf19-1c87-4042-8375-d53fee0da00b",
    "d2a7744c-9c37-48ac-8b5d-0a5f7bc6d314"
];

// --- Hàm upload Imgur qua API Kaiz ---
function upload_to_kaiz_imgur($image_data, $keychatbot){
    $tmpFile = tempnam(sys_get_temp_dir(), 'img');
    file_put_contents($tmpFile, $image_data);
    $api_key = $keychatbot[array_rand($keychatbot)];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://kaiz-apis.gleeze.com/api/imgur");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ['url'=>'file://'.$tmpFile,'apikey'=>$api_key]);
    $res = curl_exec($ch); curl_close($ch);
    unlink($tmpFile);
    $json = json_decode($res,true);
    return $json['uploaded']['image'] ?? null;
}

// -------------------- Ảnh MẶT TRƯỚC --------------------
$baseFront = imagecreatefrompng($bgBasePath);
$frontImg = imagecreatetruecolor(imagesx($baseFront), imagesy($baseFront));
imagesavealpha($frontImg,true);
$transparent = imagecolorallocatealpha($frontImg,0,0,0,127);
imagefill($frontImg,0,0,$transparent);
imagecopy($frontImg,$baseFront,0,0,0,0,imagesx($baseFront),imagesy($baseFront));
imagedestroy($baseFront);

$overlay = imagecreatefrompng($overlayPath);
imagecopy($frontImg,$overlay,0,0,0,0,imagesx($overlay),imagesy($overlay));
imagedestroy($overlay);

// QR
$qrPayload = $socccd.'||'.$name.'|'.str_replace('/','',$birthday).'|'.$sex.'|'.$thuongtru.'|'.str_replace('/','',$ngaycap);
$qrData = @file_get_contents('https://quickchart.io/qr?text='.urlencode($qrPayload).'&light=0000&ecLevel=Q&format=png&size=170');
if($qrData){ $qrImg=imagecreatefromstring($qrData); imagecopy($frontImg,$qrImg,1360,200,0,0,imagesx($qrImg),imagesy($qrImg)); imagedestroy($qrImg); }

// Text
$textColor=[0,0,0,20]; $shadowColor=[0,0,0,60];
imagettftextSpWithEffects($frontImg,40,0,845,535,$socccd,$fontBoldPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,31,0,725,630,mb_strtoupper($name,'UTF-8'),$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,1060,670,$birthday,$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,935,715,$sex,$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,1340,722,'Việt Nam',$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,725,810,$quequan,$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,725,900,$thuongtru,$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,1190,855,$xomlang,$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,18,0,555,875,$ngaycap,$fontRegPath,$textColor,$shadowColor);

// Ảnh thẻ
if($anhtheUrl){
    $photoData = @file_get_contents($anhtheUrl);
    if($photoData){
        $srcPhoto=@imagecreatefromstring($photoData);
        if($srcPhoto){
            $adj = imagecreatetruecolor(295,405);
            imagesavealpha($adj,true);
            imagefill($adj,0,0,imagecolorallocatealpha($adj,0,0,0,127));
            $sW=imagesx($srcPhoto); $sH=imagesy($srcPhoto);
            $srcAspect=$sW/$sH; $dstAspect=295/405;
            if($srcAspect>$dstAspect){$cropW=(int)($sH*$dstAspect); $cropX=(int)(($sW-$cropW)/2); imagecopyresampled($adj,$srcPhoto,0,0,$cropX,0,295,405,$cropW,$sH);}
            else{$cropH=(int)($sW/$dstAspect); $cropY=(int)(($sH-$cropH)/2); imagecopyresampled($adj,$srcPhoto,0,0,0,$cropY,295,405,$sW,$cropH);}
            imagecopy($frontImg,$adj,400,430,0,0,295,405); imagedestroy($adj); imagedestroy($srcPhoto);
        }
    }
}

// Lấy nhị phân
ob_start(); imagepng($frontImg); $front_img_data = ob_get_clean(); imagedestroy($frontImg);

// -------------------- Ảnh MẶT SAU --------------------
$baseBack = imagecreatefrompng($backBasePath);
$backImg = imagecreatetruecolor(imagesx($baseBack), imagesy($baseBack));
imagesavealpha($backImg,true);
imagefill($backImg,0,0,imagecolorallocatealpha($backImg,0,0,0,127));
imagecopy($backImg,$baseBack,0,0,0,0,imagesx($baseBack),imagesy($baseBack));
imagedestroy($baseBack);

// Font MRZ
$textColor=[0,0,0,0]; $shadowColor=[0,0,0,50];
imagettftextSpWithEffects($backImg,20,0,845,290,$ngaycap,$fontRegPath,$textColor,$shadowColor);

// Loại bỏ dấu tiếng Việt
function removeVietnameseAccents($str){$str=mb_strtoupper($str,'UTF-8'); $unicode=['A'=>'À|Á|Â|Ã|Ä|Å|Ă|Ā|Ą|Ạ|Ả|Ấ|Ầ|Ẩ|Ẫ|Ậ|Ắ|Ằ|Ẳ|Ẵ|Ặ','E'=>'È|É|Ê|Ë|Ē|Ę|Ẹ|Ẻ|Ẽ|Ế|Ề|Ể|Ễ|Ệ','I'=>'Ì|Í|Î|Ï|Ī|Ị|Ỉ|Ĩ','O'=>'Ò|Ó|Ô|Õ|Ö|Ø|Ō|Ọ|Ỏ|Ố|Ồ|Ổ|Ỗ|Ộ|Ớ|Ờ|Ở|Ỡ|Ợ','U'=>'Ù|Ú|Û|Ü|Ū|Ụ|Ủ|Ũ|Ứ|Ừ|Ử|Ữ|Ự','Y'=>'Ý|Ỳ|Ỷ|Ỹ|Ỵ','D'=>'Đ']; foreach($unicode as $non=>$pat)$str=preg_replace('/'.$pat.'/u',$non,$str); return preg_replace('/[^A-Z0-9 ]/','',$str);}

// MRZ
$fullnameMRZ=removeVietnameseAccents($name);
$parts=preg_split('/\s+/',$fullnameMRZ);
if(count($parts)>1){$lastname=array_shift($parts);$firstname=array_pop($parts);$midnames=$parts;$fullnameMRZ=$lastname.'<<'.implode('<',array_merge($midnames,[$firstname]));}
$fullnameMRZ=substr(str_pad($fullnameMRZ,39,'<'),0,39);

$mrzRaw=strtoupper('IDVNM'.substr($socccd,3).'1'.$socccd.'<<6'.rand(100000,999999).'F'.rand(10000000,99999999).'VNM<<<<<<<<<<<6'.$fullnameMRZ.'<<<<<<<<<<<<');
$mrzRaw=substr(str_pad($mrzRaw,90,'<'),0,90);
$mrzLines=str_split($mrzRaw,30);
$startY=720;$lineY=[$startY,$startY+55,$startY+110];$fontSize=45;
foreach($mrzLines as $i=>$line){
    $bbox=imagettfbbox($fontSize,0,$fontMRZ,$line);
    $centerX=(imagesx($backImg)-($bbox[2]-$bbox[0]))/2;
    imagettftextSpWithEffects($backImg,$fontSize,0,$centerX,$lineY[$i],$line,$fontMRZ,$textColor,$shadowColor,1,1,1);
}

// Lấy nhị phân
ob_start(); imagepng($backImg); $back_img_data = ob_get_clean(); imagedestroy($backImg);

// Upload lên Kaiz API
$front_url = upload_to_kaiz_imgur($front_img_data,$keychatbot);
$back_url  = upload_to_kaiz_imgur($back_img_data,$keychatbot);

// JSON phản hồi
header('Content-Type: application/json');
echo json_encode([
    'status'=>'success',
    'info'=>compact('socccd','name','birthday','sex','quequan','thuongtru','xomlang','ngaycap'),
    'front'=>$front_url,
    'back'=>$back_url
]);
exit;