<?php    
// Tắt hiển thị lỗi ra output để không phá header ảnh    
ini_set('display_errors', 0);    
error_reporting(0);    
  
if (!isset($_GET['name'])) {    
    http_response_code(400);    
    exit;    
}    
  
// --- Nhận dữ liệu GET & kiểm tra ---    
$socccd    = trim($_GET['socccd']    ?? '');    
$name      = trim($_GET['name']      ?? '');    
$birthday  = trim($_GET['birthday']  ?? '');    
$sex       = trim($_GET['sex']       ?? '');    
$quequan   = trim($_GET['quequan']   ?? '');    
$thuongtru = trim($_GET['thuongtru'] ?? '');
$xomlang   = trim($_GET['xomlang']   ?? '');      
$ngaycap   = trim($_GET['ngaycap']   ?? '');    
$anhtheUrl = trim($_GET['anhthe']    ?? '');    
  
if ($socccd === '' || $name === '' || $birthday === '' || $sex === '' || $quequan === '' || $thuongtru === '' || $xomlang === '' || $ngaycap === '' || $anhtheUrl === '') {    
    http_response_code(422);    
    exit;    
}    
  
// --- Đường dẫn tuyệt đối tài nguyên ---    
$baseDir      = __DIR__;    
$fontBoldPath = $baseDir . '/SVN-Arial 3 bold.ttf';    
$fontRegPath  = $baseDir . '/SVN-Arial Regular.ttf';    
$bgBasePath   = $baseDir . '/fsdf.png';    
$overlayPath  = $baseDir . '/mattruoc.png';    
  
// Kiểm tra file cần thiết tối thiểu (ảnh nền)    
if (!is_file($bgBasePath) || !is_file($overlayPath)) {    
    http_response_code(500);    
    exit;    
}    
  
// --- Hàm vẽ chữ có hiệu ứng ---    
function imagettftextSpWithEffects(    
    $image, $size, $angle, $x, $y, $text, $font,    
    $textColor, $shadowColor, $shadowOffsetX = 0, $shadowOffsetY = 0, $outerGlowSize = 1, $spacing = 0    
) {    
    $w = imagesx($image);    
    $h = imagesy($image);    
    $temp = imagecreatetruecolor($w, $h);    
    imagesavealpha($temp, true);    
    $transparent = imagecolorallocatealpha($temp, 0, 0, 0, 127);    
    imagefill($temp, 0, 0, $transparent);    
  
    $txt  = imagecolorallocatealpha($temp, (int)$textColor[0], (int)$textColor[1], (int)$textColor[2], (int)$textColor[3]);    
    $shad = imagecolorallocatealpha($temp, (int)$shadowColor[0], (int)$shadowColor[1], (int)$shadowColor[2], (int)$shadowColor[3]);    
  
    if ((int)$spacing === 0) {    
        for ($i = 0; $i < (int)$outerGlowSize; $i++) {    
            imagettftext($temp, (float)$size, (float)$angle, (int)($x + $shadowOffsetX), (int)($y + $shadowOffsetY), $shad, $font, $text);    
        }    
        imagettftext($temp, (float)$size, (float)$angle, (int)$x, (int)$y, $txt, $font, $text);    
    } else {    
        $temp_x = (int)$x;    
        $len = strlen($text);    
        for ($i = 0; $i < $len; $i++) {    
            for ($j = 0; $j < (int)$outerGlowSize; $j++) {    
                imagettftext($temp, (float)$size, (float)$angle, (int)($temp_x + $shadowOffsetX), (int)($y + $shadowOffsetY), $shad, $font, $text[$i]);    
            }    
            $bbox = imagettftext($temp, (float)$size, (float)$angle, (int)$temp_x, (int)$y, $txt, $font, $text[$i]);    
            $advance = (int)($bbox[2] - $bbox[0]);    
            $temp_x += (int)$spacing + $advance;    
        }    
    }    
  
    imagecopy($image, $temp, 0, 0, 0, 0, $w, $h);    
    imagedestroy($temp);    
}    
  
// --- Xuất PNG nền trong suốt ---    
header('Content-Type: image/png');    
  
// Load ảnh nền CCCD    
$baseImg = imagecreatefrompng($bgBasePath);    
$W = imagesx($baseImg);    
$H = imagesy($baseImg);    
  
// Overlay giao diện mặt trước    
$overlay = imagecreatefrompng($overlayPath);    
imagecopy($baseImg, $overlay, 0, 0, 0, 0, imagesx($overlay), imagesy($overlay));    
  
// --- QR code ---    
$qrPayload = $socccd.'||'.$name.'|'.str_replace('/','',$birthday).'|'.$sex.'|'.$thuongtru.'|'.str_replace('/','',$ngaycap);    
$qrUrl = 'https://quickchart.io/qr?text='.urlencode($qrPayload).'&light=0000&ecLevel=Q&format=png&size=170';    
$qrData = @file_get_contents($qrUrl);    
$qrImg  = $qrData ? imagecreatefromstring($qrData) : null;    
if ($qrImg) {    
    imagecopy($baseImg, $qrImg, 1360, 200, 0, 0, imagesx($qrImg), imagesy($qrImg));    
}    
  
// --- Màu chữ ---    
$textColor   = [0, 0, 0, 20];    
$shadowColor = [0, 0, 0, 60];    
  
// --- Vẽ chữ ---    
if (is_file($fontBoldPath) && is_file($fontRegPath)) {    
    imagettftextSpWithEffects($baseImg, 40, 0, 845, 535, $socccd, $fontBoldPath, $textColor, $shadowColor, 0, 0, 3);    
    imagettftextSpWithEffects($baseImg, 31, 0, 725, 630, mb_strtoupper($name, 'UTF-8'), $fontRegPath, $textColor, $shadowColor, 1, 1, 2);    
    imagettftextSpWithEffects($baseImg, 28, 0, 1060, 670, $birthday, $fontRegPath, $textColor, $shadowColor, 1, 1, 2);    
    imagettftextSpWithEffects($baseImg, 28, 0, 935, 715, $sex, $fontRegPath, $textColor, $shadowColor, 1, 1, 2);    
    imagettftextSpWithEffects($baseImg, 28, 0, 1340, 722, 'Việt Nam', $fontRegPath, $textColor, $shadowColor, 1, 1, 2);    
    imagettftextSpWithEffects($baseImg, 28, 0, 725, 810, $quequan, $fontRegPath, $textColor, $shadowColor, 1, 1, 2);    
    imagettftextSpWithEffects($baseImg, 28, 0, 725, 900, $thuongtru, $fontRegPath, $textColor, $shadowColor, 1, 1, 2);    
    imagettftextSpWithEffects($baseImg, 28, 0, 1190, 855, $xomlang, $fontRegPath, $textColor, $shadowColor, 1, 1, 2);    
    imagettftextSpWithEffects($baseImg, 18, 0, 555, 875, $ngaycap, $fontRegPath, $textColor, $shadowColor, 1, 1, 2);    
}    
  
// --- Ảnh thẻ ---    
$desiredW = 295;    
$desiredH = 405;    
$photoData = @file_get_contents($anhtheUrl);    
if ($photoData) {    
    $srcPhoto = @imagecreatefromstring($photoData);    
    if ($srcPhoto) {    
        $adj = imagecreatetruecolor($desiredW, $desiredH);    
        imagesavealpha($adj, true);    
        $tcol = imagecolorallocatealpha($adj, 0, 0, 0, 127);    
        imagefill($adj, 0, 0, $tcol);    
  
        $sW = imagesx($srcPhoto);    
        $sH = imagesy($srcPhoto);    
        $srcAspect = ($sH > 0) ? ($sW / $sH) : 1.0;    
        $dstAspect = $desiredW / $desiredH;    
  
        if ($srcAspect > $dstAspect) {    
            $cropW = (int)($sH * $dstAspect);    
            $cropX = (int)(($sW - $cropW) / 2);    
            imagecopyresampled($adj, $srcPhoto, 0, 0, $cropX, 0, $desiredW, $desiredH, $cropW, $sH);    
        } else {    
            $cropH = (int)($sW / $dstAspect);    
            $cropY = (int)(($sH - $cropH) / 2);    
            imagecopyresampled($adj, $srcPhoto, 0, 0, 0, $cropY, $desiredW, $desiredH, $sW, $cropH);    
        }    
  
        imagecopy($baseImg, $adj, 400, 430, 0, 0, $desiredW, $desiredH);    
        imagedestroy($adj);    
        imagedestroy($srcPhoto);    
    }    
}    
  
// --- Tạo canvas trong suốt chuẩn (VD: 1600x1200) ---
$canvasW = 1600;
$canvasH = 1200;

$finalImg = imagecreatetruecolor($canvasW, $canvasH);
imagesavealpha($finalImg, true);
$transparent = imagecolorallocatealpha($finalImg, 0, 0, 0, 127);
imagefill($finalImg, 0, 0, $transparent);

// Căn giữa CCCD vào canvas
$dstX = (int)(($canvasW - $W) / 2);
$dstY = (int)(($canvasH - $H) / 2);
imagecopy($finalImg, $baseImg, $dstX, $dstY, 0, 0, $W, $H);

// --- Xuất PNG ---
imagesavealpha($finalImg, true);
imagepng($finalImg, null, 9);
  
// --- Dọn dẹp ---    
if (isset($qrImg) && $qrImg) imagedestroy($qrImg);    
imagedestroy($overlay);    
imagedestroy($baseImg);    
imagedestroy($finalImg);    
exit;  