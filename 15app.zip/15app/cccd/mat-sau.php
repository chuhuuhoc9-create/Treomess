<?php
ini_set('display_errors', 0);
error_reporting(0);

if (isset($_GET['name'])) {
    $socccd    = trim($_GET['socccd']);
    $name      = trim($_GET['name']);
    $name      = iconv('UTF-8', 'ASCII//TRANSLIT', $name);
    $name      = preg_replace('/[^A-Za-z0-9 ]/', '', $name);

    // Xử lý fullname cho MRZ: họ << tên đệm < tên
    $parts = explode(' ', $name);
    if (count($parts) > 1) {
        $lastname  = array_shift($parts);        // họ
        $midnames  = array_slice($parts, 0, -1); // tên đệm
        $firstname = end($parts);                // tên chính
        $fullname  = $lastname . '<<' . implode('<', array_merge($midnames, [$firstname]));
    } else {
        $fullname = $name;
    }

    $birthday  = trim($_GET['birthday']);
    $sex       = trim($_GET['sex']);
    $quequan   = trim($_GET['quequan']);
    $thuongtru = trim($_GET['thuongtru']);
    $ngaycap   = trim($_GET['ngaycap']);

    if (empty($socccd) || empty($name) || empty($birthday) || empty($sex) || empty($quequan) || empty($thuongtru) || empty($ngaycap)) {
        die("Missing input");
    }

    // Hàm in chữ có hiệu ứng
    function imagettftextSpWithEffects($image, $size, $angle, $x, $y, $text, $font, $textColor, $shadowColor, $shadowOffsetX, $shadowOffsetY, $outerGlowSize = 1, $spacing = 0)
    {
        $temp_image = imagecreatetruecolor(imagesx($image), imagesy($image));
        imagesavealpha($temp_image, true);
        $transparentColor = imagecolorallocatealpha($temp_image, 0, 0, 0, 127);
        imagefill($temp_image, 0, 0, $transparentColor);

        $textColor   = imagecolorallocatealpha($temp_image, $textColor[0], $textColor[1], $textColor[2], $textColor[3]);
        $shadowColor = imagecolorallocatealpha($temp_image, $shadowColor[0], $shadowColor[1], $shadowColor[2], $shadowColor[3]);

        if ($spacing == 0) {
            for ($i = 0; $i < $outerGlowSize; $i++) {
                imagettftext($temp_image, $size, $angle, $x + $shadowOffsetX, $y + $shadowOffsetY, $shadowColor, $font, $text);
            }
            imagettftext($temp_image, $size, $angle, $x, $y, $textColor, $font, $text);
        } else {
            $temp_x = $x;
            for ($i = 0; $i < strlen($text); $i++) {
                for ($j = 0; $j < $outerGlowSize; $j++) {
                    imagettftext($temp_image, $size, $angle, $temp_x + $shadowOffsetX, $y + $shadowOffsetY, $shadowColor, $font, $text[$i]);
                }
                $bbox   = imagettftext($temp_image, $size, $angle, $temp_x, $y, $textColor, $font, $text[$i]);
                $temp_x += $spacing + ($bbox[2] - $bbox[0]);
            }
        }
        imagecopy($image, $temp_image, 0, 0, 0, 0, imagesx($image), imagesy($image));
        imagedestroy($temp_image);
    }

    // Xuất ảnh PNG trong suốt
    header('Content-type: image/png');

    // Kích thước canvas tổng (nền trong suốt)
    $canvasWidth  = 1600; 
    $canvasHeight = 1200;

    $canvas = imagecreatetruecolor($canvasWidth, $canvasHeight);
    imagesavealpha($canvas, true);
    $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
    imagefill($canvas, 0, 0, $transparent);

    // Ảnh CCCD mặt sau (matsau.png nền trong suốt)
    $matsau = imagecreatefrompng('matsau.png');
    $cccdWidth  = imagesx($matsau);
    $cccdHeight = imagesy($matsau);

    // Căn giữa CCCD
    $dstX = ($canvasWidth  - $cccdWidth)  / 2;
    $dstY = ($canvasHeight - $cccdHeight) / 2;

    imagecopy($canvas, $matsau, $dstX, $dstY, 0, 0, $cccdWidth, $cccdHeight);
    imagedestroy($matsau);

    // Font
    $font1 = __DIR__ . "/SVN-Arial Regular.ttf";
    $font2 = __DIR__ . "/font.ttf";

    $textColor   = [0, 0, 0, 0];
    $shadowColor = [0, 0, 0, 50];

    // In ngày cấp
    imagettftextSpWithEffects($canvas, 20, 0, $dstX + 845, $dstY + 290, $ngaycap, $font1, $textColor, $shadowColor, 1, 1, 1);

    // MRZ
    $mrzRaw = strtoupper(
        'IDVNM' . substr($socccd, 3) . '1' . $socccd . '<<6'
        . rand(100000, 999999) . 'F' . rand(10000000, 99999999)
        . 'VNM<<<<<<<<<<<6' . $fullname . '<<<<<<<<<<<<'
    );

    $mrzRaw   = substr(str_pad($mrzRaw, 90, '<'), 0, 90);
    $mrzLines = str_split($mrzRaw, 30);

    $startY   = $dstY + 720;
    $lineY    = [$startY, $startY + 55, $startY + 110];
    $fontSize = 45;

    foreach ($mrzLines as $i => $line) {
        $bbox = imagettfbbox($fontSize, 0, $font2, $line);
        $textWidth = $bbox[2] - $bbox[0];
        $centerX   = $dstX + ($cccdWidth - $textWidth) / 2;

        $y = $lineY[$i];

        imagettftextSpWithEffects(
            $canvas,
            $fontSize,
            0,
            $centerX,
            $y,
            $line,
            $font2,
            $textColor,
            $shadowColor,
            1, 1, 1
        );
    }

    // Xuất PNG trong suốt
    imagesavealpha($canvas, true);
    imagepng($canvas, null, 9);
    imagedestroy($canvas);
}
?>