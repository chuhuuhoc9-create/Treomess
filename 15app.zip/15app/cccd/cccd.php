<?php
ini_set('display_errors', 0);
error_reporting(0);

// --- Nhận dữ liệu GET ---
$socccd    = trim($_GET['socccd'] ?? '');
$name      = trim($_GET['name'] ?? '');
$birthday  = trim($_GET['birthday'] ?? '');
$sex       = trim($_GET['sex'] ?? '');
$quequan   = trim($_GET['quequan'] ?? '');
$thuongtru = trim($_GET['thuongtru'] ?? '');
$xomlang   = trim($_GET['xomlang'] ?? '');
$ngaycap   = trim($_GET['ngaycap'] ?? '');
$anhtheUrl = trim($_GET['anhthe'] ?? '');

if (!$socccd || !$name) {
    header('Content-Type: application/json');
    echo json_encode(['status'=>'error','msg'=>'Missing required fields']);
    exit;
}

// --- Đường dẫn tài nguyên ---
$baseDir      = __DIR__;
$fontBoldPath = $baseDir . '/SVN-Arial 3 bold.ttf';
$fontRegPath  = $baseDir . '/SVN-Arial Regular.ttf';
//$bgBasePath   = $baseDir . '/fsdf.png';
$overlayPath  = $baseDir . '/mattruoc.png';
$backBasePath = $baseDir . '/matsau.png';
$fontMRZ      = $baseDir . '/font.ttf';

// Kiểm tra file cần thiết
foreach([$overlayPath,$backBasePath,$fontBoldPath,$fontRegPath,$fontMRZ] as $f){
    if(!is_file($f)){
        header('Content-Type: application/json');
        echo json_encode(['status'=>'error','msg'=>"Missing file: $f"]);
        exit;
    }
}

// --- Hàm vẽ chữ có hiệu ứng ---
function imagettftextSpWithEffects($image, $size, $angle, $x, $y, $text, $font,
    $textColor, $shadowColor, $shadowOffsetX = 0, $shadowOffsetY = 0, $outerGlowSize = 1, $spacing = 0){
    $w = imagesx($image); $h = imagesy($image);
    $temp = imagecreatetruecolor($w,$h);
    imagesavealpha($temp,true);
    $transparent = imagecolorallocatealpha($temp,0,0,0,127);
    imagefill($temp,0,0,$transparent);
    $txt  = imagecolorallocatealpha($temp,$textColor[0],$textColor[1],$textColor[2],$textColor[3]);
    $shad = imagecolorallocatealpha($temp,$shadowColor[0],$shadowColor[1],$shadowColor[2],$shadowColor[3]);
    if((int)$spacing===0){
        for($i=0;$i<$outerGlowSize;$i++){
            imagettftext($temp,$size,$angle,$x+$shadowOffsetX,$y+$shadowOffsetY,$shad,$font,$text);
        }
        imagettftext($temp,$size,$angle,$x,$y,$txt,$font,$text);
    } else {
        $temp_x = $x;
        $len = mb_strlen($text,'UTF-8');
        for($i=0;$i<$len;$i++){
            for($j=0;$j<$outerGlowSize;$j++){
                imagettftext($temp,$size,$angle,$temp_x+$shadowOffsetX,$y+$shadowOffsetY,$shad,$font,mb_substr($text,$i,1,'UTF-8'));
            }
            $bbox = imagettftext($temp,$size,$angle,$temp_x,$y,$txt,$font,mb_substr($text,$i,1,'UTF-8'));
            $temp_x += $spacing + ($bbox[2]-$bbox[0]);
        }
    }
    imagecopy($image,$temp,0,0,0,0,$w,$h);
    imagedestroy($temp);
}

// --- Hàm upload lên UpAnhLayLink ---
function upload_to_upanhlaylink($filePath){
    $api_token = 'b4bf9ec045ec5b46fa1755f58877d622';
    $server = 'server_1';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://upload.upanhlaylink.com/upload");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'token' => $api_token,
        'images' => new CURLFile($filePath),
        'server' => $server
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $json = json_decode($response, true);
    if(!empty($json['results'][0]['success'])){
        return $json['results'][0]['url'] ?? null;
    }
    return null;
}

// --- Hàm ghép ảnh vào nền, căn giữa & thu nhỏ ---
function merge_with_background($srcPath, $bgPath, $outputPath, $scale = 0.8) {
    if (!file_exists($srcPath) || !file_exists($bgPath)) {
        return false;
    }
    $bg  = imagecreatefrompng($bgPath);
    $src = imagecreatefrompng($srcPath);

    $bgW  = imagesx($bg);
    $bgH  = imagesy($bg);
    $srcW = imagesx($src);
    $srcH = imagesy($src);

    // Tính kích thước mới (theo scale)
    $newW = (int)($srcW * $scale);
    $newH = (int)($srcH * $scale);

    // Căn giữa trên nền
    $posX = (int)(($bgW - $newW) / 2);
    $posY = (int)(($bgH - $newH) / 2);

    // Canvas final
    $final = imagecreatetruecolor($bgW, $bgH);
    imagesavealpha($final, true);
    $transparent = imagecolorallocatealpha($final, 0, 0, 0, 127);
    imagefill($final, 0, 0, $transparent);

    // Copy nền
    imagecopy($final, $bg, 0, 0, 0, 0, $bgW, $bgH);

    // Ghép CCCD đã resize vào giữa
    imagecopyresampled($final, $src, $posX, $posY, 0, 0, $newW, $newH, $srcW, $srcH);

    // Xuất file
    imagepng($final, $outputPath);

    imagedestroy($bg);
    imagedestroy($src);
    imagedestroy($final);

    return true;
}

// -------------------- TẠO ẢNH MẶT TRƯỚC --------------------
$baseFront = imagecreatefrompng($overlayPath);
$frontImg = imagecreatetruecolor(imagesx($baseFront), imagesy($baseFront));
imagesavealpha($frontImg, true);
$transparent = imagecolorallocatealpha($frontImg, 0, 0, 0, 127);
imagefill($frontImg, 0, 0, $transparent);
imagecopy($frontImg, $baseFront, 0, 0, 0, 0, imagesx($baseFront), imagesy($baseFront));
imagedestroy($baseFront);

// Copy overlay
$overlay = imagecreatefrompng($overlayPath);
imagecopy($frontImg, $overlay, 0, 0, 0, 0, imagesx($overlay), imagesy($overlay));
imagedestroy($overlay);

// QR code
$qrPayload = $socccd.'||'.$name.'|'.str_replace('/','',$birthday).'|'.$sex.'|'.$thuongtru.'|'.str_replace('/','',$ngaycap);
$qrUrl = 'https://quickchart.io/qr?text='.urlencode($qrPayload).'&light=0000&ecLevel=Q&format=png&size=170';
$qrData = @file_get_contents($qrUrl);
if($qrData){
    $qrImg = imagecreatefromstring($qrData);
    imagecopy($frontImg,$qrImg,1360,200,0,0,imagesx($qrImg),imagesy($qrImg));
    imagedestroy($qrImg);
}

// Chữ trên mặt trước
$textColor   = [0,0,0,20]; $shadowColor=[0,0,0,60];
imagettftextSpWithEffects($frontImg,40,0,845,535,$socccd,$fontBoldPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,31,0,725,630,mb_strtoupper($name,'UTF-8'),$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,1060,670,$birthday,$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,935,715,$sex,$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,1340,722,'Việt Nam',$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,725,810,$quequan,$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,725,900,$thuongtru,$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,28,0,1190,855,$xomlang,$fontRegPath,$textColor,$shadowColor);
imagettftextSpWithEffects($frontImg,18,0,555,875,$ngaycap,$fontRegPath,$textColor,$shadowColor);

// Ảnh thẻ người dùng
if($anhtheUrl){
    $photoData = @file_get_contents($anhtheUrl);
    if($photoData){
        $srcPhoto = @imagecreatefromstring($photoData);
        if($srcPhoto){
            $desiredW=295; $desiredH=405;
            $adj = imagecreatetruecolor($desiredW,$desiredH);
            imagesavealpha($adj,true);
            $transparent = imagecolorallocatealpha($adj,0,0,0,127);
            imagefill($adj,0,0,$transparent);

            $sW=imagesx($srcPhoto); $sH=imagesy($srcPhoto);
            $srcAspect = ($sH>0)?($sW/$sH):1.0;
            $dstAspect = $desiredW/$desiredH;
            if($srcAspect > $dstAspect){
                $cropW = (int)($sH*$dstAspect); $cropX=(int)(($sW-$cropW)/2);
                imagecopyresampled($adj,$srcPhoto,0,0,$cropX,0,$desiredW,$desiredH,$cropW,$sH);
            }else{
                $cropH = (int)($sW/$dstAspect); $cropY=(int)(($sH-$cropH)/2);
                imagecopyresampled($adj,$srcPhoto,0,0,0,$cropY,$desiredW,$desiredH,$sW,$cropH);
            }

            imagecopy($frontImg,$adj,400,430,0,0,$desiredW,$desiredH);
            imagedestroy($adj);
            imagedestroy($srcPhoto);
        }
    }
}


// -------------------- TẠO ẢNH MẶT SAU --------------------
$baseBack = imagecreatefrompng($backBasePath);
$backImg = imagecreatetruecolor(imagesx($baseBack), imagesy($baseBack));
imagesavealpha($backImg,true);
$transparent = imagecolorallocatealpha($backImg,0,0,0,127);
imagefill($backImg,0,0,$transparent);
imagecopy($backImg, $baseBack, 0, 0, 0, 0, imagesx($baseBack), imagesy($baseBack));
imagedestroy($baseBack);

// Font MRZ
$textColor=[0,0,0,0]; $shadowColor=[0,0,0,50];
imagettftextSpWithEffects($backImg,20,0,845,290,$ngaycap,$fontRegPath,$textColor,$shadowColor);

// Hàm loại bỏ dấu tiếng Việt
function removeVietnameseAccents($str) {
    $str = mb_strtoupper($str, 'UTF-8');
    $unicode = [
        'A'=>'À|Á|Â|Ã|Ä|Å|Ă|Ā|Ą|Ạ|Ả|Ấ|Ầ|Ẩ|Ẫ|Ậ|Ắ|Ằ|Ẳ|Ẵ|Ặ',
        'E'=>'È|É|Ê|Ë|Ē|Ę|Ẹ|Ẻ|Ẽ|Ế|Ề|Ể|Ễ|Ệ',
        'I'=>'Ì|Í|Î|Ï|Ī|Ị|Ỉ|Ĩ',
        'O'=>'Ò|Ó|Ô|Õ|Ö|Ø|Ō|Ọ|Ỏ|Ố|Ồ|Ổ|Ỗ|Ộ|Ớ|Ờ|Ở|Ỡ|Ợ',
        'U'=>'Ù|Ú|Û|Ü|Ū|Ụ|Ủ|Ũ|Ứ|Ừ|Ử|Ữ|Ự',
        'Y'=>'Ý|Ỳ|Ỷ|Ỹ|Ỵ',
        'D'=>'Đ'
    ];
    foreach($unicode as $nonAccent=>$pattern){
        $str = preg_replace('/'.$pattern.'/u', $nonAccent, $str);
    }
    $str = preg_replace('/[^A-Z0-9 ]/', '', $str);
    return $str;
}

// Chuẩn hóa fullname MRZ
$fullnameMRZ = removeVietnameseAccents($name);
$parts = preg_split('/\s+/',$fullnameMRZ);
if(count($parts) > 1){
    $lastname = array_shift($parts);
    $firstname = array_pop($parts);
    $midnames = $parts;
    $fullnameMRZ = $lastname . '<<' . implode('<', array_merge($midnames, [$firstname]));
} else {
    $fullnameMRZ = $fullnameMRZ;
}

// Thêm ký tự < để MRZ dòng 3 đúng chuẩn
$fullnameMRZ = substr(str_pad($fullnameMRZ, 39, '<'), 0, 39);

// Tạo MRZ tổng thể
//$mrzRaw = strtoupper(
   // 'IDVNM' . substr($socccd, 3) . '4' . $socccd . '<<9'
   // . rand(1000000,9999999) . 'M' . rand(1000000,9999999)
    //. 'VNM<<<<<<<<<<<4' . $fullnameMRZ . '<<<<<<<<<<<<'
);

// Tạo MRZ tổng thể
$mrzRaw = strtoupper(
    'IDVNM' . substr($socccd, 3) . '4' . $socccd . '<<9'
    . '0504069' . 'M' . '3004065'
    . 'VNM<<<<<<<<<<<4' . $fullnameMRZ . '<<<<<<<<<<<<'
);

$mrzRaw = substr(str_pad($mrzRaw, 90, '<'), 0, 90);
$mrzLines = str_split($mrzRaw, 30);
$startY = 720;
$lineY = [$startY, $startY+55, $startY+110];
$fontSize = 45;

// Vẽ MRZ lên ảnh
foreach($mrzLines as $i => $line){
    $bbox = imagettfbbox($fontSize, 0, $fontMRZ, $line);
    $textWidth = $bbox[2]-$bbox[0];
    $centerX = (imagesx($backImg) - $textWidth) / 2;
    $y = $lineY[$i];
    imagettftextSpWithEffects($backImg, $fontSize, 0, $centerX, $y, $line, $fontMRZ, $textColor, $shadowColor, 1, 1, 1);
}

// --- Lưu ảnh mặt trước ---
$frontFile = $baseDir . '/output_front.png';
imagepng($frontImg, $frontFile);
imagedestroy($frontImg);

// --- Lưu ảnh mặt sau ---
$backFile = $baseDir . '/output_back.png';
imagepng($backImg, $backFile);
imagedestroy($backImg);

// --- Ghép vào nền mới ---
$bgImage  = $baseDir . '/nen.png';  // ảnh nền bạn chuẩn bị sẵn
$newFront = $baseDir . '/final_front.png';
$newBack  = $baseDir . '/final_back.png';

// Ghép vào nền, thu nhỏ 50% so với ảnh gốc
merge_with_background($frontFile, $bgImage, $newFront, 1);
merge_with_background($backFile, $bgImage, $newBack, 1);

// --- Upload ảnh đã ghép nền ---
$front_url = upload_to_upanhlaylink($newFront);
$back_url  = upload_to_upanhlaylink($newBack);

// --- Xóa file tạm nếu muốn ---
unlink($frontFile);
unlink($backFile);

// --- Trả JSON ---
header('Content-Type: application/json');
echo json_encode([
    'status' => 'success',
    'info' => compact('socccd','name','birthday','sex','quequan','thuongtru','xomlang','ngaycap'),
    'front' => $front_url,
    'back' => $back_url
]);
exit;